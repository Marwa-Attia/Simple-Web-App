import { InMemoryDbService } from 'angular-in-memory-web-api';
export class HeroData implements InMemoryDbService {
  createDb() {
    let hoganCall = [
      { id: 1, message: 'total deals from batch select sql is not equal to verification size' },
      { id: 2, message: 'success processed 0 loans' }
    ];
    return {hoganCall};
  }
}
