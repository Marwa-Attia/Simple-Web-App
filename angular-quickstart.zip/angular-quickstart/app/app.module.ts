import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }   from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule }   from '@angular/forms';
import { DeactiveLoanHoganService } from './component/deactiveLoanHogan/deactive-loan-hogan.service';
import { DeactiveLoanHoganComponent} from './component/deactiveLoanHogan/deactive-loan-hogan.component';
import { CoreHttpService } from './component/lib/core-http.service';
@NgModule({
  imports:      [ BrowserModule,AppRoutingModule,FormsModule ],
  declarations: [ AppComponent,DeactiveLoanHoganComponent ],
  providers: [ DeactiveLoanHoganService,CoreHttpService ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
