"use strict";
var HeroData = (function () {
    function HeroData() {
    }
    HeroData.prototype.createDb = function () {
        var hoganCall = [
            { id: 1, message: 'total deals from batch select sql is not equal to verification size' },
            { id: 2, message: 'success processed 0 loans' }
        ];
        return { hoganCall: hoganCall };
    };
    return HeroData;
}());
exports.HeroData = HeroData;
//# sourceMappingURL=app-mock-data.js.map