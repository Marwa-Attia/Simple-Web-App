"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var deactive_loan_hogan_service_1 = require('./deactive-loan-hogan.service');
var DeactiveLoanHoganComponent = (function () {
    function DeactiveLoanHoganComponent(deactiveLoanHoganService) {
        this.deactiveLoanHoganService = deactiveLoanHoganService;
        this.hoganCall = {
            startDate: new Date(),
            endDate: new Date(),
            recordCount: 0
        };
    }
    DeactiveLoanHoganComponent.prototype.triggerCallHogan = function () {
        var stDate = this.hoganCall.startDate;
        var edDate = this.hoganCall.endDate;
        var recCount = this.hoganCall.recordCount;
        if (!stDate || !edDate || !recCount) {
            this.hoganCallErrorMessage = "Record Count, Start Date and End Date are required.";
        }
        else {
            if (stDate && stDate < new Date(2014, 4, 15)) {
                this.hoganCallErrorMessage = 'Start date cannot be prior to Release 2.14 implementation date (05/16/2014).';
            }
            else if (stDate && edDate && stDate > edDate) {
                this.hoganCallErrorMessage = 'Start date cannot be after end date.';
            }
            else {
                this.deactiveLoanHoganService.setRequest(this.hoganCall);
                this.hoganCallErrorMessage = this.deactiveLoanHoganService.runCallHogan().message;
            }
        }
    };
    DeactiveLoanHoganComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'deactive-loan-hogan',
            templateUrl: 'deactive-loan-hogan.component.html'
        }), 
        __metadata('design:paramtypes', [deactive_loan_hogan_service_1.DeactiveLoanHoganService])
    ], DeactiveLoanHoganComponent);
    return DeactiveLoanHoganComponent;
}());
exports.DeactiveLoanHoganComponent = DeactiveLoanHoganComponent;
//# sourceMappingURL=deactive-loan-hogan.component.js.map