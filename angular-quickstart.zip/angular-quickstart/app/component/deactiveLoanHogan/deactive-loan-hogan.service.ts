
import { Injectable } from '@angular/core';
import { CoreHttpService } from './lib/core-http.service';
import { Observable }     from 'rxjs/Observable';
import {  Response } from '@angular/http';
@Injectable()
export class DeactiveLoanHoganService {
	private requestData: HoganCall;
    private hoganCallURL = 'app/hoganCall';  // URL to web API

	constructor(private coreHttpService: CoreHttpService) {
		
	}
	
	setRequest(request:HoganCall){
		this.requestData = request ;
	}
	
	runCallHogan(): Observable<HoganCallResponse> {
        console.log(this.requestData);
        let resId=Math.floor(Math.random() * 2) + 1 ;
       let list: Observable<HoganCallResponse[]>=null; 
       // return {message:'OK'};
       // let queryStr='?id=${resId}';
      //  console.log(queryStr);
        console.log(resId);
        
		return this.coreHttpService.get(this.hoganCallURL).map(this.extractData)
                    .catch(this.handleError);
	}
     private extractData(res: Response) {
    let body = res.json();
    return body.data || { };
  }
  private handleError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
}

export class HoganCallResponse {
	message: string; 
}

export class HoganCall {
	startDate: Date;
	endDate: Date;
  	recordCount:number;
}