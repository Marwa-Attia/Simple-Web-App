import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DeactiveLoanHoganService } from './component/deactiveLoanHogan/deactive-loan-hogan.service';
import { DeactiveLoanHoganComponent} from './component/deactiveLoanHogan/deactive-loan-hogan.component';
const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard',  component: DeactiveLoanHoganComponent }
];
@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
