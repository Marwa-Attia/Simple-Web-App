
angular.module('wf.framework', []);
angular.module('ui.date', []);
angular.module("dialog", [ 'ui.bootstrap' ]);

angular.module('wf.framework').run(function() {
	/**
	* Hack in support for Function.name for browsers that don't support it.
	* IE, I'm looking at you.
	**/
	if (Function.prototype.name === undefined && Object.defineProperty !== undefined) {
		Object.defineProperty(Function.prototype, 'name', {
			get: function() {
				console.log("shim");
				var funcNameRegex = /function\s([^(]{1,})\(/;
				var results = (funcNameRegex).exec((this).toString());
				return (results && results.length > 1) ? results[1].trim() : "";
			},
			set: function(value) {}
		});
	}
});


/*
 * wfBigdecimal directive
 * Usage
 * This will set the scale (number of digits after decimal point) to 5 and max number of digits
 * before decimal point to 6. If more than 6 digits are entered before decimal point
 * the validity will set to false.
 * <input type="text" ng-model="d1" wf-bigdecimal="{integer: 6, decimal:5}"></input>
 * or
 *
 * This will set the scale (number of digits after decimal point) to 5. This will not do any validation related to
 * number of digits before the decimal point.
 * <input type="text" ng-model="d1" wf-bigdecimal="5"></input>
 *
 * If the ng-model is a javascript Number it will stay a number.  If it is a Big then it will remain a big.
 * <input type="text" ng-model="d1" wf-bigdecimal="{integer: 6, decimal:5}"></input>
 * 
 */


angular.module('wf.framework')// By not including the dependencies this will not replace the existing wf.framework
    .directive('wfBigdecimal', ['$filter', function($filter) {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, element, attr, ngModelCtlr) {

				var dp = null;
				var integerDigits = null;
                var varType;

                /** Model Name to uniquely identify the element and default error message.*/
                var field = attr.ngModel;
                var errorMsg = "Invalid Number";

                /** if the error message is defined, then use that message instead of the default */
                if (attr.wfError != undefined) {
//                    errorMsg = scope.$eval(attr.wfError);
                    errorMsg = attr.wfError;
                }

				var conf = scope.$eval(attr.wfBigdecimal);
				if (typeof conf == 'object') {
					if (conf.decimal != null) {
						dp = conf.decimal;
					}
					if (conf.integer != null) {
						integerDigits = conf.integer;
					}
				} else {
					dp = conf;
				}
				
				/**
					Used when model is updated from the view i.e. user input
				*/
                function toBig(text) {
                    if (text == null || text === '') {
						if(element.hasClass("ng-invalid")){
							element.addClass("ng-valid");
							element.removeClass("ng-invalid");
						}
                        return null;
                    }

                    try {
                        ngModelCtlr.$setValidity('wfBigdecimalValidity', true);
                        if (!element.hasClass("ng-valid")){
                            element.addClass("ng-valid");
                            element.removeClass("ng-invalid");
                        }
                        text = text.replace(/[,]/g, '');
                        if (varType === "Big") {
                            return Big(text);
                        } else if (varType == "Number") {
							if (Number(text) != Number(text)) {	// is NaN; should only occur if starting with initial '-'
								return undefined;
							} else {
                            return Number(text);
							}
                        } else {
                            return text;
                        }
					} catch(err) {
						ngModelCtlr.$setValidity('wfBigdecimalValidity', false);
						return undefined;
					}
                }

				/**
					Used when view is updated from the model
				*/
                function toText(big) {
                    if (varType == undefined && big != undefined) {
                        varType = big.constructor.name;
                    }
					if (big != null) {
						if (dp == null || dp === '') {
                            var amount = big;
                            if (varType === "Big") {
                                amount = big.toString();
                            }
							return $filter('number')(big.toString());
						}
						else {
                            if (varType !== 'Big') {
                                big = Big(big);
                            }
                            return $filter('number')(big.toFixed(dp), dp);
						}
					}
                }
                ngModelCtlr.$parsers.unshift(toBig);
                ngModelCtlr.$formatters.unshift(toText);

                element.on("blur", function(event) {
                    if (event.currentTarget.value != null && event.currentTarget.value !== '') {
						var text = event.currentTarget.value.replace(/\s/g, '');
                        text = text.replace(/,/g, '');
						if (ngModelCtlr.$valid) {
							try {
								if (text === "-") {		// special handling for focus loss with only initial '-' 
									event.currentTarget.value = "";
								} else {
                                var big = Big(text);
								if (dp != null && dp !== '') {
    								element.val($filter('number')(big.toFixed(dp), dp));
								}
								else {
    								element.val($filter('number')(big.toString()));
								}
							}
							}
							catch(err) {
								element.removeClass("ng-valid");
								element.addClass("ng-invalid");
                                ngModelCtlr.$setValidity('wfBigdecimalValidity', false);
                                appendErrorMessage(scope.$eval(attr.wfErrorList), field, errorMsg);
								console.log(err);
                                return;
							}
                            ngModelCtlr.$setValidity('wfBigdecimalValidity', true);
                            removeErrorMessage(scope.$eval(attr.wfErrorList), field);

                        }
                    }
                });

                // Allow only these keys to be pressed
                var validKeys = [
                    48, 96,   // 0
                    49, 97,   // 1
                    50, 98,   // 2
                    51, 99,   // 3
                    52, 100,  // 4
                    53, 101,  // 5
                    54, 102,  // 6
                    55, 103,  // 7
                    56, 104,  // 8
                    57, 105,  // 9
                    190, 110, // period
                    189, 109, // dash
                    188,      // comma
                    //86,       // v for Ctrl-v
                    67,       // c for Ctrl-c
                    88,       // x for Ctrl-x
                    8,        // backspace
                    9,        // tab
                    46,       // delete
                    35,       // end
                    36,       // home
                    37,       // left
                    38,       // up
                    39,       // right
                    40        // down
                ];

                function charCode2Char(code) {
                    switch (code) {
                        case 48:
                        case 96: return '0';
                        case 49:
                        case 97: return '1';
                        case 50:
                        case 98: return '2';
                        case 51:
                        case 99: return '3';
                        case 52:
                        case 100: return '4';
                        case 53:
                        case 101: return '5';
                        case 54:
                        case 102: return '6';
                        case 55:
                        case 103: return '7';
                        case 56:
                        case 104: return '8';
                        case 57:
                        case 105: return '9';
                        case 190:
                        case 110: return '.';
                        case 189:
                        case 109: return '-';
                        case 188: return ',';
                        case 86: return 'v';
                        case 67: return 'c';
                        case 88: return 'x';
                        default: return '%';
                    }
                };

                function getNumberParts(num) {
                    var index = num.indexOf(".");
                    var decimalPart = "";
                    var integerPart = "";
                    if (index > -1) {
                        decimalPart = num.substring(index + 1);
                        integerPart = num.substring(0, index);
                    } else {
                        integerPart = num;
                    }
                    // handle length of negative numbers
                    var negative = 0;
                    if (integerPart.indexOf('-') > -1) {
                        negative = 1;
                    }
                    return [negative, integerPart.replace(/,/g, ''), decimalPart.replace(/,/g, ''), index];
                };

                // ngModelCtrl.$setViewValue() doesn't set the ngModel variable like the AngularJS document claims.
                // disabling Ctrl-v for now.
                element.on('paste', function(event) {
                    var self = $(this);
                    var orig = self.val();
                    setTimeout(function () {
                        var value = $(self).val().replace(/[^0-9\.\-]/g, '');
                        // console.log("orig: " + orig + " value: " + value);
                        var parts = getNumberParts(value);
                        var neg = parts[0];
                        var invalid = false;
                        var intPart = parts[1];
                        var decPart = parts[2];
                        if (integerDigits != null && intPart.length > integerDigits + neg) {
                            invalid = true;
                        }
                        else if (dp != null && decPart.length > dp) {
                            invalid = true;
                        }
                        if (invalid) {
                            value = orig;
                        }
                        ngModelCtlr.$setViewValue(value);
                        ngModelCtlr.$render();
                    });
                });

                element.on("keydown", function(event) {
                    var numPattern = new RegExp('[0-9]');
                    var charCode = event.which || event.keyCode;
                    var charStr = charCode2Char(charCode);
//                    console.log("Keypress: " + charStr + " keyCode: " + charCode);
                    var selectionStart = event.currentTarget.selectionStart;
                    var selectionEnd = event.currentTarget.selectionEnd;

                    if (validKeys.indexOf(charCode) === -1) {
                        event.preventDefault();
                        return;
                    }

                    // allow Shift-tab to navigate between fields
                    if (event.shiftKey == true) {
                        if (charCode === 9) {
                        	;	// allow Shift-tab to navigate between fields
                        } else {
                        event.preventDefault();
                        return;
                    }
                    }

                    if (event.ctrlKey == true) {
                        if (charStr === 'v' || charStr === 'c' || charStr === 'x') {
                            // do nothing and continue processing
                        }
                        else {
                            event.preventDefault();
                            return;
                        }
                    }

                    // Check for valid minus sign placement.
                    if (charStr === '-') {
                    	if (selectionStart < selectionEnd) {
                        	var minusIdx = event.currentTarget.value.indexOf('-');
                            if (minusIdx > -1 && minusIdx >= selectionStart && minusIdx < selectionEnd) {
                            	; // noop - replacing minus w/ new minus; ok
                            } else {
                            event.preventDefault();
                            return;
                        }
                        }
                        else if (event.currentTarget.value[0] === '-' && event.currentTarget.textContent.length === 0) {  // minus sign already exists, and is not only char
                            event.preventDefault();
                            return;
                        }
                    }

                    // Check for valid decimal point placement
                    // Added logic to allow the period key if the existing period is highlighted.  CREG-12654
                    var idx = event.currentTarget.value.indexOf('.');
                    if (charStr === '.' && idx > -1) {
                        if (selectionStart < selectionEnd) {
                            if (! (idx >= selectionStart && idx < selectionEnd)) {
                        event.preventDefault();
                        return;
                    }
                        }
                        else {
                            event.preventDefault();
                            return;
                        }
                    }
                    // Check for c, x, v with Ctrl.
                    if ((charStr === 'c' || charStr === 'x' || charStr === 'v') && ! event.ctrlKey) {
                        event.preventDefault();
                        return;
                    }

                    // Check for valid integer length.
                    if ((integerDigits != null && integerDigits !== '') ||
                            (dp != null && dp !== '')) {
                        var inputValue = event.currentTarget.value;
                        var parts = getNumberParts(inputValue);
                        var negative = parts[0];
                        var integerPart = parts[1];
                        var decimalPart = parts[2];
                        var index = parts[3];
                        // Backspace deleting the decimal point
                        if (charCode == 8 && selectionStart > 0 && inputValue[selectionStart-1] === '.' &&
                            inputValue.length-1 > integerDigits + negative) {
                            event.preventDefault();
                            return;
                        }
                        // Delete key deleting the decimal point
                        if (charCode == 46 && selectionStart > 0 && inputValue[selectionStart] === '.' &&
                            inputValue.length-1 > integerDigits + negative) {
                            event.preventDefault();
                            return;
                        }

                        // Delete or backspaces is pressed while part of the input is highlighted
                        if (selectionStart < selectionEnd && (charCode == 8 || charCode == 46)) {
                            var periodIdx = inputValue.indexOf('.');
                            if (periodIdx > -1 && periodIdx > selectionStart && periodIdx < selectionEnd) {
                                var newValue = inputValue.substring(0, selectionStart).replace('-', '') +
                                    inputValue.substring(selectionEnd);
                                if (newValue.length > integerDigits) {
                                    event.preventDefault();
                                    return;
                                }
                            }
                        }

                        if (numPattern.test(charStr) &&
                                selectionStart === selectionEnd) {
                            var invalid = false;
                            if (integerDigits != null && index > -1 && selectionStart < index+1 &&
                                integerPart.length+1 > integerDigits + negative) {
                                invalid = true;
                            } else if (dp != null && index > -1 && selectionStart > index &&
                                decimalPart.length+1 > dp) {
                                invalid = true;
                            }
                            else if (integerDigits != null && index == -1 && integerPart.length+1 > integerDigits + negative) {
                                invalid = true;
                            }
                            if (invalid) {
                                event.preventDefault();
                            }
                        } else {
                            ngModelCtlr.$setValidity('wfBigdecimalValidity', true);
                            if (!element.hasClass("ng-valid")){
                                element.addClass("ng-valid");
                                element.removeClass("ng-invalid");
                            }
                        }
                    }
                });
            }
        };
    }]);
/*
 * wfCurrency directive
 */


angular.module('wf.framework')// By not including the dependencies this will not replace the existing wf.framework
    .directive('wfCurrency', ['$filter', function($filter) {

        return {
            restrict: 'A',
            require: 'ngModel',
            compile: function(tElement, tAttrs) {
                if (tAttrs['placeholder'] == undefined) {
                    tElement.attr("placeholder", "$");
                }
                tElement.addClass("currency");

                return function(scope, element, attr, ngModelCtlr) {

                    var dp = 2;
                    var integerDigits = 14;
                    var minAmount;
                    var maxAmount;
                    var currencyType;
                    var isHidden = false;

                    /** Model Name to uniquely identify the element and default error message.*/
                    var field = attr.ngModel;
                    var id = attr.id;
                    if (id != undefined && id != null && String(id).length > 0) {
                        /**
                         * Fix for: if there is more than one element using the same model,
                         * then the errormessage will be recorded with id instead of model name.
                         * Given that the element has an id.
                         * */
                        if(attr.type != "Radio" && attr.type != "radio") {
                            field = attr.id;
                        }
                    }
                    var prefix = attr.wfCurrency;
                    if (prefix === '') {
                        prefix = "$";
                    } else if (prefix === 'none') { //CREG-11745 to specify no prefix needed
                        prefix = '';
                    }
                    var errorMsg = "Invalid Number";

                    /** if the error message is defined, then use that message instead of the default */
                    if (attr.wfError != undefined) {
                        errorMsg = attr.wfError;
                    }

                    // Only allow the dollar portion of the amount to be entered.
                    if (attr.wfNoCents != undefined) {
                        dp = 0;
                    }

                    var getDynamicModelValues = function() {
                    	/** if the error message is defined, then use that message instead of the default */
                        if (attr.wfError != undefined) {
                            errorMsg = attr.wfError;
                        }
                    // get the min and max allowable amounts.
                    if (attr.wfMinAmount != undefined && ! isNaN(attr.wfMinAmount)) {
                        minAmount = attr.wfMinAmount;
                        } else if (attr.wfMinAmount != undefined) {
                        	minAmount = scope.$eval(attr.wfMinAmount);
                    }
                    if (attr.wfMaxAmount != undefined && ! isNaN(attr.wfMaxAmount)) {
                        maxAmount = attr.wfMaxAmount;
                        } else if (attr.wfMaxAmount != undefined) {
                        	maxAmount = scope.$eval(attr.wfMaxAmount);
                    }
                        
                        if (attr.ngHide != undefined && Boolean(scope.$eval(attr.ngHide))) {
                        	isHidden = true;
                        } else {
                        	isHidden = false;
                    }
                    }

                    // initialize the min, max and error message values
                    getDynamicModelValues();
                    
                    function convertToMinus(text) {
                        if (text[0] === '(' && text[text.length - 1] === ')') {
                            text = '-' + text.substring(1, text.length - 1);
                        }
                        return text;
                    }

                    /**
                     Used when model is updated from the view i.e. user input
                     */
                    function toBig(text) {
                        if (text == null || text === '') {
                            /* Not needed since, $setValidaty will take care of this
                             * if(element.hasClass("ng-invalid")){
                                element.addClass("ng-valid");
                                element.removeClass("ng-invalid");
                            }*/
                            return null;
                        }

                        try {
                            text = convertToMinus(text);
                            ngModelCtlr.$setValidity('wfCurrencyValidity', true);
                            /* Not needed since, $setValidaty will take care of this
                             * if (!element.hasClass("ng-valid")){
                                element.addClass("ng-valid");
                                element.removeClass("ng-invalid");
                            }*/
                            text = text.replace(/[$,]/g, '');
                            if (currencyType === "Big") {
                                return Big(text);
                            } else if (currencyType == "Number") {
                            	if (Number(text) != Number(text)) {	// is NaN; should only occur if starting with initial '-'
                            		return undefined;
                            	} else {
                                return Number(text);
                            	}
                            } else {
                                return text;
                            }
                        } catch(err) {
                            ngModelCtlr.$setValidity('wfCurrencyValidity', false);
                            return undefined;
                        }
                    }

                    /**
                     Used when view is updated from the model
                     */
                    function toText(big) {
                        if (currencyType == undefined && big != null) {
                            currencyType = big.constructor.name;
                        }
                        else if (currencyType == undefined) {
                            currencyType = 'Number';
                        }
                        if (big != null) {
                            if (dp == null || dp === '') {
                                var amount = big;
                                if (currencyType === "Big") {
                                    amount = big.toString();
                                }
                                return $filter('currency')(amount, prefix);
                            }
                            else {
                                var filtered = big.toString();
                                if ((currencyType === 'Number' || currencyType === 'Big') &&
                                        (big.constructor.name === 'Big' || big.constructor.name === 'Number')) {
                                    var filtered = $filter('currency')(big.toFixed(dp), prefix);
                                    if (attr.wfNoCents != 'formatOnly' && dp === 0) {
                                        element.val(filtered.replace(/\...$/, ''));
                                    } else {
                                        element.val(filtered);
                                    }
                                    if (attr.wfNoCents != 'formatOnly' && dp === 0) {
                                       return filtered.replace(/\...$/, '');
                                    }
                                    
                                    return filtered;
                                }
                                else if ((currencyType === 'String' || big.constructor.name === 'String') && !isNaN(big)) {
                                    var value = parseFloat(big);
                                    return $filter('currency')(value.toFixed(dp), prefix);
                                }
                                return filtered;
                            }
                        }
                    }
                    ngModelCtlr.$parsers.push(toBig);
                    ngModelCtlr.$formatters.push(toText);

                    element.on("focus", function(event) {
                        var text = event.currentTarget.value.replace(/\s/g, '');
                        text = convertToMinus(text);
                        element.val(text);
                    });

                    var validateCurrency = function(value) {
                    	
                    	getDynamicModelValues();
                        if (value != null && value !== '') {
                           // var text = value.replace(/\s/g, '');
                            var text = convertToMinus(value);
                            text = text.replace(/[$,]/g, '');
                            //if (ngModelCtlr.$valid) {
                                var minMaxError = '';
                                try {
                                    var amount = parseFloat(text);
                                    if (minAmount != undefined && amount < minAmount) {
                                        throw("Amount is less than " + minAmount);
                                    }
                                    if (maxAmount != undefined && amount > maxAmount) {
                                        throw("Amount is greater than " + maxAmount);
                                    }
                                    if (dp != null && dp !== '') {
                                        var filtered = $filter('currency')(Number(text).toFixed(dp), prefix);
                                        // wfNoCents check decides if the 2 decimal format needs to be shown on the screen or not.
                                        if (attr.wfNoCents != 'formatOnly' && dp === 0) {
                                            element.val(filtered.replace(/\...$/, ''));
                                        } else {
                                            element.val(filtered);
                                        }
                                    }
                                    else {
                                        element.val($filter('currency')(Number(text)), prefix);
                                    }
                                }
                                catch(err) {
                                    /* Not needed since, $setValidaty will take care of this
                                     * element.removeClass("ng-valid");
                                    element.addClass("ng-invalid");*/
                                	if(!isHidden) {
                                    ngModelCtlr.$setValidity('wfCurrencyValidity', false);
                                    appendErrorMessage(scope.$eval(attr.wfErrorList), field, errorMsg);
                                	} else {
                                		ngModelCtlr.$setValidity('wfCurrencyValidity', true);
                                        removeErrorMessage(scope.$eval(attr.wfErrorList), field);
                                	}
                                    
                                    return;
                                }
                            //}
                        }
                        ngModelCtlr.$setValidity('wfCurrencyValidity', true);
                        removeErrorMessage(scope.$eval(attr.wfErrorList), field);
                    	
                    }
                    
                    element.on("blur", function(event) {
                    	var value = "";
                    	if (event.currentTarget.value != null && event.currentTarget.value !== '') {
                    		value = event.currentTarget.value.replace(/\s/g, '');
                    	}
                    	validateCurrency(value);
                    });

                    // Allow only these keys to be pressed
                    var validKeys = [
                        48, 96,   // 0
                        49, 97,   // 1
                        50, 98,   // 2
                        51, 99,   // 3
                        52, 100,  // 4
                        53, 101,  // 5
                        54, 102,  // 6
                        55, 103,  // 7
                        56, 104,  // 8
                        57, 105,  // 9
                        190, 110, // period
                        189, 109, // dash
                        52,       // $
                        188,      // comma
                        //86,       // v for Ctrl-v
                        67,       // c for Ctrl-c
                        88,       // x for Ctrl-x
                        8,        // backspace
                        9,        // tab
                        46,       // delete
                        35,       // end
                        36,       // home
                        37,       // left
                        38,       // up
                        39,       // right
                        40        // down
                    ];

                    function charCode2Char(code) {
                        switch (code) {
                            case 48:
                            case 96: return '0';
                            case 49:
                            case 97: return '1';
                            case 50:
                            case 98: return '2';
                            case 51:
                            case 99: return '3';
                            case 52:
                            case 100: return '4';
                            case 53:
                            case 101: return '5';
                            case 54:
                            case 102: return '6';
                            case 55:
                            case 103: return '7';
                            case 56:
                            case 104: return '8';
                            case 57:
                            case 105: return '9';
                            case 190:
                            case 110: return '.';
                            case 189:
                            case 109: return '-';
                            case 188: return ',';
                            case 86: return 'v';
                            case 67: return 'c';
                            case 88: return 'x';
                            default: return '%';
                        }
                    };

                    function getNumberParts(num) {
                        num = convertToMinus(num);
                        var index = num.indexOf(".");
                        var decimalPart = "";
                        var integerPart = "";
                        if (index > -1) {
                            decimalPart = num.substring(index + 1);
                            integerPart = num.substring(0, index);
                        } else {
                            integerPart = num;
                        }
                        // handle length of negative numbers
                        var negative = 0;
                        if (integerPart.indexOf('-') > -1) {
                            negative = 1;
                        }
                        return [negative, integerPart.replace(/[$,]/g, ''), decimalPart.replace(/[$,]/g, ''), index];
                    };

                    // ngModelCtrl.$setViewValue() doesn't set the ngModel variable like the AngularJS document claims.
                    // disabling Ctrl-v for now.
                    element.on('paste', function(event) {
                        var self = $(this);
                        var orig = self.val();
                        getDynamicModelValues();
                        setTimeout(function () {
                            var value = $(self).val().replace(/[^0-9\.\-]/g, '');
                            // console.log("orig: " + orig + " value: " + value);
                            var parts = getNumberParts(value);
                            var neg = parts[0];
                            var invalid = false;
                            var intPart = parts[1];
                            var decPart = parts[2];
                            if (integerDigits != null && intPart.length > integerDigits + neg) {
                                invalid = true;
                            }
                            else if (dp != null && decPart.length > dp) {
                                invalid = true;
                            }
                            if (invalid) {
                                value = orig;
                            }
                            ngModelCtlr.$setViewValue(value);
                            ngModelCtlr.$render();
                        });
                    });

                    element.on("keydown", function(event) {
                        var numPattern = new RegExp('[0-9]');
                        var charCode = event.which || event.keyCode;
                        var charStr = charCode2Char(charCode);
                        // console.log("Keypress: " + charStr + " keyCode: " + charCode);
                        var selectionStart = event.currentTarget.selectionStart;
                        var selectionEnd = event.currentTarget.selectionEnd;

                        if (validKeys.indexOf(charCode) === -1) {
                            event.preventDefault();
                            return;
                        }

                        // Only allow any Shift key press for dollar sign, parens and for tab navigation
                        if (event.shiftKey == true) {
                            if (charStr === '4') {
                                charStr = '$';
                            }
                            else if (charStr === '9') {
                                charStr = '(';
                            }
                            else if (charStr === '0') {
                                charStr = ')';
                            }
                            else if (charCode === 9) {
                            	;	// allow Shift-tab to navigate between fields
                            }
                            else {
                                event.preventDefault();
                                return;
                            }
                        }

                        if (event.ctrlKey == true) {
                            if (charStr === 'v' || charStr === 'c' || charStr === 'x') {
                                // Continue processing the Ctrl v,c,x
                            }
                            else {
                                event.preventDefault();
                                return;
                            }
                        }

                        // Check for valid minus sign placement.
                        if (charStr === '-') {
                        	if (selectionStart < selectionEnd) {
                            	var minusIdx = event.currentTarget.value.indexOf('-');
                                if (minusIdx > -1 && minusIdx >= selectionStart && minusIdx < selectionEnd) {
                                	; // noop - replacing minus w/ new minus; ok
                                } else {
                                event.preventDefault();
                                return;
                            }
                            }
                            else if (event.currentTarget.value[0] === '-' && event.currentTarget.textContent.length === 0) {  // minus sign already exists, and is not only char
                                event.preventDefault();
                                return;
                            }
                        }

                        // Check for valid decimal point placement
                        // Added logic to allow the period key if the existing period is highlighted.  CREG-12654
                        var idx = event.currentTarget.value.indexOf('.');
                        if (charStr === '.' && idx > -1) {
                            if (selectionStart < selectionEnd) {
                                if (! (idx >= selectionStart && idx < selectionEnd)) {
                            event.preventDefault();
                            return;
                        }
                            }
                            else {
                                event.preventDefault();
                                return;
                            }
                        }

                        // Check for c, x, v with Ctrl.
                        if ((charStr === 'c' || charStr === 'x' || charStr === 'v') && ! event.ctrlKey) {
                            event.preventDefault();
                            return;
                        }

                        // Check for valid integer length.
                        if ((integerDigits != null && integerDigits !== '') ||
                            (dp != null && dp !== '')) {
                            var inputValue = event.currentTarget.value;
                            var parts = getNumberParts(inputValue);
                            var negative = parts[0];
                            var integerPart = parts[1];
                            var decimalPart = parts[2];
                            var index = parts[3];
                            // Backspace deleting the decimal point
                            if (charCode == 8 && selectionStart > 0 && inputValue[selectionStart-1] === '.' &&
                                inputValue.length-1 > integerDigits + negative) {
                                event.preventDefault();
                                return;
                            }
                            // Delete key deleting the decimal point
                            if (charCode == 46 && selectionStart > 0 && inputValue[selectionStart] === '.' &&
                                inputValue.length-1 > integerDigits + negative) {
                                event.preventDefault();
                                return;
                            }

                            // Delete or backspaces is pressed while part of the input is highlighted
                            if (selectionStart < selectionEnd && (charCode == 8 || charCode == 46)) {
                                var periodIdx = inputValue.indexOf('.');
                                if (periodIdx > -1 && periodIdx > selectionStart && periodIdx < selectionEnd) {
                                    var newValue = inputValue.substring(0, selectionStart).replace('-', '') +
                                        inputValue.substring(selectionEnd);
                                    if (newValue.length > integerDigits) {
                                        event.preventDefault();
                                        return;
                                    }
                                }
                            }

                            if (numPattern.test(charStr) &&
                                selectionStart === selectionEnd) {
                                var invalid = false;
                                if (integerDigits != null && index > -1 && selectionStart < index+1 &&
                                    integerPart.length+1 > integerDigits + negative) {
                                    invalid = true;
                                } else if (dp != null && index > -1 && selectionStart > index &&
                                    decimalPart.length+1 > dp) {
                                    invalid = true;
                                }
                                else if (integerDigits != null && index == -1 && integerPart.length+1 > integerDigits + negative) {
                                    invalid = true;
                                }
                                if (invalid) {
                                    event.preventDefault();
                                }
                            } else {
                                ngModelCtlr.$setValidity('wfCurrencyValidity', true);
                                
                               /* Not needed since $setValidaty will take care of this
                                * if (!element.hasClass("ng-valid")){
                                    element.addClass("ng-valid");
                                    element.removeClass("ng-invalid");
                                }*/
                            }
                        }
                    });
                    
                    
                    var unregisterFormSubmit = scope.$on("formSubmitted", function(mass) {
        				var modelValue = ngModelCtlr.$modelValue;       				
                    	validateCurrency(String(modelValue));
        			});
        			
        			// unregister the watches on scope destroy
        			scope.$on("$destroy", function() {
        				unregisterFormSubmit();
                    });
                    
                    
                }
            }
        };
    }]);
/*
 * wfPercent directive
 * Usage
 *
 * <input type="text" ng-model="d1" wf-percent></input>
 *     or if you want to omit the percent sign suffix
 * <input type="text" ng-model="d1" wf-percent wf-no-suffix></input>
 *
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing wf.framework
    .directive('wfPercent', ['$filter', function($filter) {
        return {
            restrict: 'A',
            require: 'ngModel',
            compile: function(tElement, tAttrs) {
                if (tAttrs['placeholder'] == undefined) {
                    tElement.attr("placeholder", "%");
                }
                tAttrs.$addClass("percent");
                return function(scope, element, attr, ngModelCtlr) {

				var dp = 3;
				var integerDigits = 3;
				var minPercent;
                var maxPercent;
                var varType;

                var suffix = '%';
                /** Model Name to uniquely identify the element and default error message.*/
                var field = attr.ngModel;
                var errorMsg = "Invalid Number";

                /** if the error message is defined, then use that message instead of the default */
                if (attr.wfError != undefined) {
                    errorMsg = attr.wfError;
                }

                var conf = scope.$eval(attr.wfPercent);
                if (typeof conf == 'object') {
                    if (conf.decimal != null) {
                        dp = conf.decimal;
                    }
                    if (conf.integer != null) {
                        integerDigits = conf.integer;
                    }
                }

                if (attr.wfIntegerOnly != undefined) { //CREG-12250 to specify only allow integer values
                    dp = 0;
                }

                if (attr.wfNoSuffix != undefined) { //CREG-11745 to specify no suffix needed
                    suffix = '';
                }

                var getDynamicModelValues = function() {
                	/** if the error message is defined, then use that message instead of the default */
                    if (attr.wfError != undefined) {
                        errorMsg = attr.wfError;
                    }
                 // get the min and max allowable amounts.
                    if (attr.wfMinPercent != undefined && ! isNaN(attr.wfMinPercent)) {
                        minPercent = attr.wfMinPercent;
                    } else if (attr.wfMinPercent != undefined) {
                    	minPercent = scope.$eval(attr.wfMinPercent);
                    }
                    if (attr.wfMaxPercent != undefined && ! isNaN(attr.wfMaxPercent)) {
                        maxPercent = attr.wfMaxPercent;
                    } else if (attr.wfMaxPercent != undefined) {
                    	maxPercent = scope.$eval(attr.wfMaxPercent);
                    }
                }
                
                function convertToMinus(text) {
                    if (text[0] === '(' && text[text.length - 1] === ')') {
                        text = '-' + text.substring(1, text.length - 1);
                    }
                    return text;
                }

                function convertMinusToParen(text) {
	                if (tAttrs.wfPercent != "-") {
	                    if (text[0] === '-') {
	                        text = '(' + text.substring(1) + ')';
	                    }
	                }
                    return text;
                }

				/**
					Used when model is updated from the view i.e. user input
				*/
                function toBig(text) {
                    if (text == null || text === '') {
                        /*if(element.hasClass("ng-invalid")){
                            element.addClass("ng-valid");
                            element.removeClass("ng-invalid");
                        }*/
                        return null;
                    }

                    try {
                        ngModelCtlr.$setValidity('wfPercentValidity', true);
                        /* Not needed since, $setValidaty will take care of this
                        if (!element.hasClass("ng-valid")){
                            element.addClass("ng-valid");
                            element.removeClass("ng-invalid");
                        }*/
                        text = text.replace(/[%]/g, '');
                        if (varType === "Big") {
                            return Big(text);
                        } else if (varType == "Number") {
                        	if (Number(text) != Number(text)) {	// is NaN; should only occur if starting with initial '-'
                        		return undefined;
                        	} else {
                        		return Number(text);
                        	}
                        } else {
                            return text;
                        }
                    } catch(err) {
                        ngModelCtlr.$setValidity('wfPercentValidity', false);
                        return undefined;
                    }
                }

				/**
					Used when view is updated from the model
				*/
                function toText(big) {
                    if (varType == undefined && big != null) {
                        varType = big.constructor.name;
                    }
                    else if (varType == undefined) {
                        varType = 'Number';
                    }
                    if (big != null) {
                        if (dp == null || dp === '') {
                            var amount = big;
                            if (varType === "Big") {
                                amount = big.toString();
                            }
                            return convertMinusToParen($filter('number')(big.toString()) + suffix);
                        }
                        else {
                            var filtered = big.toString();
                            if ((varType === 'Number' || varType === 'Big') &&
                                    (big.constructor.name === 'Big' || big.constructor.name === 'Number')) {
                                return convertMinusToParen($filter('number')(big.toFixed(dp), dp) + suffix);
                            }
                            else if (varType === 'String' && big.constructor.name === 'String' && !isNaN(big)) {
                                var value = parseFloat(big);
                                return convertMinusToParen($filter('number')(value.toFixed(dp), dp) + suffix);
                            }
                            return filtered;
                        }
                    }
                    else {
                        return suffix;
                    }
                }

                ngModelCtlr.$parsers.push(toBig);
                ngModelCtlr.$formatters.push(toText);

                element.on("focus", function(event) {
                    var text = event.currentTarget.value.replace(/\s/g, '');
                    text = convertToMinus(text);
                    element.val(text);
                });

                var validatePercent = function(value) {
                	getDynamicModelValues();
                    if (value != null && value !== '') {
						//var text = event.currentTarget.value.replace(/\s/g, '');
                        var text = (value);
                        text = text.replace(/\%/g, '');
						//if (ngModelCtlr.$valid) {
							try {
								if (text === "-") {		// special handling for focus loss with only initial '-' 
									event.currentTarget.value = "";
								} else {
	                                var big = Big(text);
	                                if (minPercent != undefined && Number(text) < Number(minPercent)) {
	                                    throw("Percent is less than " + minPercent);
	                                }
	                                if (maxPercent != undefined && Number(text) > Number(maxPercent)) {
	                                    throw("Percent is greater than " + maxPercent);
	                                }
	                                
	                                
									if (dp != null && dp !== '') {
										element.val(convertMinusToParen($filter('number')(big.toFixed(dp), dp) + suffix));
									}
									else {
										element.val(convertMinusToParen($filter('number')(big.toString()) + suffix));
									}									
								}
							}
							catch(err) {
                                // Only add the error message if it is a non null invalid number.
                                if (text != undefined && text != null && text != '') {
                                    /*element.removeClass("ng-valid");
                                    element.addClass("ng-invalid");*/
                                    ngModelCtlr.$setValidity('wfPercentValidity', false);
                                    appendErrorMessage(scope.$eval(attr.wfErrorList), field, errorMsg);
                                } else {
                                	ngModelCtlr.$setValidity('wfPercentValidity', true);
                                    removeErrorMessage(scope.$eval(attr.wfErrorList), field);
                                }
                                return;
							}
                            ngModelCtlr.$setValidity('wfPercentValidity', true);
                            removeErrorMessage(scope.$eval(attr.wfErrorList), field);

                        //}
                    }
                }
                
                
                element.on("blur", function(event) {
                	var value = "";
                	if (event.currentTarget.value != null && event.currentTarget.value !== '') {
                		value = event.currentTarget.value.replace(/\s/g, '');
                	}
                	validatePercent(value);
                });

                // Allow only these keys to be pressed
                var validKeys = [
                    48, 96,   // 0
                    49, 97,   // 1
                    50, 98,   // 2
                    51, 99,   // 3
                    52, 100,  // 4
                    53, 101,  // 5
                    54, 102,  // 6
                    55, 103,  // 7
                    56, 104,  // 8
                    57, 105,  // 9
                    190, 110, // period
                    189, 109, // dash
                    //188,      // comma
                    //86,       // v for Ctrl-v
                    67,       // c for Ctrl-c
                    88,       // x for Ctrl-x
                    8,        // backspace
                    9,        // tab
                    46,       // delete
                    35,       // end
                    36,       // home
                    37,       // left
                    38,       // up
                    39,       // right
                    40       // down
                ];

                function charCode2Char(code) {
                    switch (code) {
                        case 48:
                        case 96: return '0';
                        case 49:
                        case 97: return '1';
                        case 50:
                        case 98: return '2';
                        case 51:
                        case 99: return '3';
                        case 52:
                        case 100: return '4';
                        case 53:
                        case 101: return '5';
                        case 54:
                        case 102: return '6';
                        case 55:
                        case 103: return '7';
                        case 56:
                        case 104: return '8';
                        case 57:
                        case 105: return '9';
                        case 190:
                        case 110: return '.';
                        case 189: return '-';
                        case 109: return '-';
                        case 188: return ',';
                        case 86: return 'v';
                        case 67: return 'c';
                        case 88: return 'x';
                        default: return '%';
                    }
                };

                function getNumberParts(num) {
                    num = convertToMinus(num);
                    var index = num.indexOf(".");
                    var decimalPart = "";
                    var integerPart = "";
                    if (index > -1) {
                        decimalPart = num.substring(index + 1);
                        integerPart = num.substring(0, index);
                    } else {
                        integerPart = num;
                    }
                    // handle length of negative numbers
                    var negative = 0;
                    if (integerPart.indexOf('-') > -1) {
                        negative = 1;
                    }
                    return [negative, integerPart.replace(/\%/g, ''), decimalPart.replace(/\%/g, ''), index];
                };

                // ngModelCtrl.$setViewValue() doesn't set the ngModel variable like the AngularJS document claims.
                // disabling Ctrl-v for now.
                element.on('paste', function(event) {
                    var self = $(this);
                    var orig = self.val();
                    setTimeout(function () {
                        var value = $(self).val().replace(/[^0-9\.\-]/g, '');
                        // console.log("orig: " + orig + " value: " + value);
                        var parts = getNumberParts(value);
                        var neg = parts[0];
                        var invalid = false;
                        var intPart = parts[1];
                        var decPart = parts[2];
                        if (integerDigits != null && intPart.length > integerDigits + neg) {
                            invalid = true;
                        }
                        else if (dp != null && decPart.length > dp) {
                            invalid = true;
                        }
                        if (invalid) {
                            value = orig;
                        }
                        ngModelCtlr.$setViewValue(value);
                        ngModelCtlr.$render();
                    });
                });

                element.on("keydown", function(event) {
                    var numPattern = new RegExp('[0-9]');
                    var charCode = event.which || event.keyCode;
                    var charStr = charCode2Char(charCode);
//                    console.log("Keypress: " + charStr + " keyCode: " + charCode);
                    var selectionStart = event.currentTarget.selectionStart;
                    var selectionEnd = event.currentTarget.selectionEnd;

                    if (validKeys.indexOf(charCode) === -1) {
                        event.preventDefault();
                        return;
                    }

                    // allow Shift-tab to navigate between fields
                    if (event.shiftKey == true) {
                        if (charStr === '5') {
                            charStr = '%';
                        } else if (charCode === 9) {
                        	;	// allow Shift-tab to navigate between fields
                        } else if (charStr === '9') {
                            charStr = '(';
                        }
                        else if (charStr === '0') {
                            charStr = ')';
                        } else {
	                        event.preventDefault();
	                        return;
                        }
                    }

                    if (event.ctrlKey == true) {
                        if (charStr === 'v' || charStr === 'c' || charStr === 'x') {
                            // do nothing and continue processing
                        }
                        else {
                            event.preventDefault();
                            return;
                        }
                    }

                    // Check for valid minus sign placement.
                    if (charStr === '-') {
                    	if (selectionStart < selectionEnd) {
                        	var minusIdx = event.currentTarget.value.indexOf('-');
                            if (minusIdx > -1 && minusIdx >= selectionStart && minusIdx < selectionEnd) {
                            	; // noop - replacing minus w/ new minus; ok
                            } else {
                            	event.preventDefault();
                                return;
                            }
                        }
                        else if (event.currentTarget.value[0] === '-' && event.currentTarget.textContent.length === 0) {  // minus sign already exists, and is not only char
                            event.preventDefault();
                            return;
                        }
                    }

                    // Check for valid decimal point placement
                    // Added logic to allow the period key if the existing period is highlighted.  CREG-12654
                    var idx = event.currentTarget.value.indexOf('.');
                    if (charStr === '.' && idx > -1) {
                        if (selectionStart < selectionEnd) {
                            if (! (idx >= selectionStart && idx < selectionEnd)) {
                                event.preventDefault();
                                return;
                            }
                        }
                        else {
                            event.preventDefault();
                            return;
                        }
                    }

                    // Check for c, x, v with Ctrl.
                    if ((charStr === 'c' || charStr === 'x' || charStr === 'v') && ! event.ctrlKey) {
                        event.preventDefault();
                        return;
                    }

                    // Check for valid integer length.
                    if ((integerDigits != null && integerDigits !== '') ||
                            (dp != null && dp !== '')) {
                        var inputValue = event.currentTarget.value;
                        var parts = getNumberParts(inputValue);
                        var negative = parts[0];
                        var integerPart = parts[1];
                        var decimalPart = parts[2];
                        var index = parts[3];
                        // Backspace deleting the decimal point
                        if (charCode == 8 && selectionStart > 0 && inputValue[selectionStart-1] === '.' &&
                            inputValue.length-1 > integerDigits + negative) {
                            event.preventDefault();
                            return;
                        }
                        // Delete key deleting the decimal point
                        if (charCode == 46 && selectionStart > 0 && inputValue[selectionStart] === '.' &&
                            inputValue.length-1 > integerDigits + negative) {
                            event.preventDefault();
                            return;
                        }

                        // Delete or backspaces is pressed while part of the input is highlighted
                        if (selectionStart < selectionEnd && (charCode == 8 || charCode == 46)) {
                            var periodIdx = inputValue.indexOf('.');
                            if (periodIdx > -1 && periodIdx > selectionStart && periodIdx < selectionEnd) {
                                var newValue = inputValue.substring(0, selectionStart).replace('-', '') +
                                    inputValue.substring(selectionEnd);
                                if (newValue.length > integerDigits) {
                                    event.preventDefault();
                                    return;
                                }
                            }
                        }

                        if (numPattern.test(charStr) &&
                                selectionStart === selectionEnd) {
                            var invalid = false;
                            if (integerDigits != null && index > -1 && selectionStart < index+1 &&
                                integerPart.length+1 > integerDigits + negative) {
                                invalid = true;
                            } else if (dp != null && index > -1 && selectionStart > index &&
                                decimalPart.length+1 > dp) {
                                invalid = true;
                            }
                            else if (integerDigits != null && index == -1 && integerPart.length+1 > integerDigits + negative) {
                                invalid = true;
                            }
                            if (invalid) {
                                event.preventDefault();
                            }
                        } else {
                            ngModelCtlr.$setValidity('wfPercentValidity', true);
                            /* Not needed since $setValidaty will take care of this
                            if (!element.hasClass("ng-valid")){
                                element.addClass("ng-valid");
                                element.removeClass("ng-invalid");
                            }*/
                        }
                    }
                });
                
                var unregisterFormSubmit = scope.$on("formSubmitted", function(mass) {
    				var modelValue = ngModelCtlr.$modelValue;  
    				if (modelValue != undefined && modelValue != null) {
    					validatePercent(String(modelValue));	
    				} else {
    					validatePercent(modelValue);
    				}
                	
    			});
    			
    			// unregister the watches on scope destroy
    			scope.$on("$destroy", function() {
    				unregisterFormSubmit();
                });
    			
            }
        }};
    }]);


angular.module('wf.framework')
.factory('FragmentChangeHelper', ['$templateCache', '$timeout', function($templateCache, $timeout) {
    return {
        setupFragmentHolder: function($scope) {
            if($scope.wfFragment == undefined || $scope.wfFragment == null) {
                $scope.wfFragment = {};
            }
        },
        changeFragment: function($scope, fragmentId, newFragment){
            if ($scope.wfFragment == null) {
                $scope.wfFragment = {};
            }
            var id = eval('$scope.wfFragment.'+ fragmentId);
            if (id != undefined && newFragment === id) {
                console.log("fragment " + fragmentId + "matched : " + newFragment);
                $templateCache.remove(newFragment);
                eval('$scope.wfFragment.'+fragmentId + '= \'\'');
                $timeout(function() {
                    eval('$scope.wfFragment.' + fragmentId + ' = newFragment');
                }, 0);
            } else {
                eval('$scope.wfFragment.' + fragmentId + ' = newFragment');
            }
        }
    }
}])

function appendErrorMessage(messagelist, field, errmsg, defaultList) {
	var isPresent = 0;
    if (messagelist == null) {
        return;
    }
	for(var i = messagelist.length - 1; i >= 0; i--){
		if(messagelist[i].id == field){
			isPresent = 1;
			/** if the error message for the field changed, 
			 * then delete the message from the current */
			if (messagelist[i].data != errmsg) {
				messagelist.splice(i,1);
				isPresent = 0;
		}
		}
		if(messagelist[i] != undefined && messagelist[i].id == undefined){
			messagelist.splice(i,1);
		}
		
	}
	if (isPresent == 0){
		messagelist.push(({id:field, data: errmsg}));
	}
	isPresent = 0;
	if (defaultList != undefined) {
		
		for(var i = defaultList.length - 1; i >= 0; i--){
			if(defaultList[i].id == field){
				isPresent = 1;
			}
			if(defaultList[i].id == undefined){
				defaultList.splice(i,1);
			}
			
		}
		if (isPresent == 0){
			defaultList.push(({id:field, data: errmsg}));
		}
		
	}
	
};

function removeErrorMessage(messagelist, field, defaultList) {
	if (messagelist == null) {
        return;
    }
	for(var i = messagelist.length - 1; i >= 0; i--){
		if(messagelist[i].id == field || messagelist[i].id == undefined){
			messagelist.splice(i,1);
		}
	}
	
	if (defaultList != undefined) {
		for(var i = defaultList.length - 1; i >= 0; i--){
			if(defaultList[i].id == field || defaultList[i].id == undefined){
				defaultList.splice(i,1);
			}
		}
	}
	
};

/**
 * scroll directive - used in header
 *
 * Created by Eugeniu Burianov
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
    .directive("scroll", ['$window', function ($window) {
        return function(scope, element, attrs) {
            angular.element($window).bind("scroll", function() {
                var oldVal = scope.changeClass;
                var scrollHeight = $('body').get(0).scrollHeight;
                var bodyHeight = $('body').height();
                var headerHeight = $('#top-nav-content').height()+$('#customer-header').height();

                if (this.pageYOffset >= 1) {
                    if(scrollHeight-headerHeight > bodyHeight + 1)
                        scope.changeClass = true;
                    else
                        scope.changeClass = false;
                } else {
                    scope.changeClass = false;
                }
                if (oldVal != scope.changeClass) {
                    scope.$digest();
                }
            });
        };
    }])
    .directive('wfKeepScroll', [ '$timeout', 'wfScrolls', function ($timeout, wfScrolls) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {

                //load scroll position after everything has rendered
                var scrollTimer = $timeout(function () {
                    var scrollKey = attrs.wfKeepScroll ? attrs.wfKeepScroll : 'defaultScrollKey';
                    var scrollY = wfScrolls.values[scrollKey];
                    $(window).scrollTop(scrollY ? scrollY : 0);
                }, 0);

                //save scroll position on change
                scope.$on("$stateChangeStart", function () {
                    var scrollKey = attrs.wfKeepScroll ? attrs.wfKeepScroll : 'defaultScrollKey';
                    wfScrolls.values[scrollKey] = $(window).scrollTop();
                });

                // Cleanup the scrollTimer
                element.on("$destroy", function () {
                    if (scrollTimer) {
                        $timeout.cancel(scrollTimer);
                    }
                });
            }
        }
    }]);

angular.module('wf.framework')
    .factory('wfScrolls', [
        function() {
            return {
                values: {},
                // Allow for the the resetting of the saved scroll value.
                resetValue: function(id) {
                    if (id) {
                        this.values[id] = null;
                    }
                    else if (id === undefined) {
                        this.values = {};
                    }
                }
            };
        }
    ]);
/**
 * Created by u111378 on 2/10/15.
 */
angular.module('wf.framework')
    .directive('wfElementsDisable', ['$compile', function($compile){
        return {
            link: function ($scope, elm, attrs, ngModel) {
                var isDisable = true;
                if (attrs.wfElementsDisable != undefined
                    && attrs.wfElementsDisable.length > 0) {
                    isDisable = $scope.$eval(attrs.wfElementsDisable);
                }

				var targetId = attrs.id;
                if (attrs.targetId != undefined) {
                  targetId = attrs['targetId'];
                }
				
                var removeAllSecureClassesFunction = function(index, css) {
                    return (css.match(/\bwf-secure-element\S+/g) || []).join(' ');
                };

                var disableAllChildren = function(el) {

                    var childElements = null;

                    if (el!= undefined && el){
                        childElements = el.children;
                    } else {
						if (document.getElementById(targetId)) {
							childElements = document.getElementById(targetId).children;
						}
                    }

                    angular.forEach(childElements, function(e){
                        if (angular.element(e).is("input,textarea,select,button,a")) {
                            angular.element(e).removeAttr('ng-disabled')
                                .removeAttr('ng-enabled')
                                .removeClass(removeAllSecureClassesFunction)
                                .attr('disabled', true)
                                .attr('ng-disabled', true);
                            if (angular.element(e).is("a")) {
                                angular.element(e).unbind()
                                    .removeAttr("href")
                                    .removeAttr("ng-click");
                            }
                            var fn = $compile(e);
                            fn($scope);
                        } else {
                            disableAllChildren(e);
                        }

                    });
                }

                if(isDisable){
                    disableAllChildren();
                }

            }
        }
    }]);
/**
 * wfFilter directive
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
    .directive("wfFilter", function() {
        //This directive will be used for the filter attribute in siriusforce
        //textbox and textarea widgets
        //This directive adds a keypress event to the textbox/textarea control which
        //checks if the character typed in matches the regex and if not then call
        //event.preventDefault
        //Sample Usage:
        //<input type="text" ng-model="homePhoneNumberTextBox" wf-filter="[0-9\-]"></input>
        return {
            restrict: 'A',
            replace: false,
            link: function(scope, element, attrs, controller) {
                var charPattern = new RegExp(attrs.wfFilter);
                var stringPattern = new RegExp('^('+attrs.wfFilter+')*$');
                element.on('keypress', function(event) {
                    var charCode = event.which || event.keyCode;
                    var charStr = String.fromCharCode(charCode);
                    if (!charPattern.test(charStr)) {
                        event.preventDefault();
                    }
                });
                element.on('paste', function(event) {
                    var charStr = event.originalEvent.clipboardData.getData("text").toString().trim();
                    charStr=charStr.replace(/[\n\r]+/g, '');
                    if (!stringPattern.test(charStr)) {
                        event.preventDefault();
                    }
                });
            }
        }
    });


/**
 * wfFragment directive
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
    .directive('wfFragment', ['FragmentChangeHelper', function(FragmentChangeHelper) {
        return {
            restrict: 'E',
            scope: false,
            replace: false,
            transclude: false,
            compile: function(element, attr, scope) {
                element.html("<ng-include src='wfFragment." + attr.id + "'/>");
                return function($scope, element, attr) {
                	FragmentChangeHelper.setupFragmentHolder($scope);
                    eval("if (!$scope.wfFragment.hasOwnProperty('"+ attr.id + "')) { $scope.wfFragment." + attr.id + "='" + attr.include + "'}");
                   // FragmentChangeHelper.changeFragment($scope, attr.id, attr.include);
                };
            }
        };
    }]);

/**
 * wfIf directive
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
    .directive('wfIf', ['$animate', function($animate) {
        return {
            transclude: 'element',
            priority: 600,
            terminal: true,
            restrict: 'A',
            $$tlb: true,
            link: function ($scope, $element, $attr, ctrl, $transclude) {
                var block;
                if ($scope.$eval($attr.wfIf)) {
                    $transclude($scope, function (clone) {
                        clone[clone.length++] = document.createComment(' end wfIf: ' + $attr.wfIf + ' ');
                        block = {
                            clone: clone
                        };
                        $animate.enter(clone, $element.parent(), $element);
                    });
                } else {
                    if (block) {
                        $animate.leave(getBlockElements(block.clone));
                        block = null;
                        }
                    }
                }
            }
    }]);

/**
 * Created by U318690 on 3/21/14.
 *
 * These directives relate to UI Security.
 *
 * wfSecure examines the permission as provided by the securityService to
 * determine whether to remove the element from the DOM (DENY),
 * disable the element (READ) or allow full access (EDIT).
 */


var totalTime = 0;
var resetTime = function(){
    var time = totalTime;
    totalTime = 0;
    return time;
}
angular.module('wf.framework')
    .directive('wfSecurity', ['wfSecurityService', '$log', '$rootScope', function(securityService, $log, $rootScope) {
        var removeAllSecureClassesFunction = function(index, css) {
            return (css.match(/\bwf-secure-element\S+/g) || []).join(' ');
        };
        var runSecurity = function(namespace, elem, attrs) {
            if($rootScope.wfSecurityEnabled === false){
                return;
            }
            var startDate = new Date();
            var inherited = !attrs.wfSecurity;
            var elementsWithIds = elem.find("[id]");
            angular.forEach(elementsWithIds, function(e) {
                // getPermission should return one of following:
                // 'DENY' : user should not be able to see
                // 'READ' : user can see but not edit
                // 'EDIT' : user can see and edit
                // false  : no permission defined for namespace/element, SKIP
                var permissionObj = securityService.getElementPermission(namespace, e.id);
                var permission = permissionObj;
                var securityRule = null;
                if (permissionObj && angular.isObject(permissionObj)) {
                    permission = permissionObj.action;
                    securityRule = permissionObj.condition;
                }
                var securityInfo;
                if ($rootScope.securityHelperEnabled) {
                    if (!$rootScope.securityInfo[namespace]){
                        $rootScope.securityInfo[namespace] = [];
                    }
                    securityInfo = {
                        elementId: e.id,
                        permission: permission,
                        inheritedNamespace: inherited,
                        appliedSecurityRule : securityRule !== null ? securityRule : null
                    }
                }
                if (permission) {
                    switch(permission)
                    {
                        case "DENY":
                            if($rootScope.securityHelperEnabled) {
                                var deletedChildren = angular.element(e).find("input,textarea,select,button");
                                securityInfo.childElements = [];
                                angular.forEach(deletedChildren, function(child) {
                                    securityInfo.childElements.push(child.id);
                                });
                            }
                            //angular.element(e).unbind();
                            angular.element(e).remove();
                            break;
                        case "READ":
                            var readOnlyChildren = angular.element(e).find("input,textarea,select,button");
                            readOnlyChildren.removeAttr('ng-disabled')
                            				.removeAttr('ng-enabled')
                            				.attr('disabled',true)
                                .removeClass(removeAllSecureClassesFunction)
                                .addClass('wf-secure-element wf-secure-element-read');
                            if($rootScope.securityHelperEnabled) {
                                securityInfo.childElements = [];
                                angular.forEach(readOnlyChildren, function(child) {
                                    securityInfo.childElements.push(child.id);
                                });
                            }
                            // test element itself to see if it needs to be disabled
                            if (angular.element(e).is("input,textarea,select,button,a")) {
                                angular.element(e).removeAttr('ng-disabled')
                								  .removeAttr('ng-enabled')
                								  .attr('disabled', true)
                                    .removeClass(removeAllSecureClassesFunction)
                                    .addClass('wf-secure-element wf-secure-element-read');
                                //If its a link disable all existing click handlers
                                if (angular.element(e).is("a")) {
                                    angular.element(e).unbind();
                                }
                            }
                            break;
                        case "EDIT":
                            var editChildren = angular.element(e).find("input,textarea,select,button");
                            editChildren.removeClass(removeAllSecureClassesFunction)
                                .addClass('wf-secure-element wf-secure-element-edit');
                            if($rootScope.securityHelperEnabled) {
                                securityInfo.childElements = [];
                                angular.forEach(editChildren, function(child) {
                                    securityInfo.childElements.push(child.id);
                                });
                            }
                            // test element itself to see if it needs to be disabled
                            if (angular.element(e).is("input,textarea,select,button")) {
                                angular.element(e).removeClass(removeAllSecureClassesFunction)
                                    .addClass('wf-secure-element wf-secure-element-edit');
                            }
                            break;
                        default:
                            $log.error("Permission ["+permission+"] unrecognized element ["+namespace+":"+ e.id+"]");
                    }
                } else {
                    /*noPermissionChildren.removeClass(removeAllSecureClassesFunction)
                     .addClass('wf-secure-element wf-secure-element-none');*/
                    if($rootScope.securityHelperEnabled) {
                        var noPermissionChildren = angular.element(e).find("input,textarea,select,button");
                        securityInfo.childElements = [];
                        angular.forEach(noPermissionChildren, function(child) {
                            securityInfo.childElements.push(child.id);
                        });
                    }
                    // test element itself to see if it needs to be disabled
                    /*if (angular.element(e).is("input,textarea,select,button")) {
                     angular.element(e).removeClass(removeAllSecureClassesFunction)
                     .addClass('wf-secure-element wf-secure-element-none');
                     }*/
                }
                if ($rootScope.securityHelperEnabled) {
                    $rootScope.securityInfo[namespace].push(securityInfo);
                }
                var endDate = new Date();
                totalTime += endDate.getTime() - startDate.getTime();
            });
        };
        return {
            restrict: 'A',
            scope: false,
            compile: function(elem, attrs){
                if (attrs.wfSecurity && attrs.wfSecurity.indexOf('{{') === -1) {
               		runSecurity(attrs.wfSecurity.replace(/\.[\d\w]+\.html/, '\.html'), elem, attrs);
                }
                return {
                    pre: function preLink(scope, elem, attrs){
                        if (attrs.wfSecurity) {
                            scope.namespace = attrs.wfSecurity.replace(/\.[\d\w]+\.html/, '\.html');
                        }
                    },
                    post: function(scope, elem, attrs) {
                        if (!attrs.wfSecurity) {
                            runSecurity(scope.namespace, elem, attrs);
                        } else {
                        	runSecurity(attrs.wfSecurity.replace(/\.[\d\w]+\.html/, '\.html'), elem, attrs);
                        }
                    }
                }
            }
        }
    }]);

/**
 * Created by Sudipta Sarkar on 3/6/14.
 * This file contains directives that adds a title attribute (tooltip) for some(icon-question-sign, icon-edit, icon-remove)
 * of the font-awesome icons.
 */



angular.module('wf.framework')
    .directive('iconQuestionSign', function () {
        return {
            restrict: 'C',
            link: function ($scope, element, attrs, controller) {
                element.attr('title', 'Help');
            }
        };
    })
    .directive('iconEdit', function () {
        return {
            restrict: 'C',
            link: function ($scope, element, attrs, controller) {
                element.attr('title', 'View/Edit');
            }
        };
    })
    .directive('iconRemove', function () {
        return {
            restrict: 'C',
            link: function ($scope, element, attrs, controller) {
                element.attr('title', 'Delete');
            }
        };
    });

/**
 * formatCurrency directive
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing wf.framework
    .directive('formatCurrency', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function($scope, element, attrs) {
                element.on("blur", function(inputValue) {
                    var source = event.target || event.srcElement;
                    var inputValue = source.value;
                    var transformedInput = inputValue;
                    if (inputValue !== null && inputValue.length > 0) {
                        var dotIndex = inputValue.indexOf(".");
                        var decimalPart = "";
                        var intPart = "";
                        if (dotIndex >= 0) {
                            decimalPart = inputValue.substring(dotIndex + 1);
                            intPart = inputValue.substring(0, dotIndex);
                        } else {
                            decimalPart = "00";
                            intPart = inputValue;
                        }
                        var allowableDecimalPoints = 2 - decimalPart.length;
                        if (allowableDecimalPoints > 0) {
                            while (allowableDecimalPoints > 0) {
                                decimalPart = decimalPart + "0";
                                allowableDecimalPoints--;
                            }
                        }
                        if (intPart == "") {
                            intPart = "0";
                        }
                        transformedInput = intPart + "." + decimalPart;
                    }
                    if (transformedInput != inputValue && inputValue != "") {
                        element.val(transformedInput);
                        $scope.$apply();
                    }
                    return transformedInput;
                });
            }
        };
    });

/**
 * wfDecimalpoints
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing wf.framework
    /*Usage
     * <input maxlength="10" type="text" ng-model="rent" format-decimalpoints="3"></input>
     */
    .directive('formatDecimalpoints', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            scope: {
                decimalpoints: '='
            },
            link: function($scope, element, attrs) {
                element.bind("blur", function(inputValue) {
                    var source = event.target || event.srcElement;
                    var inputValue = source.value;
                    var ReplacedInput = inputValue;
                    var allowableDecimalPoints = $scope.$eval(attrs.formatDecimalpoints);
                    if (inputValue !== null && inputValue.length > 0) {
                        var index = inputValue.indexOf(".");
                        var decimalPart = "";
                        var integerPart = "";
                        if (index > -1) {
                            decimalPart = inputValue.substring(index + 1);
                            integerPart = inputValue.substring(0, index);
                        } else {
                            decimalPart = "00";
                            integerPart = inputValue;
                        }
                        allowableDecimalPoints = allowableDecimalPoints - (decimalPart.length);
                        if (allowableDecimalPoints < 0) {
                            while (allowableDecimalPoints < 0) {
                                decimalPart = decimalPart.substring(0, decimalPart.length - 1);
                                allowableDecimalPoints++;
                            }
                        } else {
                            while (allowableDecimalPoints > 0) {
                                decimalPart = decimalPart + "0";
                                allowableDecimalPoints--;
                            }
                        }
                        ReplacedInput = integerPart + "." + decimalPart;
                        element.val(ReplacedInput);
                        $scope.$apply();
                    }
                });
            }
        };
    });

/**
 * formatItin directive
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing wf.framework
    .directive('formatItin', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function($scope, element, attrs) {
                element.bind("focus", function() {
                    var intialVal = element.val();
                    var temp;
                    if (intialVal != null && intialVal.length >= 9) {
                        element.val(temp.substring(intialVal, 0, 1));
                        if (temp != 9) {
                            element.val(false);
                            $scope.$apply();
                        } else {
                            element.val(temp.substring(intialVal, 3, 5));
                            if (temp < 70 || temp > 99) {
                                element.val(false);
                                $scope.$apply();
                            }
                        }
                    } else {
                        element.val(false);
                        $scope.$apply();
                    }
                });
            }
        }
    });

/**
 * formatPhoneNumber directive
 *
 * Created by U062274 on 11/19/13.
 * Modified by U111378 on 03/05/2014
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing wf.framework
    .directive('formatPhoneNumber', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function($scope, element, attrs, ctrl) {
                var field = attrs.ngModel;
                var errorMsg = "This is not a valid Phone Number.";
                var currentState = true;
                var regexForPhone = /^(\d{3}-?\d{3}-?\d{4}|XXX-XXX-XXXX)$/;

                attrs.$set("maxlength", 12);
                if (attrs.wfError != undefined) {
                    errorMsg = attrs.wfError;
                }

                var validatePhoneNumber = function(value, isValid, isSubmitted) {
                    var isHidden = false;
                	if(attrs.ngHide != undefined && $scope.$eval(attrs.ngHide)){
                		isHidden = true;
                	}
                    if(isSubmitted && value != undefined && value != "" && !isHidden) {
                        if(isValid) {
                            ctrl.$setValidity('formatToPhone', true);
                            removeErrorMessage($scope.$eval(attrs.wfErrorList),
                                field, $scope.$eval("errorMessages"));
                        } else {
                            ctrl.$setValidity('formatToPhone', false);
                            appendErrorMessage($scope.$eval(attrs.wfErrorList),
                                field, errorMsg, $scope.$eval("errorMessages"));
                        }
                    } else {
                        ctrl.$setValidity('formatToPhone', true);
                        removeErrorMessage($scope.$eval(attrs.wfErrorList),
                            field, $scope.$eval("errorMessages"));
                    }

                }

                ctrl.$setValidity('formatToPhone', true);

                ctrl.$parsers.unshift(function(value) {
                    value = ctrl.$viewValue;
                    var valid = regexForPhone.test(value);
                    if(valid) {
                        value = value.substring(0,3)+'-'+ value.substring(3,6)+'-'+ value.substring(6);
                        //ctrl.$viewValue = value;
                    }

                    //ctrl.$render();
                    //$scope.$apply();

                    return value;
                });

                ctrl.$formatters.unshift(function(value) {
                    value = ctrl.$modelValue;

                    if(value) {
                        value = value.replace(/[^0-9]/g, '');
                        value = value.replace(/-/g, '');
                        //ctrl.$setViewValue(value);
                        //ctrl.$modelValue = value;
                    }

                    if(value && value.length == 10) {
                        value = value.substring(0,3)+'-'+ value.substring(3,6)+'-'+ value.substring(6);
                    }

                    return value;
                });

                element.on("focus", function(inputValue) {
                    var re = new RegExp('-', 'g');
                    var tempVal = ctrl.$modelValue;
                    if (tempVal != undefined) {
                        element.val(tempVal.replace(re, ''));
                    }
                    $scope.$apply();

                    var value = ctrl.$viewValue;
                    currentState = ctrl.$valid;
                    ctrl.$setValidity('formatPhoneNumber', true);
                });

                element.on("blur", function(inputValue) {
                    var viewValue = ctrl.$viewValue;
                    var valid = regexForPhone.test(viewValue);

                    if (currentState == false) {
                        validatePhoneNumber(viewValue, valid, true);
                    } else {
                        validatePhoneNumber(viewValue, valid, false);
                    }
                    var re = new RegExp('-', 'g');
                    if (viewValue != undefined) {
                        element.val(viewValue.replace(re, ''));
                        viewValue = viewValue.replace(re, '');
                        ctrl.$setViewValue(viewValue);
                    }
                    if( viewValue!= undefined && viewValue.length == 10) {
                        element.val(viewValue.substring(0,3)+'-'+ viewValue.substring(3,6)+'-'+ viewValue.substring(6));
                        $scope.$apply();
                    }

                });

                var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
                    var modelValue = ctrl.$modelValue;

                    var valid = regexForPhone.test(modelValue);

                    validatePhoneNumber(modelValue, valid, true);
                });

                // unregister the watches on scope destroy
                $scope.$on("$destroy", function() {
					ctrl.$setValidity('formatToPhone', true);
					removeErrorMessage($scope.$eval(attrs.wfErrorList),
						field, $scope.$eval("errorMessages"));
                    unregisterFormSubmit();
                });

            }
        }
    });
/**
 * formatSsn directive
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing wf.framework
    .directive("formatSsn", function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function($scope, element, attrs) {
                element.bind("focus", function() {
                    var intialVal = new RegExp('-', 'g');
                    var tempVal = element.val();
                    if (tempVal != undefined) {
                        element.val(tempVal.replace(intialVal, ''));
                    }
                    attrs.$set("maxlength", 9);
                    $scope.$apply();
                });
                element.bind("blur", function(event) {
                    var source = event.target || event.srcElement;
                    var inputValue = source.value;
                    var tempVal = inputValue;
                    if (tempVal != undefined && tempVal.length == 9) {
                        attrs.$set("maxlength", 11);
                        element.val(tempVal.substring(0, 3) + '-' + tempVal.substring(3, 5) + '-' + tempVal.substring(5));
                        return element.val();
                        $scope.$apply();
                    }
                });
            }
        };
    });

/**
 * acceptCurrentDate directive
 *
 * Created by U486992 on 06/20/16.
 */


angular.module('wf.framework')
.directive("wfAcceptCurrentDate", ['$log', function ($log) {
    return {
        require: '?ngModel',
        link: function ($scope, elm, attrs, ngModel) {
            	var theDate;
            	/** Model Name to uniquely identify the element and default error message.*/
            	var field = attrs.ngModel;
            	var errorMsg = "Invalid Current Date";
            	var dateOperator = "+";
            	var year = "00";
            	var month = "00";
            	var day = "00";
            	
            	/** if the error message is defined, then use that message instead of the default */
            	if (attrs.wfError != undefined) {
                	errorMsg = attrs.wfError;
                }
            	
            	var getUpdatedDate = function(myDate, updateToAttr) {
            		
            		// it expects +00Y00M00D or -00Y00M00D format 
            		//            0123456789
            		if(updateToAttr.length == 10 && (updateToAttr.substring(0,1) == "+" || updateToAttr.substring(0,1) == "-" ) ){
            			dateOperator = updateToAttr.substring(0,1);
            			year = updateToAttr.substring(1,3);
            			month = updateToAttr.substring(4,6);
            			day = updateToAttr.substring(7,9);
            			if(dateOperator == "+") {
            				myDate.setDate(myDate.getDate() + parseInt(day));
            				myDate.setMonth(myDate.getMonth() + parseInt(month));
            				myDate.setFullYear(myDate.getFullYear() + parseInt(year));
                		}
            			if(dateOperator == "-") {
            				myDate.setDate(myDate.getDate() - parseInt(day));
            				myDate.setMonth(myDate.getMonth() - parseInt(month));
            				myDate.setFullYear(myDate.getFullYear() - parseInt(year));
                		} 
            		} else {
            			myDate = $scope.$eval(updateToAttr);
            		}
            		
            		return myDate;
            		
            	}
            	
        	var validateDate = function(value, submitted) {
            	var valid = true;
            	var today = new Date();
            	var minDate = new Date();
            	var maxDate = new Date();
            	var isHidden = false;
            	
            	if (attrs.ngHide != undefined && $scope.$eval(attrs.ngHide)) {
            		isHidden = true;
				}
            	
            	if(typeof value == "string") {
            		theDate = Date.parse(value);
            	} else {
            		theDate = value;
            	}
            	if(value != undefined && value != null && submitted == true) {
    	            	// Check if the future data satisfies the minimum Date Requirement
    	            	if (attrs.wfMinDate != undefined){
    	            		minDate = getUpdatedDate(minDate, attrs.wfMinDate);
    	            		if(minDate != undefined && theDate <= minDate) {
    		            		valid = false;
    	            		}
    	            	} 
    	            	// Check if the future data satisfies the maximum Date Requirement
    	            	if (attrs.wfMaxDate != undefined){
    	            		maxDate = getUpdatedDate(maxDate, attrs.wfMaxDate);
    	            		if(maxDate != undefined && theDate >= maxDate) {
    		            		valid = false;
    	            		}
    	            	}
    	            		
    	            	if(valid == false && isHidden == false) {
    	            		ngModel.$setValidity(field, false);
    	                	if(attrs.wfErrorList != undefined) {
    	                		appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);
    	                	}
    	            		return theDate;
    	            	}
    	            	today.setHours(0,0,0,0)
    	                if (valid == true && theDate == today && theDate != null && isHidden == false) {
    	                	ngModel.$setValidity(field, false);
    	                	if(attrs.wfErrorList != undefined) {
    	                		appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);
    	                	}
    	                    return theDate;
    	                }
    	                
    	                ngModel.$setValidity(field, true);
    	                if(attrs.wfErrorList != undefined) {
    	                	removeErrorMessage($scope.$eval(attrs.wfErrorList), field);
    	                }
    	                
    	                return theDate;
            	} else {
            		ngModel.$setValidity(field, true);
            		if(attrs.wfErrorList != undefined) {
	                	removeErrorMessage($scope.$eval(attrs.wfErrorList), field);
	                }
            	}
            	
            }
        	
        	var validationOnViewChange = function(value){
				
				validateDate(value);
				
				return value;
			};

			var validationOnModelChange = function(value){
				
				validateDate(value);
				
				return value;
			};
			
			ngModel.$parsers.unshift(validationOnViewChange);
			ngModel.$formatters.unshift(validationOnModelChange);
			
			elm.on("blur", function(inputValue) {
				var value = ngModel.$modelValue;
				
				validateDate(value);
				
			});
			
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				var modelValue = ngModel.$modelValue;
				
				validateDate(modelValue, true);
			});
			
			// unregister the watches on scope destroy
			$scope.$on("$destroy", function() {
				unregisterFormSubmit();
            });
        	
        }
        

    };

}]);
/**
 * acceptFutureDate directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive("wfAcceptFutureDate", ['$log', function ($log) {
    return {
        require: '?ngModel',
        link: function ($scope, elm, attrs, ngModel) {
            	var theDate;
            	/** Model Name to uniquely identify the element and default error message.*/
            	var field = attrs.ngModel;
            	var errorMsg = "Invalid Future Date";
            	var dateOperator = "+";
            	var year = "00";
            	var month = "00";
            	var day = "00";
            	
            	/** if the error message is defined, then use that message instead of the default */
            	if (attrs.wfError != undefined) {
                	errorMsg = attrs.wfError;
                }
            	
            	var getUpdatedDate = function(myDate, updateToAttr) {
            		
            		// it expects +00Y00M00D or -00Y00M00D format 
            		//            0123456789
            		if(updateToAttr.length == 10 && (updateToAttr.substring(0,1) == "+" || updateToAttr.substring(0,1) == "-" ) ){
            			dateOperator = updateToAttr.substring(0,1);
            			year = updateToAttr.substring(1,3);
            			month = updateToAttr.substring(4,6);
            			day = updateToAttr.substring(7,9);
            			if(dateOperator == "+") {
            				myDate.setDate(myDate.getDate() + parseInt(day));
            				myDate.setMonth(myDate.getMonth() + parseInt(month));
            				myDate.setFullYear(myDate.getFullYear() + parseInt(year));
                		}
            			if(dateOperator == "-") {
            				myDate.setDate(myDate.getDate() - parseInt(day));
            				myDate.setMonth(myDate.getMonth() - parseInt(month));
            				myDate.setFullYear(myDate.getFullYear() - parseInt(year));
                		} 
            		} else {
            			myDate = $scope.$eval(updateToAttr);
            		}
            		
            		return myDate;
            		
            	}
            	
        	var validateDate = function(value, submitted) {
            	var valid = true;
            	var today = new Date();
            	var minDate = new Date();
            	var maxDate = new Date();
            	var isHidden = false;
            	
            	if (attrs.ngHide != undefined && $scope.$eval(attrs.ngHide)) {
            		isHidden = true;
				}
            	
            	if(typeof value == "string") {
            		theDate = Date.parse(value);
            	} else {
            		theDate = value;
            	}
            	if(value != undefined && value != null && submitted == true) {
    	            	// Check if the future data satisfies the minimum Date Requirement
    	            	if (attrs.wfMinDate != undefined){
    	            		minDate = getUpdatedDate(minDate, attrs.wfMinDate);
    	            		if(minDate != undefined && theDate <= minDate) {
    		            		valid = false;
    	            		}
    	            	} 
    	            	// Check if the future data satisfies the maximum Date Requirement
    	            	if (attrs.wfMaxDate != undefined){
    	            		maxDate = getUpdatedDate(maxDate, attrs.wfMaxDate);
    	            		if(maxDate != undefined && theDate >= maxDate) {
    		            		valid = false;
    	            		}
    	            	}
    	            		
    	            	if(valid == false && isHidden == false) {
    	            		ngModel.$setValidity(field, false);
    	                	if(attrs.wfErrorList != undefined) {
    	                		appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);
    	                	}
    	            		return theDate;
    	            	}
    	            	today.setHours(0,0,0,0)
    	                if (valid == true && theDate < today && theDate != null && isHidden == false) {
    	                	ngModel.$setValidity(field, false);
    	                	if(attrs.wfErrorList != undefined) {
    	                		appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);
    	                	}
    	                    return theDate;
    	                }
    	                
    	                ngModel.$setValidity(field, true);
    	                if(attrs.wfErrorList != undefined) {
    	                	removeErrorMessage($scope.$eval(attrs.wfErrorList), field);
    	                }
    	                
    	                return theDate;
            	} else {
            		ngModel.$setValidity(field, true);
            		if(attrs.wfErrorList != undefined) {
	                	removeErrorMessage($scope.$eval(attrs.wfErrorList), field);
	                }
            	}
            	
            }
        	
        	var validationOnViewChange = function(value){
				
				validateDate(value);
				
				return value;
			};

			var validationOnModelChange = function(value){
				
				validateDate(value);
				
				return value;
			};
			
			ngModel.$parsers.unshift(validationOnViewChange);
			ngModel.$formatters.unshift(validationOnModelChange);
			
			elm.on("blur", function(inputValue) {
				var value = ngModel.$modelValue;
				
				validateDate(value);
				
			});
			
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				var modelValue = ngModel.$modelValue;
				
				validateDate(modelValue, true);
			});
			
			// unregister the watches on scope destroy
			$scope.$on("$destroy", function() {
				unregisterFormSubmit();
            });
        	
        }
        

    };

}]);
/**
 * acceptPastDate directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive("wfAcceptPastDate", ['$log', function ($log) {
    return {
        require: '?ngModel',
        link: function ($scope, elm, attrs, ngModel) {
            	var theDate;
            	/** Model Name to uniquely identify the element and default error message.*/
            	var field = attrs.ngModel;
            	var errorMsg = "Invalid Past Date";
            	var dateOperator = "+";
            	var year = "00";
            	var month = "00";
            	var day = "00";
            	
            	/** if the error message is defined, then use that message instead of the default */
            	if (attrs.wfError != undefined) {
                	errorMsg = attrs.wfError;
                }
            	
            	
            	
            	var getUpdatedDate = function(myDate, updateToAttr) {
            		
            		// it expects +00Y00M00D or -00Y00M00D format 
            		//            0123456789
            		if(updateToAttr.length == 10 && (updateToAttr.substring(0,1) == "+" || updateToAttr.substring(0,1) == "-" ) ){
            			dateOperator = updateToAttr.substring(0,1);
            			year = updateToAttr.substring(1,3);
            			month = updateToAttr.substring(4,6);
            			day = updateToAttr.substring(7,9);
            			if(dateOperator == "+") {
            				myDate.setDate(myDate.getDate() + parseInt(day));
            				myDate.setMonth(myDate.getMonth() + parseInt(month));
            				myDate.setFullYear(myDate.getFullYear() + parseInt(year));
                		}
            			if(dateOperator == "-") {
            				myDate.setDate(myDate.getDate() - parseInt(day));
            				myDate.setMonth(myDate.getMonth() - parseInt(month));
            				myDate.setFullYear(myDate.getFullYear() - parseInt(year));
                		} 
            		} else {
            			myDate = $scope.$eval(updateToAttr);
            		}
            		
            		return myDate;
            		
            	}

            var validateDate = function(value, submitted) {
            	var valid = true;
            	var today = new Date();
            	var minDate = new Date();
            	var maxDate = new Date();
            	var isHidden = false;
            	
            	if (attrs.ngHide != undefined && $scope.$eval(attrs.ngHide)) {
            		isHidden = true;
				}
            	if(typeof value == "string") {
            		theDate = Date.parse(value);
            	} else {
            		theDate = value;
            	}
            	
            	if(value != undefined && value != null && submitted == true) {
    	            	// Check if the future data satisfies the minimum Date Requirement
    	            	if (attrs.wfMinDate != undefined){
    	            		minDate = getUpdatedDate(minDate, attrs.wfMinDate);
    	            		if(minDate != undefined && theDate <= minDate) {
    		            		valid = false;
    	            		}
    	            	} 
    	            	// Check if the future data satisfies the maximum Date Requirement
    	            	if (attrs.wfMaxDate != undefined){
    	            		maxDate = getUpdatedDate(maxDate, attrs.wfMaxDate);
    	            		if(maxDate != undefined && theDate >= maxDate) {
    		            		valid = false;
    	            		}
    	            	}
    	            		
    	            	if(valid == false && isHidden == false) {
    	            		ngModel.$setValidity(field, false);
    	                	if(attrs.wfErrorList != undefined) {
    	                		appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);
    	                	}
    	            		return theDate;
    	            	}
    	            	today.setHours(0,0,0,0)
    	                if (valid == true && theDate >= today && theDate != null && isHidden == false) {
    	                	ngModel.$setValidity(field, false);
    	                	if(attrs.wfErrorList != undefined) {
    	                		appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);
    	                	}
    	                    return theDate;
    	                }
    	                
    	                ngModel.$setValidity(field, true);
    	                if(attrs.wfErrorList != undefined) {
    	                	removeErrorMessage($scope.$eval(attrs.wfErrorList), field);
    	                }
    	                return theDate;        
            	} else {
            		ngModel.$setValidity(field, true);
            		if(attrs.wfErrorList != undefined) {
	                	removeErrorMessage($scope.$eval(attrs.wfErrorList), field);
	                }
            	}
            	
                
                
            }
            
            var validationOnViewChange = function(value){
				
				validateDate(value);
				
				return value;
			};

			var validationOnModelChange = function(value){
				
				validateDate(value);
				
				return value;
			};
			
			ngModel.$parsers.unshift(validationOnViewChange);
			ngModel.$formatters.unshift(validationOnModelChange);
			
			elm.on("blur", function(inputValue) {
				var value = ngModel.$modelValue;
				
				validateDate(value);
				
			});
			
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				var modelValue = ngModel.$modelValue;
				
				validateDate(modelValue, true);
			});
			
			// unregister the watches on scope destroy
			$scope.$on("$destroy", function() {
				unregisterFormSubmit();
            });
            
            
        }
        

    };

}]);
/**
 * acceptFutureDate directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive('wfCityValidation',function(){
	  return{
		    require: "ngModel",
		    link: function($scope, elm, attrs, ngModel){
				var regex = new RegExp("^[0-9A-Za-z \.\-]+$");
				
				/** Model Name to uniquely identify the element and default error message.*/
	        	var field = attrs.ngModel;
	        	var errorMsg = "Invalid City Name";
	        	
	        	/** if the error message is defined, then use that message instead of the default */
	        	if (attrs.wfError != undefined) {
	            	errorMsg = attrs.wfError;
	            }
	        	
	        	var validateCity = function(value, valid, submitted) {
	        		
	        		var validateStatus = true;
					if (attrs.ngHide != undefined && $scope.$eval(attrs.ngHide)) {
						validateStatus = false;
					}
	        		
					if(validateStatus == true) {
		        		if (!valid && value!= undefined && value.length > 0) {
		        			if (submitted == true) {
		        				ngModel.$setValidity('cityValidation', false);
		        			} else {
		        				ngModel.$setValidity('cityValidation', true);
		        			}
							if(attrs.wfErrorList != undefined) {
								appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg, $scope.$eval("errorMessages"));
							}
						} else {
							ngModel.$setValidity('cityValidation', true);
							if(attrs.wfErrorList != undefined) {
								removeErrorMessage($scope.$eval(attrs.wfErrorList), field, $scope.$eval("errorMessages"));
							}
						}
					}
	        		
	        	}
	        	
				var validationOnViewChange = function(value){
					
					var valid = regex.test(value);
					
					validateCity(value, valid);
					
					return value;
				};

				var validationOnModelChange = function(value){
					
					var valid = regex.test(value);
					
					validateCity(value, valid);
					
					return value;
				};
				
				elm.on("keypress", function(event) {
					var value = ngModel.$modelValue;
					var charCode = event.which || event.keyCode;
					
					var char = String.fromCharCode(charCode);
					var valid = regex.test(char);
					if(!valid){
							event.preventDefault();
							return;
					}
					
				});
				
                elm.on('paste', function(event) {
                    var self = $(this);
                    var orig = self.val();
                    setTimeout(function () {
                        var value = $(self).val().replace(/[^0-9A-Za-z \.\-]/g, '');
                        ngModel.$setViewValue(value);
                        ngModel.$render();
                    });
                });
                
				ngModel.$parsers.unshift(validationOnViewChange);
				ngModel.$formatters.unshift(validationOnModelChange);
				
				elm.on("blur", function(inputValue) {
					var value = ngModel.$modelValue;
					var valid = regex.test(value);
					
					validateCity(value, valid);
					
				});
				
				var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
					var modelValue = ngModel.$modelValue;
					var valid = true;
					
					valid = regex.test(modelValue);
					
					validateCity(modelValue, valid, true);
				});
				
				// unregister the watches on scope destroy
				$scope.$on("$destroy", function() {
					unregisterFormSubmit();
	            });
		    }
	  };
});

/**
 * Conditional Validation directive
 *
 * Created by U251308 on 02/24/14.
 */


angular.module('wf.framework')
.directive('wfConditionalValidation', function() {
	return {
		require : "^ngModel",
		link : function($scope, elm, attrs, ngModel) {

			/**
			 * Model Name to uniquely identify the element and default error
			 * message.
			 */
			var currentState = true;
			var field = attrs.ngModel;
			var errorMsg = "ERROR: Unknown building status is invalid when entering the subject property.";
			var isSubmit = false;
			
			
			var conditionValidation = function(value, submitted) {
				var conditionStatus = false;
				var isSubmitted = false;
				
				if(submitted != undefined){
					isSubmitted = submitted;
				}
				if (attrs.wfConditionalValidation != undefined
						&& attrs.wfConditionalValidation.length > 0) {
					conditionStatus = $scope.$eval(attrs.wfConditionalValidation);
				}
				// if the element is hidden, required will not be evaluated.
				if (attrs.ngHide != undefined && $scope.$eval(attrs.ngHide)) {
					conditionStatus = false;
				}
				
				/**
				 * if the error message is defined, then use that message instead of
				 * the default
				 */
				if (attrs.wfConditionalError != undefined) {
					errorMsg = attrs.wfConditionalError;
				}
				if (attrs.wfConditionalValidation == undefined ) {
					conditionStatus = false;
				} else if (typeof value == "object" && $.isEmptyObject(value)) {
					conditionStatus = false;
				} 
				
				/**
				 * appendErrorMessage and removeErrorMessage function adds or
				 * removes the error messages from the list
				 */
				
				if (conditionStatus == true) {
					conditionValidityFailed(field, errorMsg, isSubmitted);
				} else if (conditionStatus == false) {
					conditionValidityPassed(field, isSubmitted);
				}
				
			}
			
			var conditionValidityFailed = function(field, errorMsg, submitted) {
				if(submitted == true) {
					ngModel.$setValidity('wfConditionalValidation', false);	
					if (attrs.wfErrorList != undefined) {
						appendErrorMessage($scope.$eval(attrs.wfErrorList),
								field + "*", errorMsg, $scope.$eval("errorMessages"));
					}
				}
				

			}
			
			var conditionValidityPassed = function(field, submitted) {
				ngModel.$setValidity('wfConditionalValidation', true);
				if (attrs.wfErrorList != undefined) {
					removeErrorMessage($scope.$eval(attrs.wfErrorList),
							field + "*", $scope.$eval("errorMessages"));
				}
			}
			
			var modelChangeValidator = function(value){
				var modelValue = ngModel.$modelValue;
				conditionValidation(modelValue, isSubmit);
	
				return value;
			
			}
			
			var viewChangeValidator = function(value){
				var viewValue = ngModel.$viewValue;
				conditionValidation(viewValue, isSubmit);
	
				return value;
			
			};

			// on model value change on the controller
			ngModel.$formatters.unshift(modelChangeValidator);

			// on view value change
			ngModel.$parsers.unshift(viewChangeValidator);
			
			// if the text box was red already, then validate again and set, or else never make it red.
			elm.on("blur", function(inputValue) {
				var value = ngModel.$viewValue;
				if (currentState == false) {
					conditionValidation(value, true);
				}
			});
			
			// on focus the element should change to white if it was red already. 
			elm.on("focus", function(inputValue) {
				var value = ngModel.$viewValue;
				currentState = ngModel.$valid;
				ngModel.$setValidity('wfConditionalValidation', true);
			});
			
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				
				var modelValue = ngModel.$modelValue;
				isSubmit = true;
				conditionValidation(modelValue, isSubmit);
				
				//console.log(validationService.errorMessageList);
			});
			
			var unregisterFormReset = $scope.$on("clearForm", function(clearEvent, args) {
				isSubmit = false;
				conditionValidityPassed(field, true);
			});
		
			if(attrs.wfConditionalList != undefined) {
				
				var conditionalList = attrs.wfConditionalList;
				var conditionalListListArray = conditionalList.split(',');
				var unregister = [{}];
				
				for ( var i = 0; i < conditionalListListArray.length; i++) {
					
					unregister[conditionalListListArray[i].trim()] =  $scope.$on(conditionalListListArray[i].trim(), function(args) {
						var fieldName = args.name;
						/**
						 * if the error message is defined, then use that message
						 * instead of the default
						 */
						if (attrs.wfConditionalError != undefined) {
							errorMsg = attrs.wfConditionalError;
						}
						
						var value = ngModel.$viewValue;
						conditionValidation(value, isSubmit);

					});
					
					// unregister the watches on scope destroy
					$scope.$on("$destroy", function() {
						unregisterFormSubmit();
						unregisterFormReset();
						if (conditionalListListArray[i] != undefined)
						unregister[conditionalListListArray[i].trim()]();
		            });
				}
			}
			
			

		}
	};
});
/**
 * acceptFutureDate directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive("wfDateValidation", ['$log', 'DateTimeService', function ($log, DateTimeService) {
    return {
        require: '?ngModel',
        link: function ($scope, elm, attrs, ngModel) {
            	var theDate;
            	/** Model Name to uniquely identify the element and default error message.*/
            	var field = attrs.ngModel;
            	if(attrs.id != undefined && attrs.id != "") {
            		field = attrs.id;
            	}
            	var errorMsg = "Invalid Future Date";
            	var dateOperator = "+";
            	var year = "00";
            	var month = "00";
            	var day = "00";
            	
            	/** if the error message is defined, then use that message instead of the default */
            	if (attrs.wfError != undefined) {
                	errorMsg = attrs.wfError;
                }
            	
            	var getUpdatedDate = function(myDate, updateToAttr) {
            		
            		// it expects +00Y00M00D, +000YM00D00 or -00Y00M00D or -000YM00D00format 
            		if(updateToAttr.length >= 10 && (updateToAttr.substring(0,1) == "+" || updateToAttr.substring(0,1) == "-" ) ){
            			dateOperator = updateToAttr.substring(0,1);
						var yearIndex = updateToAttr.indexOf("Y");
            			year = updateToAttr.substring(1, yearIndex);
						var monthStartIndex = 4 + (yearIndex - 3);
						var dayStartIndex = 7 + (yearIndex - 3);
            			month = updateToAttr.substring(monthStartIndex, monthStartIndex + 2);
            			day = updateToAttr.substring(dayStartIndex, dayStartIndex + 2);
            			if(dateOperator == "+") {
            				myDate.setDate(myDate.getDate() + parseInt(day));
            				myDate.setMonth(myDate.getMonth() + parseInt(month));
            				myDate.setFullYear(myDate.getFullYear() + parseInt(year));
                		}
            			if(dateOperator == "-") {
            				myDate.setDate(myDate.getDate() - parseInt(day));
            				myDate.setMonth(myDate.getMonth() - parseInt(month));
            				myDate.setFullYear(myDate.getFullYear() - parseInt(year));
                		} 
            		} else {
            			myDate = $scope.$eval(updateToAttr);
            			if(typeof myDate == "string") {
            				myDate = DateTimeService.jsonStringToDate(myDate);
                    	}
            		}
            		
            		return myDate;
            		
            	}
            	
        	var validateDate = function(value, submitted) {
            	var valid = true;
            	var today = new Date();
            	var minDate = new Date();
            	var maxDate = new Date();
            	var isHidden = false;
            	
            	if (attrs.ngHide != undefined && $scope.$eval(attrs.ngHide)) {
            		isHidden = true;
				}
            	
            	if(typeof value == "string") {
            		theDate = DateTimeService.jsonStringToDate(value);
            	} else {
            		theDate = value;
            	}
            	if(value != undefined && value != null && submitted == true) {
    	            	// Check if the future data satisfies the minimum Date Requirement
    	            	if (attrs.wfMinDate != undefined){
    	            		minDate = getUpdatedDate(minDate, attrs.wfMinDate);
    	            		if(minDate != undefined && theDate <= minDate) {
    		            		valid = false;
    	            		}
    	            	} 
    	            	// Check if the future data satisfies the maximum Date Requirement
    	            	if (attrs.wfMaxDate != undefined){
    	            		maxDate = getUpdatedDate(maxDate, attrs.wfMaxDate);
    	            		if(maxDate != undefined && theDate >= maxDate) {
    		            		valid = false;
    	            		}
    	            	}
    	            		
    	            	if(valid == false && isHidden == false) {
    	            		ngModel.$setValidity(field, false);
    	                	if(attrs.wfErrorList != undefined) {
    	                		appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);
    	                	}
    	            		return theDate;
    	            	}
    	                
    	                ngModel.$setValidity(field, true);
    	                if(attrs.wfErrorList != undefined) {
    	                	removeErrorMessage($scope.$eval(attrs.wfErrorList), field);
    	                }
    	                
    	                return theDate;
            	} else {
            		ngModel.$setValidity(field, true);
            		if(attrs.wfErrorList != undefined) {
	                	removeErrorMessage($scope.$eval(attrs.wfErrorList), field);
	                }
            	}
            	
            }
        	
        	var validationOnViewChange = function(value){
				
				validateDate(value);
				
				return value;
			};

			var validationOnModelChange = function(value){
				
				validateDate(value);
				
				return value;
			};
			
			ngModel.$parsers.unshift(validationOnViewChange);
			ngModel.$formatters.unshift(validationOnModelChange);
			
			elm.on("blur", function(inputValue) {
				var value = ngModel.$modelValue;
				
				validateDate(value);
				
			});
			
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				var modelValue = ngModel.$modelValue;
				
				validateDate(modelValue, true);
			});
			
			// unregister the watches on scope destroy
			$scope.$on("$destroy", function() {
				unregisterFormSubmit();
            });
        	
        }
        

    };

}]);
/**
 * Created by U309364 on 12/19/13.
 * Added a wfEmailOnly parameter to only check wellsfargo.com only emails. When this flag
 * is set only email addreses ending with wellsfargo.com is valid
 */



angular.module('wf.framework')
.directive('wfEmailValidation', function() {
	return {
		require : "^ngModel",
		link : function($scope, elm, attrs, ngModel) {
            // This follows all email address standards. forward look before is not working in JS. So seperate condition added to validate consecutive dots.
              var regex = new RegExp("^([a-zA-Z0-9][-0-9A-Za-z!#$%&'*+/=?^_`{|}~.]*)@([-0-9A-Za-z!#$%&'*+/=?^_`{|}~.]+)[.]([a-zA-Z]+[a-zA-Z]+)$");
            
            // This is more restrictive an follows the more common email formats - Commented the below regex part of 
            //var regex = new RegExp("^([a-zA-Z0-9][a-zA-Z0-9_\.-]+)@([a-zA-Z0-9][0-9a-zA-Z\.-]+)\.([a-zA-Z]+[a-zA-Z]+)$");

			/**
			 * Model Name to uniquely identify the element and default error
			 * message.
			 */
			var field = attrs.ngModel;
			var errorMsg = "Email format is invalid";

			/**
			 * if the error message is defined, then use that message instead of
			 * the default
			 */
			if (attrs.wfError != undefined) {
				errorMsg = attrs.wfError;
			}
			
			var validateWellsfargoEmail = function(value) {
				var valid = true;
				if (attrs.wfEmailOnly != undefined && value && !endsWith(value.toLowerCase(), 'wellsfargo.com')) {
					valid = false;
				}
				return valid;
			}
			
			var endsWith = function (str, substring) {
				return str.length >= substring.length && str.substr(str.length - substring.length) == substring;
			}
			
			var validateEmail = function(value, valid, submitted) {
				var validateStatus = true;
				if (attrs.ngHide != undefined && $scope.$eval(attrs.ngHide)) {
					validateStatus = false;
				}
				/**
				 * appendErrorMessage and removeErrorMessage function adds or
				 * removes the error messages from the list
				 */
				if(validateStatus == true) {
					if (!valid && value != undefined && value.length > 0) {
						if (submitted == true) {
							ngModel.$setValidity('emailValidation', false);
						} else {
							ngModel.$setValidity('emailValidation', true);
						}
						if (attrs.wfErrorList != undefined) {
							appendErrorMessage($scope.$eval(attrs.wfErrorList),
									field, errorMsg, $scope.$eval("errorMessages"));
						}
					} else {
						ngModel.$setValidity('emailValidation', true);
						if (attrs.wfErrorList != undefined) {
							removeErrorMessage($scope.$eval(attrs.wfErrorList),
									field, $scope.$eval("errorMessages"));
						}
					}
				} else {
					ngModel.$setValidity('emailValidation', true);
					if (attrs.wfErrorList != undefined) {
						removeErrorMessage($scope.$eval(attrs.wfErrorList),
								field, $scope.$eval("errorMessages"));
					}
				}
				
			}
			
			var validateOnViewChange = function(value) {
				
				var value = ngModel.$viewValue;
				var valid = regex.test(value) && validateWellsfargoEmail(value);
				// regex forward look before not working as expected. Adding consecutive dots check as below. 
				if(value != null && value.indexOf("..") > -1){
						valid = false;
				}
				
				validateEmail(value, valid);
				
				return value;
			};

			var validationOnModelChange = function(value) {

				var value = ngModel.$modelValue;
				var valid = regex.test(value) && validateWellsfargoEmail(value);
				// regex forward look before not working as expected. Adding consecutive dots check as below.				
				if(value != null && value.indexOf("..") > -1){
					valid = false;
				}
				validateEmail(value, valid);

				return value;
			};

			ngModel.$parsers.unshift(validateOnViewChange);
			ngModel.$formatters.unshift(validationOnModelChange);

			elm.on("blur", function(inputValue) {
				var value = ngModel.$modelValue;
				var valid = regex.test(value) && validateWellsfargoEmail(value);
				// regex forward look before not working as expected. Adding consecutive dots check as below.
				if(value != null && value.indexOf("..") > -1){
					valid = false;
				}
				validateEmail(value, valid);
				
			});
			
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				var modelValue = ngModel.$modelValue;
				var valid = true;
				
				valid = regex.test(modelValue) && validateWellsfargoEmail(modelValue);
				// regex forward look before not working as expected. Adding consecutive dots check as below.
				if(modelValue != null && modelValue.indexOf("..") > -1){
					valid = false;
				}
				validateEmail(modelValue, valid, true);
			});
			
			// unregister the watches on scope destroy
			$scope.$on("$destroy", function() {
				unregisterFormSubmit();
            });
			
		}
	};
});

/**
 * Error Message Panel directive
 *
 * Created by U111378 on 11/29/13.
 */


angular.module('wf.framework')
.directive('wfErrorMessagePanel', function(){
    return {
      template: function (element, attrs) {
          if (attrs.panelId != undefined) {
              return '<table id="'+attrs.panelId+'"><tr ng-repeat="message in error.messages track by $index" style="color:RED;" >' +
                                  '<td>{{message.data}}</td>' +
		    '</tr></table>';
          }
          return '<table id="errorMessagePanelId"><tr ng-repeat="message in error.messages track by $index" style="color:RED;" >' +
        	    '<td>{{message.data}}</td>' +
        	    '</tr></table>';
      },
      replace: true,
      transclude: false,
      restrict: 'E',
      scope: false
    };
  });


angular.module('wf.framework')
.directive('wfMaxNumber',function(){
	  return{
	    require: '?ngModel',
	    link: function($scope, elm, attrs, ngModel){
	    	var regex = new RegExp("^[0-9]{1,7}$");
	    	if(attrs.wfNumberOfDecimals != undefined) {
	    		if(attrs.wfNumberOfDecimals.length === 1) {
	    			regex = new RegExp("((^[1-9]\\d*)|^0{0,1})(\\.\\d{1,"+attrs.wfNumberOfDecimals+"})?$");	
	    		}
	    	}
			var field = attrs.ngModel;	
			var errorMsg = "Max Number is greater than";
			var id = attrs.id;
			var maxNumber=100;
			var maxNumberValue=0;
				      	
			if (id != undefined && id != null && String(id).length > 0) {
				/** 
				 * Fix for: if there is more than one element using the same model,
				 * then the errormessage will be recorded with id instead of model name. 
				 * Given that the element has an id.
				 * */
                if(attrs.type != "Radio" && attrs.type != "radio") {
                    field = attrs.id;
                }

			}
			
			field +=  "wfMaxNumber";
			
			/** if the error message is defined, then use that message instead of the default */
	      	if (attrs.wfError != undefined) {
	          	errorMsg = attrs.wfError;
	      	} else {
	      		errorMsg = errorMsg + ' ' + maxNumber;
	        }
	      	
	    	var validator = function(value){
		    var valid = regex.test(value);
		    
		    if (attrs.wfMaxNumber != undefined) {
	      		maxNumber = attrs.wfMaxNumber;
	          }	    
			/** if the error message is defined, then use that message instead of the default */
	      	if (attrs.wfError != undefined) {
	          	errorMsg = attrs.wfError;
	      	} else {
	      		errorMsg = errorMsg + ' ' + maxNumber;
	        }
	      	
	    	if(valid) 
	    	{
	    		
	    		maxNumberValue = Number(value);
	    		
	    	}
	    	if (value != null && ((!valid && value.length > 0) || (valid && value.length > 0 && maxNumberValue > maxNumber))) {
	    		  ngModel.$setValidity('wfMaxNumber', false);
	    		  removeErrorMessage($scope.$eval(attrs.wfErrorList), field); 
	    		  appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);	
	    	  } else {
	    		  ngModel.$setValidity('wfMaxNumber', true);
	    		  removeErrorMessage($scope.$eval(attrs.wfErrorList), field); 
	    	  }
	        return value;
	      };
	      ngModel.$parsers.unshift(validator);
	      ngModel.$formatters.push(validator);
	    }
	  };
	});	



angular.module('wf.framework')
.directive('wfMinMaxAgeValidation',function(){
	  return{
	    require: '?ngModel',
	    link: function($scope, elm, attrs, ngModel){
	    	var regex = new RegExp("^[0-9]{1,7}$");
			var field = ngModel.$name;	
			var errorMsg = "Invalid Min or Max Age";
			var ageValue=0;
			
			/** if the error message is defined, then use that message instead of the default */
	      	if (attrs.wfError != undefined) {
	          	errorMsg = attrs.wfError;
	          }
	    	var validator = function(value){	
	    	var valid = regex.test(value);	
	    	if(valid) 
	    	{
	    		ageValue = Number(value);
	    	}
	    	if ((!valid && value.length > 0)||(valid && value.length > 0 && ageValue > 100) ||(valid && value.length > 0 && ageValue < 1))  {	  
	    		  ngModel.$setValidity('wfMinMaxAgeValidation', false);
	    		  removeErrorMessage($scope.$eval(attrs.wfErrorList), field); 
	    		  appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);				  
	    	  } else {
	    		  ngModel.$setValidity('wfMinMaxAgeValidation', true);
	    		  removeErrorMessage($scope.$eval(attrs.wfErrorList), field); 
	    	  }
	        return value;
	      };
	      ngModel.$parsers.unshift(validator);
	    }
	  };
	});	



angular.module('wf.framework')
.directive('wfMinNumber',function(){
	  return{
	    require: '?ngModel',
	    link: function($scope, elm, attrs, ngModel){
	    	var regex = new RegExp("^[0-9]{1,7}$");
	    	if(attrs.wfNumberOfDecimals != undefined) {
	    		if(attrs.wfNumberOfDecimals.length === 1) {
	    			regex = new RegExp("((^[1-9]\\d*)|^0{0,1})(\\.\\d{1,"+attrs.wfNumberOfDecimals+"})?$");	
	    		}
	    	}
			var field = attrs.ngModel;	
			var errorMsg = "Min Number is less than";
			var id = attrs.id;
			var minNumber=1;
			var minNumberValue =0;
				      	
	      	if (attrs.wfMinNumber != undefined) {
	      		minNumber = attrs.wfMinNumber;
	          }	 	      	
	      	if (id != undefined && id != null && String(id).length > 0) {
				/** 
				 * Fix for: if there is more than one element using the same model,
				 * then the errormessage will be recorded with id instead of model name. 
				 * Given that the element has an id.
				 * */
                if(attrs.type != "Radio" && attrs.type != "radio") {
                    field = attrs.id;
                }

			}
			
			field += "wfMinNumber";
			
			/** if the error message is defined, then use that message instead of the default */
	      	if (attrs.wfError != undefined) {
	          	errorMsg = attrs.wfError;
	          } else {
	        	 errorMsg = errorMsg + ' ' + minNumber;
	          }	
	      	
	      	
	      	
	    	var validator = function(value){	
	    	var valid = regex.test(value);
	    	if(valid) 
	    	{
	    		minNumberValue = Number(value);
	    	} 
	    	if ((!valid && value.length > 0)||(valid && value.length > 0 && minNumberValue < minNumber)) {	 	
	    		  ngModel.$setValidity('wfMinNumber', false);
	    		  removeErrorMessage($scope.$eval(attrs.wfErrorList), field); 
	    		  appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg);	
	    	  } else {
	    		  ngModel.$setValidity('wfMinNumber', true);
	    		  removeErrorMessage($scope.$eval(attrs.wfErrorList), field); 
	    	  }
	        return value;
	      };
	      ngModel.$parsers.unshift(validator);
	    }
	  };
	});	
/**
 * National ID Validation directive
 * This directive takes
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive('wfNationalidValidation',['$rootScope', function($rootScope) {
	return {
		require : "^ngModel",
		link : function($scope, elm, attrs, ngModel) {
			
			//var regexForSSN = /^([1-6]\d{2}|7[0-6]\d|77[0-2])([ \-]?)(\d{2})\2(\d{4})$/;
			var regexForSSN = /^(\d{3}-?\d{2}-?\d{4}|XXX-XX-XXXX)$/;
			//It is a nine-digit number that always begins with the number 9 and has a range of 70-88 in the fourth and 
			//fifth digit. Effective April 12, 2011, the range was extended to include 900-70-0000 through 999-88-9999, 
			//900-90-0000 through 999-92-9999 and 900-94-0000 through 999-99-9999
			var regexForITIN = /^(9\d{2})([ \-]?)([7]\d|8[0-8]|9[0-2]|9[4-9])([ \-]?)(\d{4})$/;
			

			/**
			 * Model Name to uniquely identify the element and default error
			 * message.
			 */
			var field = attrs.ngModel;
			var errorMsg = "This is not a valid National Id";
			var currentState = true;
			var maskedElement = "";
			if(attrs.wfMaskedElementId != undefined) {
				maskedElement = document.getElementById(attrs.wfMaskedElementId);
			}
			
			/**
			 * if the error message is defined, then use that message instead of
			 * the default
			 */
			if (attrs.wfError != undefined) {
				errorMsg = attrs.wfError;
			}
			
			var validateNationalid = function(value, valid, submitted) {
				var validateStatus = true;
				if (attrs.ngHide != undefined && $scope.$eval(attrs.ngHide) && attrs.wfMaskedElementId == undefined) {
					validateStatus = false;
				}

                // added to pick up error messages dynamically
                if (attrs.wfError != undefined) {
                    errorMsg = attrs.wfError;
                }

				/**
				 * appendErrorMessage and removeErrorMessage function adds or
				 * removes the error messages from the list
				 */
				if (validateStatus == true) {
					if (!valid && value != undefined && value.length > 0) {
						if (submitted == true) {
							ngModel.$setValidity('wfNationalidValidation', false);
							if(attrs.wfMaskedElementId != undefined) {
								maskedElement = document.getElementById(attrs.wfMaskedElementId);
								if(maskedElement != null){
									maskedElement.classList.add("ng-invalid");	
								}
								
							}
							
						} else {
							ngModel.$setValidity('wfNationalidValidation', true);
							if(attrs.wfMaskedElementId != undefined) {
								maskedElement = document.getElementById(attrs.wfMaskedElementId);
								if(maskedElement != null){
									maskedElement.classList.remove("ng-invalid");	
								}
								
						}
						}
						
						if (attrs.wfErrorList != undefined) {
							appendErrorMessage($scope.$eval(attrs.wfErrorList),
									field, errorMsg, $scope.$eval("errorMessages"));
						}
					} else {
						ngModel.$setValidity('wfNationalidValidation', true);
						if(attrs.wfMaskedElementId != undefined) {
							maskedElement = document.getElementById(attrs.wfMaskedElementId);
							if(maskedElement != null){
								maskedElement.classList.remove("ng-invalid");	
							}
						}
						if (attrs.wfErrorList != undefined) {
							removeErrorMessage($scope.$eval(attrs.wfErrorList),
									field, $scope.$eval("errorMessages"));
						}
					}
				} else {
					ngModel.$setValidity('wfNationalidValidation', true);
					if(attrs.wfMaskedElementId != undefined) {
						maskedElement = document.getElementById(attrs.wfMaskedElementId);
						if(maskedElement != null){
							maskedElement.classList.remove("ng-invalid");	
						}
					}
					if (attrs.wfErrorList != undefined) {
						removeErrorMessage($scope.$eval(attrs.wfErrorList),
								field, $scope.$eval("errorMessages"));
				} 
				}
				
			}
			
			// Validate against regex
			var regexValidation = function(value) {
				var valid = true;
				
				// defaulted to ssn
				var nationalIdType = "";
				var evalNationalIdType = $scope.$eval(attrs.wfNationalidValidation);
				if (attrs.wfNationalidValidation != undefined && (attrs.wfNationalidValidation.toUpperCase() == "SSN" || attrs.wfNationalidValidation.toUpperCase() == "ITIN")) {
					nationalIdType = attrs.wfNationalidValidation;
				} else if (evalNationalIdType != undefined && (evalNationalIdType == "SocialSecurityNumber" || evalNationalIdType.toUpperCase() == "SSN")) {
					nationalIdType = "SSN";
				} else if (evalNationalIdType != undefined && (evalNationalIdType == "FederalTaxIDNumber" || evalNationalIdType.toUpperCase() == "ITIN" ) ) {
					nationalIdType = "ITIN";
				}
				

				if (nationalIdType != undefined && nationalIdType.toUpperCase()=="SSN"){
					valid = regexForSSN.test(value);
					if (value == "000000000") {
						valid = false;
					}
				} else if (nationalIdType != undefined && nationalIdType.toUpperCase()=="ITIN"){
					valid = regexForITIN.test(value);
				} else if (nationalIdType != undefined && nationalIdType.toUpperCase()==""){
					valid = true;
				}
				
				return valid;
			}
			
			// Color change should not happen when user typing.
			var validateOnViewChange = function(value) {
				
				var value = ngModel.$viewValue;
				//var valid = regex.test(value);
				
				return value;
			};

			var validationOnModelChange = function(value) {

				var modelValue = ngModel.$modelValue;
				var valid = true;
				
				valid = regexValidation(modelValue);
				
				validateNationalid(modelValue, valid, false);

				return value;
			};

			ngModel.$parsers.unshift(validateOnViewChange);
			ngModel.$formatters.unshift(validationOnModelChange);

			elm.on("blur", function(inputValue) {
				var viewValue = ngModel.$viewValue;
				var valid = true;
				
				valid = regexValidation(viewValue);
				
				if (currentState == false) {
					validateNationalid(viewValue, valid, true);
				} else {
					validateNationalid(viewValue, valid, false);
				}
				
				if(attrs.wfAlertMessage != undefined && !valid && (viewValue != "" && viewValue != null)){
					if(attrs.wfAlertMessage != ""){
						$rootScope.alert(attrs.wfAlertMessage);	
					} else {
						$rootScope.alert(errorMsg);
					}
					$scope.$apply();
				}
				
				var re = new RegExp('-', 'g')
				if (viewValue != undefined) {
                    elm.val(viewValue.replace(re, ''));
                    viewValue = viewValue.replace(re, '');
                    ngModel.$setViewValue(viewValue);
                }
				if( viewValue!= undefined && viewValue.length == 9) {
					elm.val('xxx-xx-' + viewValue.substring(5));
					$scope.$apply();
				}
				
			});
	      	
			// on focus the element should change to white if it was red already. 
			elm.on("focus", function(inputValue) {
				var re = new RegExp('-', 'g');
                var tempVal = ngModel.$modelValue;
                if (tempVal != undefined) {
                    elm.val(tempVal.replace(re, ''));
                }
                attrs.$set("maxlength", 11);
                $scope.$apply();
                
				var value = ngModel.$viewValue;
				currentState = ngModel.$valid;
				ngModel.$setValidity('wfNationalidValidation', true);
			});
	      	
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				var modelValue = ngModel.$modelValue;
				var valid = true;
				
				valid = regexValidation(modelValue);
				
				validateNationalid(modelValue, valid, true);
			});
			
			// unregister the watches on scope destroy
			$scope.$on("$destroy", function() {
				unregisterFormSubmit();
            });
		}
	};
}]);


/**
 * On Change broadcast the element value directive
 *
 * Created by U111378 on 12/09/13.
 */


angular.module('wf.framework')
.directive('wfOnChange', ['$rootScope', function($rootScope) {    
    return {
    	require: "^ngModel",
        link: function(scope, elm, attrs, ngModel) {
            elm.bind('blur', function() {
            	$rootScope.$broadcast(attrs.wfOnChange); 
            });
            
            var modelChangeValidator = function(value){
				
            	$rootScope.$broadcast(attrs.wfOnChange);
	
				return value;
			
			};
			
			var viewChangeValidator = function(value){
				
				$rootScope.$broadcast(attrs.wfOnChange);
	
				return value;
			
			};
			
			// on model value change on the controller
			ngModel.$formatters.unshift(modelChangeValidator);

			// on view value change
			ngModel.$parsers.unshift(viewChangeValidator);
			
        }
    };        
}]);
/**
 * Zipcode Validation directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive('wfPostalextensionValidation',function(){
	  return{
	    require: "^ngModel",
	    link: function($scope, elm, attrs, ngModel){
	    	var regex = new RegExp("^[0-9]{4}$");
	    	
	    	var currentState = true;
	    	/** Model Name to uniquely identify the element and default error message.*/
        	var field = attrs.ngModel;
        	var errorMsg = "Invalid Postal extension Code";
        	
        	/** if the error message is defined, then use that message instead of the default */
        	if (attrs.wfError != undefined) {
            	errorMsg = attrs.wfError;
            }

        	var validatePostalExtension = function(value, valid, submitted){
        		
				/** 
				 * appendErrorMessage and removeErrorMessage function adds or removes 
				 * the error messages from the list 
				 */
				if (!valid && value!= undefined && value.length > 0) {
					if(submitted == true) {
						ngModel.$setValidity('wfPostalextensionValidation', false);
					} else {
						ngModel.$setValidity('wfPostalextensionValidation', true);
					}
					
					if(attrs.wfErrorList != undefined) {
						appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg, $scope.$eval("errorMessages"));
					}
				} else {
					ngModel.$setValidity('wfPostalextensionValidation', true);
					if(attrs.wfErrorList != undefined) {
						removeErrorMessage($scope.$eval(attrs.wfErrorList), field, $scope.$eval("errorMessages"));
					}
				}
        		
        	}
        	var allowOnlyNumbers = function(value){
        		
        		if (value == undefined) {
					value="";
				}
        		
        		var transformedInput = value.replace(/[^0-9]/g, '');
      			
      			if (transformedInput != value) {
      				ngModel.$setViewValue(transformedInput);
      				ngModel.$render();
      				value = transformedInput;
      			}
      			
		        return value;
	      };

	      var validateOnViewChange = function(value) {
				
				allowOnlyNumbers(value);
				
				var value = ngModel.$viewValue;
				var valid = regex.test(value);
				
				//validatePostalExtension(value, valid);
				
				return value;
			};

			var validationOnModelChange = function(value) {

				allowOnlyNumbers(value);

				var value = ngModel.$modelValue;
				var valid = regex.test(value);
				
				validatePostalExtension(value, valid, false);

				return value;
			};
	      
	      ngModel.$parsers.unshift(validateOnViewChange);
	      ngModel.$formatters.unshift(validationOnModelChange);
	      
	      
	      	elm.on("blur", function(inputValue) {
				var value = ngModel.$viewValue;
				var valid = regex.test(value);
				if (currentState == false) {
					validatePostalExtension(value, valid, true);
				} else {
					validatePostalExtension(value, valid, false);
				}
				
			});
	      	
			// on focus the element should change to white if it was red already. 
			elm.on("focus", function(inputValue) {
				var value = ngModel.$viewValue;
				currentState = ngModel.$valid;
				ngModel.$setValidity('wfPostalextensionValidation', true);
			});
	      	
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				var modelValue = ngModel.$modelValue;
				var valid = regex.test(modelValue);
				
				validatePostalExtension(modelValue, valid, true);
			});
			
			// unregister the watches on scope destroy
			$scope.$on("$destroy", function() {
				unregisterFormSubmit();
            });
	      
	    }
	  };
	});

/**
 * acceptFutureDate directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive('wfProjectidValidation',function(){
	  return{
		    require: "ngModel",
		    link: function($scope, elm, attrs, ngModel){
				var regex = new RegExp("^[N]{1}[Y|J]{1}[0-9]{5}$|^[D]{1}[C]{1}[0-9]{5}$");
				
				var currentState = true;
				/** Model Name to uniquely identify the element and default error message.*/
	        	var field = attrs.ngModel;
	        	var errorMsg = "Invalid Project ID";
	        	
	        	/** if the error message is defined, then use that message instead of the default */
	        	if (attrs.wfError != undefined) {
	            	errorMsg = attrs.wfError;
	            }

	        	var validateProjectId = function(value, valid, submitted) {
	        		
	        		if (!valid && value!= undefined && value.length > 0) {
						if(submitted == true) {
							ngModel.$setValidity('wfProjectidValidation', false);
						} else {
							ngModel.$setValidity('wfProjectidValidation', true);
						}
						
						if(attrs.wfErrorList != undefined) {
							appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg, $scope.$eval("errorMessages"));
						}
					} else {
						ngModel.$setValidity('wfProjectidValidation', true);
						if(attrs.wfErrorList != undefined) {
							removeErrorMessage($scope.$eval(attrs.wfErrorList), field, $scope.$eval("errorMessages"));
						}
					}
	        		
	        	}
	        	
	        	var validationOnViewChange = function(value){
					
					var valid = regex.test(value);
					
					//validateProjectId(value, valid);
					
					return value;
				};

				var validationOnModelChange = function(value){
					
					var valid = regex.test(value);
					
					validateProjectId(value, valid, false);
					
					return value;
				};
				
				
				ngModel.$parsers.unshift(validationOnViewChange);
				ngModel.$formatters.unshift(validationOnModelChange);

				
				elm.on("blur", function(inputValue) {
					var value = ngModel.$viewValue;
					var valid = regex.test(value);
					if (currentState == false) {
						validateProjectId(value, valid, true);
					} else {
						validateProjectId(value, valid, false);
					}
					
				});
		      	
				// on focus the element should change to white if it was red already. 
				elm.on("focus", function(inputValue) {
					var value = ngModel.$viewValue;
					currentState = ngModel.$valid;
					ngModel.$setValidity('wfProjectidValidation', true);
				});
		      	
				var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
					var modelValue = ngModel.$modelValue;
					var valid = regex.test(modelValue);
					
					validateProjectId(modelValue, valid, true);
				});
				
				// unregister the watches on scope destroy
				$scope.$on("$destroy", function() {
					unregisterFormSubmit();
	            });
		    }
	  };
});

/**
 * acceptFutureDate directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive('wfRegexValidate', function() {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function($scope, elm, attrs, ngModel) {
        	var isPresent = 0;
            var flags = attrs.regexValidateFlags || '';
            
            if ($scope.messages == undefined) {
        		$scope.messages = [{}];
        	}
            var field = ngModel.$name;
            var regex = new RegExp(attrs.regexValidate, flags);            
                        
            ngModel.$parsers.unshift(function(value) {
                var valid = regex.test(value);
                ngModel.$setValidity('regexValidate', valid);
                if (!valid){
                	attrs.$set('class',"textboxbase-format-error");
                	
                	for(var i = $scope.messages.length - 1; i >= 0; i--){
            			if($scope.messages[i].id == field){
            				isPresent = 1;
            			}
            		}
                	if (isPresent == 0){
                		$scope.messages.push(({id:field, data: attrs.errormsg}));
                	}
                	
                } else {
                	attrs.$set('class',"none");
                	
                	for(var i = $scope.messages.length - 1; i >= 0; i--){
            			if($scope.messages[i].id == field){
            				$scope.messages.splice(i,1);
            			}
            		}
                	
                }
                
                return valid ? value : undefined;
            });
            
            ngModel.$formatters.unshift(function(value) {
            	ngModel.$setValidity('regexValidate', regex.test(value));
                return value;
            });
        }
        
    };
});
/**
 * Required Label directive
 * Purpose: This directive when used, will show * in required css style.
 *
 * Created by U111378 on 12/20/13.
 */


angular.module('wf.framework')
.directive('wfRequiredLabel', [ function() {
	return {
		link : function($scope, element, attrs) {
			
			var validator = function() {
				var transformedInput = element[0].innerText.replace(/^[\*]+/g, '');
				if (attrs.wfRequiredLabel != undefined && attrs.wfRequiredLabel != "" && $scope.$eval(attrs.wfRequiredLabel)) {
					element[0].innerHTML = "<span class='required'>*</span>"
						+ transformedInput;
				} else if (attrs.wfRequiredLabel != undefined && attrs.wfRequiredLabel != "" && !$scope.$eval(attrs.wfRequiredLabel)) {
					element[0].innerHTML = transformedInput;
				} else if (attrs.wfRequiredLabel == undefined || attrs.wfRequiredLabel == "") {
					element[0].innerHTML = "<span class='required'>*</span>"
						+ transformedInput;
				}
			};
			
			$scope.$on(attrs.wfRequiredLabel, function(args) {
				validator();
			});
			
			validator();
			
		}
	};
} ]);
/**
 * Required Validation directive
 *
 * Created by U111378 on 12/09/13.
 */


angular.module('wf.framework')
.directive('wfRequired', function() {
	return {
		require : "^ngModel",
		link : function($scope, elm, attrs, ngModel) {

			/**
			 * Model Name to uniquely identify the element and default error
			 * message.
			 */
			var currentState = true;
			var field = attrs.ngModel;
			var id = attrs.id;
			var errorMsg = "ERROR: A required data is not provided.";
			if (id != undefined && id != null && String(id).length > 0) {
				errorMsg = "ERROR: " + id.replace(/([A-Z])/g, ' $1') + " is a required field";
				/** 
				 * Fix for: if there is more than one element using the same model,
				 * then the errormessage will be recorded with id instead of model name. 
				 * Given that the element has an id.
				 * */
                if(attrs.type != "Radio" && attrs.type != "radio") {
                    field = attrs.id;
                }

			} 

			var isSubmit = false;
			//$scope.error.errorMessageList.push(({id:field}));
			
			/**
			 * if the error message is defined, then use that message instead of
			 * the default
			 */
			if (attrs.wfRequiredError != undefined) {
				errorMsg = attrs.wfRequiredError;
			}

			var requiredValidation = function(value, submitted) {
				var requiredStatus = true;
				var isSubmitted = false;

				if(submitted != undefined){
					isSubmitted = submitted;
				}
				if (attrs.wfRequired != undefined
						&& attrs.wfRequired.length > 0) {
					requiredStatus = $scope.$eval(attrs.wfRequired);
				}
				
				if (attrs.wfRequiredError != undefined) {
					errorMsg = attrs.wfRequiredError;
				}
				
				// if the element is hidden, required will not be evaluated.
				if (attrs.ngHide != undefined && $scope.$eval(attrs.ngHide)) {
					requiredStatus = false;
				}
//				var isElementVisible = elm.is(":visible");
//				if (isElementVisible == false) {
//					requiredStatus = false;
//				}
				/**
				 * appendErrorMessage and removeErrorMessage function adds or
				 * removes the error messages from the list
				 */
				if (requiredStatus == true) {
					if (value != undefined && String(value).length > 0) {
						requiredValidityPassed(field, isSubmitted);
					} else if (value != undefined && value.length == 0) {
						requiredValidityFailed(field, errorMsg, isSubmitted);
					}

					if (value == undefined ) {
						requiredValidityFailed(field, errorMsg, isSubmitted);
					} else if (typeof value == "object" && $.isEmptyObject(value) && elm[0].localName == "select") {
						requiredValidityFailed(field, errorMsg, isSubmitted);
					} else if (typeof value == "object" && !$.isEmptyObject(value)) {
						requiredValidityPassed(field, isSubmitted);
					}
					
					if (attrs.type == "Radio" || attrs.type == "radio") {
						if ($scope.$eval(attrs.ngModel) != undefined) {
							if (Boolean($scope.$eval(attrs.ngModel)) == true || Boolean($scope.$eval(attrs.ngModel)) == false) {
								requiredValidityPassed(field, isSubmitted);
							} else if (Boolean($scope.$eval(attrs.ngModel)) != true || Boolean($scope.$eval(attrs.ngModel)) != false) {
								requiredValidityFailed(field, errorMsg, isSubmitted);
							}
						} 
					}
					
				} else if (requiredStatus == false) {
					requiredValidityPassed(field, isSubmitted);
				}
				
				var labelModel = attrs.wfLabelModel;
				if(requiredStatus) {
					if (labelModel != undefined) {
						$scope.$eval(labelModel + ' = ' + true)						
					}
					$scope.$emit(attrs.wfLabelModel);
				} else if (!requiredStatus) {
					if (labelModel != undefined) {
						$scope.$eval(labelModel + ' = ' + false)						
					}
					$scope.$emit(attrs.wfLabelModel);
				}

			}
			
			var requiredValidityFailed = function(field, errorMsg, submitted) {
				if(submitted == true) {
					ngModel.$setValidity('wfRequired', false);	
					if (attrs.wfErrorList != undefined) {
						appendErrorMessage($scope.$eval(attrs.wfErrorList),
								field + "*", errorMsg, $scope.$eval("errorMessages"));
					}
				}
				

			}
			
			var requiredValidityPassed = function(field, submitted) {
				ngModel.$setValidity('wfRequired', true);
				if (attrs.wfErrorList != undefined) {
					removeErrorMessage($scope.$eval(attrs.wfErrorList),
							field + "*", $scope.$eval("errorMessages"));
				}
			}
			
			var modelChangeValidator = function(value){
				var modelValue = ngModel.$modelValue;
				requiredValidation(modelValue, isSubmit);
	
				return value;
			
			};
			
			var viewChangeValidator = function(value){
				var viewValue = ngModel.$viewValue;
				requiredValidation(viewValue, isSubmit);
	
				return value;
			
			};

			// on model value change on the controller
			ngModel.$formatters.unshift(modelChangeValidator);

			// on view value change
			ngModel.$parsers.unshift(viewChangeValidator);
			
			// if the text box was red already, then validate again and set, or else never make it red.
			elm.on("blur", function(inputValue) {
				var value = ngModel.$viewValue;
				if (currentState == false) {
					requiredValidation(value, true);
				}
			});
			
			// on focus the element should change to white if it was red already. 
			elm.on("focus", function(inputValue) {
				var value = ngModel.$viewValue;
				currentState = ngModel.$valid;
				ngModel.$setValidity('wfRequired', true);
			});
			

			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				
				var modelValue = ngModel.$modelValue;
				isSubmit = true;
				requiredValidation(modelValue, isSubmit);
				
				//console.log(validationService.errorMessageList);
			});
			
			var unregisterFormReset = $scope.$on("clearForm", function(clearEvent, args) {
				isSubmit = false;
				requiredValidityPassed(field, true);
			});
			
			if(attrs.wfWatchList != undefined) {
				
				var watchList = attrs.wfWatchList;
				var watchListArray = watchList.split(',');
				var unregister = [{}];
				
				for ( var i = 0; i < watchListArray.length; i++) {
					
					unregister[watchListArray[i].trim()] =  $scope.$on(watchListArray[i].trim(), function(args) {
						var fieldName = args.name;
						/**
						 * if the error message is defined, then use that message
						 * instead of the default
						 */
						if (attrs.wfConditionError != undefined) {
							errorMsg = attrs.wfConditionError;
						}
						
						var value = ngModel.$viewValue;
						requiredValidation(value, isSubmit);

					});
					
					// unregister the watches on scope destroy
					$scope.$on("$destroy", function() {
						unregisterFormSubmit();
						unregisterFormReset();
						requiredValidityPassed(field, true);
						if (watchListArray[i] != undefined)
						unregister[watchListArray[i].trim()]();
		            });
				}
			}
			
			

		}
	};
});
/**
 * Street Name Validation directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive('wfStreetnameValidation',function(){
	  return{
		    require: "ngModel",
		    link: function($scope, elm, attrs, ngModel){
				var regex = new RegExp("^[0-9A-Za-z \.\\-\/]+$");
				
				/** Model Name to uniquely identify the element and default error message.*/
	        	var field = attrs.ngModel;
	        	var errorMsg = "Invalid Street Name";
	        	
	        	/** if the error message is defined, then use that message instead of the default */
	        	if (attrs.wfError != undefined) {
	            	errorMsg = attrs.wfError;
	            }
	        	
	        	var validateStreetName = function(value, valid){
	        		
	        		/** 
					 * appendErrorMessage and removeErrorMessage function adds or removes 
					 * the error messages from the list 
					 */
					if (!valid && value!= undefined && value.length > 0) {
						ngModel.$setValidity('streetnameValidation', false);
						if(attrs.wfErrorList != undefined) {
							appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg, $scope.$eval("errorMessages"));
						}
					} else {
						ngModel.$setValidity('streetnameValidation', true);
						if(attrs.wfErrorList != undefined) {
							removeErrorMessage($scope.$eval(attrs.wfErrorList), field, $scope.$eval("errorMessages"));
						}
					}
					
	        	}
	        	
	        	var validationOnViewChange = function(value){
					
					var valid = regex.test(value);
					
					validateStreetName(value, valid);
					
					return value;
				};

				var validationOnModelChange = function(value){
					
					var valid = regex.test(value);
					
					validateStreetName(value, valid);
					
					return value;
				};
				
				elm.on("keypress", function(event) {
					var value = ngModel.$modelValue;
					var charCode = event.which || event.keyCode;
					
					var char = String.fromCharCode(charCode);
					var valid = regex.test(char);
					if(!valid){
							event.preventDefault();
							return;
					}
					
				});
				
                elm.on('paste', function(event) {
                    var self = $(this);
                    var orig = self.val();
                    setTimeout(function () {
                    	var value = $(self).val().replace(/[^0-9A-Za-z \.\-\/]/g, '');
                        ngModel.$setViewValue(value);
                        ngModel.$render();
                    });
                });
							
				ngModel.$parsers.unshift(validationOnViewChange);
				ngModel.$formatters.unshift(validationOnModelChange);
				
				elm.on("blur", function(inputValue) {
					var value = ngModel.$modelValue;
					var valid = regex.test(value);
					validateStreetName(value, valid);
				});
		    }
	  };
});

/**
 * acceptFutureDate directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive('wfStreetnumberValidation',function(){
	  return{
		    require: "ngModel",
		    link: function($scope, elm, attrs, ngModel){
				var regex = new RegExp("^[0-9A-Za-z \x2F\.\-]+$");
				
				/** Model Name to uniquely identify the element and default error message.*/
	        	var field = attrs.ngModel;
	        	var errorMsg = "Invalid Street Number";
	        	
	        	/** if the error message is defined, then use that message instead of the default */
	        	if (attrs.wfError != undefined) {
	            	errorMsg = attrs.wfError;
	            }
	        	
	        	var validationStreetNumber = function(value, valid) {
	        		
	        		if (!valid && value!= undefined && value.length > 0) {
						ngModel.$setValidity('streetnumberValidation', false);
						if(attrs.wfErrorList != undefined) {
							appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg, $scope.$eval("errorMessages"));
						}
					} else {
						ngModel.$setValidity('streetnumberValidation', true);
						if(attrs.wfErrorList != undefined) {
							removeErrorMessage($scope.$eval(attrs.wfErrorList), field, $scope.$eval("errorMessages"));
						}
					}
	        		
	        	}
	        	
	        	var validationOnViewChange = function(value){
					
					var valid = regex.test(value);
					
					validationStreetNumber(value, valid);
					
					return value;
				};

				var validationOnModelChange = function(value){
					
					var valid = regex.test(value);
					
					validationStreetNumber(value, valid);
					
					return value;
				};
				
				elm.on("keypress", function(event) {
					var value = ngModel.$modelValue;
					var charCode = event.which || event.keyCode;
					
					var char = String.fromCharCode(charCode);
					var valid = regex.test(char);
					if(!valid){
							event.preventDefault();
							return;
					}
					
				});
				
                elm.on('paste', function(event) {
                    var self = $(this);
                    var orig = self.val();
                    setTimeout(function () {
                        var value = $(self).val().replace(/[^0-9A-Za-z \.\-\/]/g, '');
                        ngModel.$setViewValue(value);
                        ngModel.$render();
                    });
                });
                
				ngModel.$parsers.unshift(validationOnViewChange);
				ngModel.$formatters.unshift(validationOnModelChange);
				
				elm.on("blur", function(inputValue) {
					var value = ngModel.$modelValue;
					var valid = regex.test(value);
					validationStreetNumber(value, valid);
				});
		    }
	  };
});

/**
 * formatCurrency directive
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework')
.directive('wfSubmit', ['$parse', function($parse) {
            return {
                restrict: 'A',
                require: ['wfSubmit', '?form'],
                controller: ['$scope', function ($scope) {
                    this.attempted = false;
 
                    this.setAttempted = function(elmName) {
                        this.attempted = true;
                        
                        // finds the scope of the element name provided by user.
                        var scopeOfElm = angular.element(document.getElementsByName(elmName)).scope();
                        
                        if($scope.wf != undefined && $scope.wf.name !=undefined &&
                                ($scope.wf.name == "okBusinessOperationButton" || $scope.wf.name == "pprMiniNavButton" || $scope.wf.name == "coreOkCancelSaveButton")) {
                        	$scope.$parent.$broadcast("formSubmitted", true);
                        } else if (scopeOfElm != undefined) {
                        	/** 
                        	 * This broadcasts the button click event to scope in which the provided element is.
                        	 * Case: If the user has the button on child but want the validation to happen on the parent, then
                        	 * Specify the one of the parent elements name in. 
                        	 * **/
                        	scopeOfElm.$broadcast("formSubmitted", true);
                        } else {
                        	$scope.$broadcast("formSubmitted", true);
                        }
                        
                    };
                }],
                compile: function(cElement, cAttributes, transclude) {
                    return {
                        pre: function(scope, formElement, attributes, controllers) {
 
                            var submitController = controllers[0];
 
                            scope.wf = scope.wf || {};
                            scope.wf[attributes.name] = submitController;
                            scope.wf.name = attributes.name; 
                        },
                        post: function(scope, formElement, attributes, controllers) {
 
                            var submitController = controllers[0];
                            var formController = (controllers.length > 1) ? 
                                                 controllers[1] : null;
 
                            var fn = $parse(attributes.wfSubmit);
 
                            formElement.bind('click', function () {
                        		submitController.setAttempted(attributes.wfSubmit);
                                if (!scope.$$phase) scope.$apply();
 
                                //if (!formController.$valid) return false;
 
                                scope.$apply(function() {
                                    fn(scope, {$event:event});
                                });
                            });
                        }
                    };
                }
        }
    }]);

/**
 * acceptFutureDate directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive('wfTransitroutingValidation',function(){
	  return{
	    require: "ngModel",
	    link: function($scope, elm, attrs, ngModel){
	    	var regex = new RegExp("^[0123]{1}[0-9]{8}$|^$");
	    	
	    	/** Model Name to uniquely identify the element and default error message.*/
        	var field = attrs.ngModel;
        	var errorMsg = "Invalid Transit Routing Number";
        	var currentState = true;
        	/** if the error message is defined, then use that message instead of the default */
        	if (attrs.wfError != undefined) {
            	errorMsg = attrs.wfError;
            }
        	
        	var validateTransitRouting = function(value, valid, submitted) {
        		
        		if (!valid && value!= undefined && value.length > 0) {
        			if(submitted == true) {
        				ngModel.$setValidity('transitroutingValidation', false);
        			} else {
        				ngModel.$setValidity('transitroutingValidation', true);
        			}
		    		  
		    		  if(attrs.wfErrorList != undefined) {
		    			  appendErrorMessage($scope.$eval(attrs.wfErrorList), field, errorMsg, $scope.$eval("errorMessages"));
		    		  }
		    	  } else {
		    		  ngModel.$setValidity('transitroutingValidation', true);
		    		  if(attrs.wfErrorList != undefined) {
		    			  removeErrorMessage($scope.$eval(attrs.wfErrorList), field, $scope.$eval("errorMessages"));
		    		  }
		    	  }
        	}
        	
	    	var allowOnlyNumbers = function(value){
	    		
	    		if (value == undefined) {
	    			value = "";
	    		}
	    		
	    		var transformedInput = value.replace(/[^0-9]/g, '');
      			
      			if (transformedInput != value) {
      				ngModel.$setViewValue(transformedInput);
      				ngModel.$render();
      				value = transformedInput;
      			}
	    	  
	        return value;
	      };
	      
	      var validationOnViewChange = function(value){
	    	  
	    	  	allowOnlyNumbers(value);
	    	  
				var valid = regex.test(value);
				
				//validateTransitRouting(value, valid);
				
				return value;
			};

			var validationOnModelChange = function(value){
				
				allowOnlyNumbers(value);
				
				var valid = regex.test(value);
				
				validateTransitRouting(value, valid, false);
				
				return value;
			};
			
			
			ngModel.$parsers.unshift(validationOnViewChange);
			ngModel.$formatters.unshift(validationOnModelChange);
	      
	      	elm.on("blur", function(inputValue) {
				var value = ngModel.$viewValue;
				var valid = regex.test(value);
				if (currentState == false) {
					validateTransitRouting(value, valid, true);
				} else {
					validateTransitRouting(value, valid, false);
				}
				
			});
	      	
			// on focus the element should change to white if it was red already. 
			elm.on("focus", function(inputValue) {
				var value = ngModel.$viewValue;
				currentState = ngModel.$valid;
				ngModel.$setValidity('transitroutingValidation', true);
			});
	      	
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				var modelValue = ngModel.$modelValue;
				var valid = regex.test(modelValue);
				
				validateTransitRouting(modelValue, valid, true);
			});
			
			// unregister the watches on scope destroy
			$scope.$on("$destroy", function() {
				unregisterFormSubmit();
            });
	    }
	  };
	});

/**
 * Zipcode Validation directive
 *
 * Created by U111378 on 11/20/13.
 */


angular.module('wf.framework')
.directive('wfZipcodeValidation', function() {
	return {
		require : "^ngModel",
		link : function($scope, elm, attrs, ngModel) {
			var regex = new RegExp("^[0-9]{5}$");

			/**
			 * Model Name to uniquely identify the element and default error
			 * message.
			 */
			var field = attrs.ngModel;
			var errorMsg = "Invalid Zip Code";
			var currentState = true;
			/**
			 * if the error message is defined, then use that message instead of
			 * the default
			 */
			if (attrs.wfError != undefined) {
				errorMsg = attrs.wfError;
			}
			
			var validateZipcode = function(value, valid, submitted) {
				/**
				 * appendErrorMessage and removeErrorMessage function adds or
				 * removes the error messages from the list
				 */
				if (!valid && value != undefined && value.length > 0) {
					if (submitted == true) {
						ngModel.$setValidity('zipcodeValidation', false);
					} else {
						ngModel.$setValidity('zipcodeValidation', true);
					}
					
					if (attrs.wfErrorList != undefined) {
						appendErrorMessage($scope.$eval(attrs.wfErrorList),
								field, errorMsg, $scope.$eval("errorMessages"));
					}
				} else {
					ngModel.$setValidity('zipcodeValidation', true);
					if (attrs.wfErrorList != undefined) {
						removeErrorMessage($scope.$eval(attrs.wfErrorList),
								field, $scope.$eval("errorMessages"));
					}
				}
				
			}
			
			var allowOnlyNumbers = function(value) {
				
				if (value == undefined) {
					value="";
				}
				
				var transformedInput = value.replace(/[^0-9]/g, '');

				if (transformedInput != value) {
					ngModel.$setViewValue(transformedInput);
					ngModel.$render();
					value = transformedInput;
				}
				
			}
			
			// Color change should not happen when user typing.
			var validateOnViewChange = function(value) {
				
				allowOnlyNumbers(value);
				
				var value = ngModel.$viewValue;
				var valid = regex.test(value);
				
				//validateZipcode(value, valid);
				
				return value;
			};

			var validationOnModelChange = function(value) {

				allowOnlyNumbers(value);

				var value = ngModel.$modelValue;
				var valid = regex.test(value);
				
				validateZipcode(value, valid, false);

				return value;
			};

			ngModel.$parsers.unshift(validateOnViewChange);
			ngModel.$formatters.unshift(validationOnModelChange);

			elm.on("blur", function(inputValue) {
				var value = ngModel.$viewValue;
				var valid = regex.test(value);
				if (currentState == false) {
					validateZipcode(value, valid, true);
				} else {
					validateZipcode(value, valid, false);
				}
				
			});
	      	
			// on focus the element should change to white if it was red already. 
			elm.on("focus", function(inputValue) {
				var value = ngModel.$viewValue;
				currentState = ngModel.$valid;
				ngModel.$setValidity('zipcodeValidation', true);
			});
	      	
			var unregisterFormSubmit = $scope.$on("formSubmitted", function(mass) {
				var modelValue = ngModel.$modelValue;
				var valid = regex.test(modelValue);
				
				validateZipcode(modelValue, valid, true);
			});
			
			// unregister the watches on scope destroy
			$scope.$on("$destroy", function() {
				unregisterFormSubmit();
            });
		}
	};
});

/**
	This is dependent on the ui.bootstrap module. This uses the modal service of ui.bootstrap.
	In ui,bootstrap version 0.6 the $dialog service is not present. This module brings back that service
*/

angular.module("dialog").factory('$dialog', ['$rootScope', '$modal', 'wfModalService', function($rootScope, $modal, wfModalService) {

  var waitCount = 0;
  function waitForModal() {
      var modalBody = document.getElementsByClassName('modal-body');
      if (modalBody && modalBody.length > 0) {
          // the modal is now displayed, we can begin the modal behavior
          wfModalService.beginModalBehavior(modalBody[0].parentNode);
      } else {
          // we need to wait
          if (waitCount++ <= 10 ) {
              setTimeout(waitForModal, 100);
          } else {
              console.error('Gave up waiting for modal dialog after ' + waitCount);
          }
      }
  }

  function dialog(modalOptions, resultFn) {
    var dialog = $modal.open(modalOptions);
    dialog.opened.then(function() {
        // we need to wait until the modal is finally displayed
        waitCount = 0;
        waitForModal();
    });
    if (resultFn) dialog.result.then(resultFn);
    dialog.values = modalOptions;
    return dialog;
  }

  function modalOptions(templateUrl, controller, scope) {
      // NOTE: the hardcoded keyboard: false is important - DO NOT DELETE.  This disables the $dialog default
      // behavior of allowing the modal to be cancelled via the escape key.  The unfortunate problem is that
      // dialogs cancelled in this method provide no notification back to us.  So we are left unable to disable
      // are keyboard handlers and can end up with the keyboard disabled when it should not be - with not recovery
      // other than refresh.
    return { templateUrl:  templateUrl, controller: controller, scope: scope, keyboard: false, backdrop: 'static' }; }

  return {
    /**
     * Creates and opens dialog.
     */
    dialog: dialog,

    /**
     * Returns 0-parameter function that opens dialog on evaluation.
     */
    simpleDialog: function(templateUrl, controller, resultFn) {
      return function () { return dialog(modalOptions(templateUrl, controller), resultFn); }; },

    /**
     * Opens simple generic dialog presenting title, message (any html) and provided buttons.
     */
    messageBox: function(title, message, buttons, resultFn) {
      var scope = angular.extend($rootScope.$new(false), { title: title, message: message, buttons: buttons });
      return dialog(modalOptions("template/messageBox/message.html", 'MessageBoxController', scope), function (result) {
        var value = resultFn ? resultFn(result) : undefined;
        scope.$destroy();
        return value;
      }); }
  };
}])
.run(["$templateCache", function($templateCache) {
  $templateCache.put("template/messageBox/message.html",
      '<div class="modal-header"><h3>{{ title }}</h3></div>\n' +
      '<div class="modal-body"><p ng-bind-html="message"></p></div>\n' +
      '<div class="modal-footer"><button type="button" ng-repeat="btn in buttons" id="dialog_button_{{$index}}" ng-click="close(btn.result)" class="btn {{$first ? \'btn-primary\' : \'btn-default\'}}" ng-class="btn.cssClass" ng-style="($first ? {float: \'right\', \'margin-right\': \'5px\'} : {float: \'left\'})">{{ btn.label }}</button></div>\n');
}])
.controller('MessageBoxController', ['$scope', '$modalInstance', 'wfModalService', function ($scope, $modalInstance, wfModalService) {
  $scope.close = function (result) {
      wfModalService.endModalBehavior();
      $modalInstance.close(result);
  }
}]);

/*global angular */
/*
 jQuery UI Datepicker plugin wrapper

 @note If ≤ IE8 make sure you have a polyfill for Date.toISOString()
 @param [ui-date] {object} Options to pass to $.fn.datepicker() merged onto uiDateConfig
 */

angular.module('ui.date', [])

    .constant('uiDateConfig', {dateFormat:'mm-dd-yy',
        dayNamesMin: [ 'S', 'M', 'T', 'W', 'T', 'F', 'S' ],
        monthNames: [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ],
        monthNamesShort: [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ],
        showOtherMonths: true,
        selectOtherMonths: true,
        changeMonth: true,
        changeYear: true})

    .directive('uiDate', ['uiDateConfig', '$timeout', function (uiDateConfig, $timeout) {

        var options;
        options = {};
        angular.extend(options, uiDateConfig);
        return {
            require:'?ngModel',
            link:function (scope, element, attrs, controller) {
                var getOptions = function () {
                    return angular.extend({}, uiDateConfig, scope.$eval(attrs.uiDate));
                };
                var errorMsg = "Invalid Date";

                /** if the error message is defined, then use that message instead of the default */
                if (attrs.wfError != undefined) {
                    errorMsg = attrs.wfError;
                }
                if (controller) {
                    controller.$formatters.push(function(date){
                        if (date) {
                            if (angular.isString(date) ) {
                                if(attrs.uiDateFormat){
                                    return jQuery.datepicker.parseDate(attrs.uiDateFormat, date);
                                }else{
                                    throw new Error('Date string is assigned to ngModel - use ui-date-format to convert it ');
                                }
                            }
                            else if (angular.isNumber(date)) {
                                return new Date(date);
                            }
                            else {
                                return date;
                            }
                        }
                        return date;
                    });
                    if (attrs.uiDateFormat == undefined) {
                        controller.$parsers.push(function(date){
                                if (!angular.isDate(date) ) {
                                    return null;
                                }
                            return date;
                        });
                    }
                }

                var initDateWidget = function () {
                    var showing = false;
                    var opts = getOptions();

                    // If we have a controller (i.e. ngModelController) then wire it up
                    if (controller) {

                        var field = attrs.ngModel;
                        // Set the view value in a $apply block when users selects
                        // (calling directive user's function too if provided)
                        var _onSelect = opts.onSelect || angular.noop;
                        opts.onSelect = function (value, picker) {
                            scope.$apply(function() {
                                showing = true;
                                var datepickerDate = element.datepicker("getDate");
								if (datepickerDate && datepickerDate < new Date('0999-12-31')) {
                                    controller.$setValidity("dateFormat", false);
                                    if (attrs.wfErrorList) {
										appendErrorMessage(scope.$eval(attrs.wfErrorList), field, errorMsg);
                                    }
                                } else {
									controller.$setViewValue(element.datepicker("getDate"));
									controller.$setValidity("dateFormat", true);
                                    if (attrs.wfErrorList) {
                                        removeErrorMessage(scope.$eval(attrs.wfErrorList), field);
                                    }									
								}
                                _onSelect(value, picker);
                                element.blur();
                            });
                        };
                        opts.beforeShow = function() {
                            showing = true;
                        };
                        opts.onClose = function(value, picker) {
                            showing = false;
                        };
                        element.on('blur', function() {
                            if ( !showing ) {
                                scope.$apply(function() {
                                    //Special handling for cases where the datepicker is set to button.
                                    //In that case when user enters invalid date the jquery date-picker still
                                    //returns defaultdate (which is the current date)
                                    //In that case we are explicitly trying to validate is the text in the input field
                                    //is a valid date.
                                    if (opts.showOn == 'button') {
                                        controller.$setValidity("dateFormat", true);
                                        if (attrs.wfErrorList) {
                                            removeErrorMessage(scope.$eval(attrs.wfErrorList), field);
                                        }
                                        if (element.val()) {
                                            try {
                                                var d = jQuery.datepicker.parseDate(opts.dateFormat, element.val());
                                            } catch (err) {
                                                try {
                                                    var alternateDateFormat = 'mmddyy';
                                                    if (element.val() && element.val().indexOf("/") !== -1) {
                                                        alternateDateFormat = 'mm/dd/yy';
                                                    }
                                                    jQuery.datepicker.parseDate(alternateDateFormat, element.val());
                                                } catch (err1) {
                                                    controller.$setValidity("dateFormat", false);
                                                    if (attrs.wfErrorList) {
                                                        appendErrorMessage(scope.$eval(attrs.wfErrorList), field, errorMsg);
                                                    }
                                                    return;
                                                }
                                            }
                                        }
                                    }
                                    var datepickerDate = element.datepicker("getDate");
                                    if (datepickerDate) {
                                        //jquery treats a 3 digit date as valid. So adding this extra check
                                        //to
                                        if (datepickerDate < new Date('0999-12-31')) {
                                            controller.$setValidity("dateFormat", false);
                                            if (attrs.wfErrorList) {
                                                appendErrorMessage(scope.$eval(attrs.wfErrorList), field, errorMsg);
                                            }
                                        } else {
                                            element.datepicker("setDate", element.datepicker("getDate"));
                                            controller.$setViewValue(element.datepicker("getDate"));
                                            controller.$setValidity("dateFormat", true);
                                            if (attrs.wfErrorList) {
                                                removeErrorMessage(scope.$eval(attrs.wfErrorList), field);
                                            }
                                        }
                                    }

                                    else if (!datepickerDate && element.val()) { //This will happen when the user input is an invalid date
                                        controller.$setValidity("dateFormat", false);
                                        if (attrs.wfErrorList) {
                                            appendErrorMessage(scope.$eval(attrs.wfErrorList), field, errorMsg);
                                        }
                                    } else {
                                        controller.$setValidity("dateFormat", true);
                                        if (attrs.wfErrorList) {
                                            removeErrorMessage(scope.$eval(attrs.wfErrorList), field);
                                        }
                                    }
                                });
                            }
                        });

                        // Update the date picker when the model changes
                        controller.$render = function () {
                            var viewValue = controller.$viewValue;
                            var modelValue = controller.$modelValue;
                            var date = viewValue;
                            if ( angular.isDefined(date) && date !== null && !angular.isDate(date) ) {
                                date = modelValue;
                                if ( angular.isDefined(date) && date !== null && !angular.isDate(date) ) {
                                    throw new Error('ng-Model value must be a Date object - currently it is a ' + typeof date + ' - use ui-date-format to convert it ');
                                }
                            }
                            element.datepicker("setDate", date);
                        };
                    }
                    // If we don't destroy the old one it doesn't update properly when the config changes
                    element.datepicker('destroy');
                    // Create the new datepicker widget
                    element.datepicker(opts);
                    if ( controller ) {
                        // Force a render to override whatever is in the input text box
                        controller.$render();
                    }
                };
                // Watch for changes to the directives options
                var unwatchOptions = scope.$watch(getOptions, initDateWidget, true);

                element.on('$destroy', function(){
                    if(element.data('datepicker')){
                        element.data('datepicker').settings = undefined;
                    }
                    element.datepicker('destroy');
                    element.unbind();
                    element.remove();
                    unwatchOptions();
                });

            }
        };
    }
    ])

    .constant('uiDateFormatConfig', '')

    .directive('uiDateFormat', ['uiDateFormatConfig', function(uiDateFormatConfig) {
        var directive = {
            require:'ngModel',
            link: function(scope, element, attrs, modelCtrl) {
                var dateFormat = attrs.uiDateFormat || uiDateFormatConfig;
                if ( dateFormat ) {
                    // Use the datepicker with the attribute value as the dateFormat string to convert to and from a string
                    modelCtrl.$formatters.unshift(function(value) { //the value is either string or number
                        if (value && angular.isString(value) ) {
                            try {
                                var date = jQuery.datepicker.parseDate(dateFormat, value);
                                return date;
                            } catch (err) {
                                //Convert ISO date string into date
                                return new Date(value);
                            }
                        }
                        if(value){   //Convert time mills to date string format..
                            return new Date(value);
                        }
                        return null;
                    });
                    modelCtrl.$parsers.push(function(value){

                        var returnTime = attrs.timeMillis;
                        if (value && angular.isDate(value)) {
                            if(returnTime){
                                return value.getTime();//converting date string to mills.
                            }
                            try {
                                return jQuery.datepicker.formatDate(dateFormat, value);
                            } catch (err) {
                                return null;
                            }
                        }
                        return null;
                    });
                } else {
                    // Default to ISO formatting
                    modelCtrl.$formatters.unshift(function(value) {
                        if (value && angular.isString(value) ) {
                            return new Date(value);
                        }
                        return null;
                    });
                    modelCtrl.$parsers.push(function(value){ //The value is a date object
                        var returnTime = attrs.timeMillis;
                        if (value && angular.isDate(value)) {
                            if(returnTime ){
                                return value.getTime();//converting date string to mills.
                            }
                            return value.toISOString();
                        }
                        return null;
                    });
                }
            }
        };
        return directive;
    }]);


/**
 * Created by U270886 on 5/14/2014.
 */
angular.module('ui.time', [])

    .constant('uiTimeConfig', {
        hourStep: 1,
        minuteStep: 1,
        showMeridian: true,
        meridians: ['AM', 'PM'],
        readonlyInput: false,
        mousewheel: true
    })

    .directive('uiTime', ['$parse', '$log', 'uiTimeConfig', function ($parse, $log, timepickerConfig) {
        return {
            restrict: 'EA',
            require:'?^ngModel',
            replace: true,
            scope: {},
            templateUrl: 'template/uiTime.html',
            link: function(scope, element, attrs, ngModel) {
                if ( !ngModel ) {
                    return; // do nothing if no ng-model
                }

                var selected = new Date(), meridians = timepickerConfig.meridians;

                var hourStep = timepickerConfig.hourStep;
                if (attrs.hourStep) {
                    scope.$parent.$watch($parse(attrs.hourStep), function(value) {
                        hourStep = parseInt(value, 10);
                    });
                }

                var minuteStep = timepickerConfig.minuteStep;
                if (attrs.minuteStep) {
                    scope.$parent.$watch($parse(attrs.minuteStep), function(value) {
                        minuteStep = parseInt(value, 10);
                    });
                }

                // 12H / 24H mode
                scope.showMeridian = timepickerConfig.showMeridian;
                if (attrs.showMeridian) {
                    scope.$parent.$watch($parse(attrs.showMeridian), function(value) {
                        scope.showMeridian = !!value;

                        if ( ngModel.$error.time ) {
                            // Evaluate from template
                            var hours = getHoursFromTemplate(), minutes = getMinutesFromTemplate();
                            if (angular.isDefined( hours ) && angular.isDefined( minutes )) {
                                selected.setHours( hours );
                                refresh();
                            }
                        } else {
                            updateTemplate();
                        }
                    });
                }

                // Get scope.hours in 24H mode if valid
                function getHoursFromTemplate ( ) {
                    var hours = parseInt( scope.hours, 10 );
                    var valid = ( scope.showMeridian ) ? (hours > 0 && hours < 13) : (hours >= 0 && hours < 24);
                    if ( !valid ) {
                        return undefined;
                    }

                    if ( scope.showMeridian ) {
                        if ( hours === 12 ) {
                            hours = 0;
                        }
                        if ( scope.meridian === meridians[1] ) {
                            hours = hours + 12;
                        }
                    }
                    return hours;
                }

                function getMinutesFromTemplate() {
                    var minutes = parseInt(scope.minutes, 10);
                    return ( minutes >= 0 && minutes < 60 ) ? minutes : undefined;
                }

                function pad( value ) {
                    return ( angular.isDefined(value) && value.toString().length < 2 ) ? '0' + value : value;
                }

                // Input elements
                var inputs = element.find('input'), hoursInputEl = inputs.eq(0), minutesInputEl = inputs.eq(1);

                // Respond on mousewheel spin
                var mousewheel = (angular.isDefined(attrs.mousewheel)) ? scope.$eval(attrs.mousewheel) : timepickerConfig.mousewheel;
                if ( mousewheel ) {

                    var isScrollingUp = function(e) {
                        if (e.originalEvent) {
                            e = e.originalEvent;
                        }
                        //pick correct delta variable depending on event
                        var delta = (e.wheelDelta) ? e.wheelDelta : -e.deltaY;
                        return (e.detail || delta > 0);
                    };

                    hoursInputEl.bind('mousewheel wheel', function(e) {
                        scope.$apply( (isScrollingUp(e)) ? scope.incrementHours() : scope.decrementHours() );
                        e.preventDefault();
                    });

                    minutesInputEl.bind('mousewheel wheel', function(e) {
                        scope.$apply( (isScrollingUp(e)) ? scope.incrementMinutes() : scope.decrementMinutes() );
                        e.preventDefault();
                    });
                }

                scope.readonlyInput = (angular.isDefined(attrs.readonlyInput)) ? scope.$eval(attrs.readonlyInput) : timepickerConfig.readonlyInput;
                if ( ! scope.readonlyInput ) {

                    var invalidate = function(invalidHours, invalidMinutes) {
                        ngModel.$setViewValue( null );
                        ngModel.$setValidity('time', false);
                        if (angular.isDefined(invalidHours)) {
                            scope.invalidHours = invalidHours;
                        }
                        if (angular.isDefined(invalidMinutes)) {
                            scope.invalidMinutes = invalidMinutes;
                        }
                    };

                    scope.updateHours = function() {
                        var hours = getHoursFromTemplate();
                        $log.debug('updateHours: ' + hours);
                        if ( angular.isDefined(hours) ) {
                            selected.setHours( hours );
                            refresh( 'h' );
                        } else {
                            invalidate(true);
                        }
                    };

                    hoursInputEl.bind('blur', function(e) {
                        if ( !scope.validHours && scope.hours < 10) {
                            scope.$apply( function() {
                                scope.hours = pad( scope.hours );
                            });
                        }
                    });

                    scope.updateMinutes = function() {
                        var minutes = getMinutesFromTemplate();

                        if ( angular.isDefined(minutes) ) {
                            selected.setMinutes( minutes );
                            refresh( 'm' );
                        } else {
                            invalidate(undefined, true);
                        }
                    };

                    minutesInputEl.bind('blur', function(e) {
                        if ( !scope.invalidMinutes && scope.minutes < 10 ) {
                            scope.$apply( function() {
                                scope.minutes = pad( scope.minutes );
                            });
                        }
                    });
                } else {
                    scope.updateHours = angular.noop;
                    scope.updateMinutes = angular.noop;
                }

                ngModel.$render = function() {
                    var date = ngModel.$modelValue ? new Date( ngModel.$modelValue ) : null;
                    $log.debug('$render: ' + date);
                    if ( isNaN(date) ) {
                        $log.debug('isNan');
                        ngModel.$setValidity('time', false);
                        $log.error('Timepicker directive: "ng-model" value must be a Date object, a number of milliseconds since 01.01.1970 or a string representing an RFC2822 or ISO 8601 date.');
                    } else {
                        if ( date ) {
                            selected = date;
                        }
                        makeValid();
                        ngModel.$setViewValue( new Date(selected) );
                        updateTemplate();
                    }
                };

                // Call internally when we know that model is valid.
                function refresh( keyboardChange ) {
                    makeValid();
                    ngModel.$setViewValue( new Date(selected) );
                    updateTemplate( keyboardChange );
                }

                function makeValid() {
                    ngModel.$setValidity('time', true);
                    scope.invalidHours = false;
                    scope.invalidMinutes = false;
                }

                function updateTemplate( keyboardChange ) {
                    var hours = selected.getHours(), minutes = selected.getMinutes();

                    if ( scope.showMeridian ) {
                        hours = ( hours === 0 || hours === 12 ) ? 12 : hours % 12; // Convert 24 to 12 hour system
                    }
                    scope.hours =  keyboardChange === 'h' ? hours : pad(hours);
                    scope.minutes = keyboardChange === 'm' ? minutes : pad(minutes);
                    scope.meridian = selected.getHours() < 12 ? meridians[0] : meridians[1];
                }

                function addMinutes( minutes ) {
                    var dt = new Date( selected.getTime() + minutes * 60000 );
                    selected.setHours( dt.getHours(), dt.getMinutes() );
                    refresh();
                }

                scope.incrementHours = function() {
                    addMinutes( hourStep * 60 );
                };
                scope.decrementHours = function() {
                    addMinutes( - hourStep * 60 );
                };
                scope.incrementMinutes = function() {
                    addMinutes( minuteStep );
                };
                scope.decrementMinutes = function() {
                    addMinutes( - minuteStep );
                };
                scope.toggleMeridian = function() {
                    addMinutes( 12 * 60 * (( selected.getHours() < 12 ) ? 1 : -1) );
                };
            }
        };
    }])
    .run(["$templateCache", function($templateCache) {
        $templateCache.put("template/uiTime.html",
            '<table>' +
                '<tr>' +
                    '<td class="control-group" ng-class="{\'error\': invalidHours}">' +
                        '<input type="text" ng-model="hours" ng-change="updateHours()" style="width: 50px" class="span1 text-center" ng-mousewheel="incrementHours()" ng-readonly="readonlyInput" maxlength="2"></td>' +
                    '<td>:</td>' +
                    '<td class="control-group" ng-class="{\'error\': invalidMinutes}" style="width: 50px">' +
                        '<input type="text" ng-model="minutes" ng-change="updateMinutes()" style="width: 50px" class="span1 text-center" ng-readonly="readonlyInput" maxlength="2"></td>' +
                    '<td ng-show="showMeridian"><button type="button" ng-click="toggleMeridian()" class="btn btn-primary">{{meridian}}</button></td>' +
                '</tr>' +
            '</table>');
    }])
;



angular.module('wf.framework')
    .directive('wfAccordion', function() {
        return {
            restrict: 'E',
            transclude: true,
            replace : true,
            scope : {
                header : '=',
                open: '=',
                onexpand: '&?',
                oncollapse: '&?',
                onHeaderClick: '&?'
            },
            link: function(scope, elem, attr) {
                scope.toggle = function() {
                    scope.open=!scope.open;

                    if(scope.open) {
                        scope.onexpand({});
                    } else {
                        scope.oncollapse({});
                    }
                };
            },
            templateUrl: 'template/wfAccordion.html'
        }
    })
    .run(["$templateCache", function($templateCache) {
        $templateCache.put("template/wfAccordion.html",
            '<div class="accordion-group arrow-label">' +
                '' +
                '<div class="accordion-heading" data-toggle="collapse">' +
                '<span class="show-hide-arrow" ng-click="toggle()">' +
                '<i class="icon-large default"  ng-class="{\'icon-expand\' : !open, \'icon-collapse\' : open}"></i>' +
                '</span>' +
                '<b ng-click="onHeaderClick()" ng-bind-html="header"></b>' +
                '</div>' +
                '<div  ng-hide="!open" class="accordion-body collapse in" ng-transclude>' +
                '</div>' +
                '</div>');
    }])
;

/**
 * wfAlert directive
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
//This directive is used for showing alert message.
//Used in WindowMessageCommand
    .directive("wfAlert",['$window', function($window) {
	return {
		restrict : 'E',
		replace : true,
		require : 'wfModal',
		scope : {
			message : '=',
			onClose : '='
		},
		template : '<div id="alertPopup"><wf-modal header-title="Alert" show="showAlert" hide-close="true" on-close="onClose();" hide-close-button="true" modal-alert="true" modal-style="width: 500px;" >'+
					  '<table style="width:100%; min-height:130px"><tr><td class="gwt-TextArea gwt-TextArea-readonly" align="center" ><span id="alertMessage">{{message}}</span></td></tr>'+
					  '</table><wf-modal-footer><button type="button" class="btn btn-primary" id="alertOkButton" ng-click="hideAlertPopup()">Close</button></wf-modal-footer>'+
					  '</wf-modal></div>',
		controller : ['$scope', '$element', '$attrs', function($scope, $element, $attrs){
			$scope.showAlert = false;
			$scope.showAlertPopup = function(){
				$scope.showAlert = true;
			};
			$scope.hideAlertPopup = function(){
				$scope.message=undefined;
				if(angular.isFunction($scope.onClose)){
					$scope.onClose();
					$scope.onClose = undefined;
				}
				$scope.showAlert = false;
			};
			$scope.$watch('message', function(newVal, oldVal){
			  if(newVal){
				$scope.showAlertPopup();
			  }
			});
		}]
	};
}]);

/**
 * wfContextMenu,  directive
 *
 * Created by Sudipta Sarkar on 09/26/15.
 *  
 * This is based on https://github.com/Templarian/ui.bootstrap.contextMenu with few minor changes
 * usage
 *
 * <div>
 *   <div ng-repeat="item in items" context-menu="menuOptions">Right Click: {{item.name}}</div>
 * </div>
 *
 * Every menu option has an array with 2-3 indexes. Most items will use the [String, Function] format. If you 
 * need a dynamic item in your context menu you can also use the [Function, Function] format.
 * The first String or function is the menu display string
 * The 2nd function is the callback function when that menu is clicked
 * The third optional index is a function used to enable/disable the item. If the function returns true, the 
 * item is enabled (default). If no function is provided, the item will be enabled by default.
 * A null idex in the array means a divider. (the 2nd item in the following example)
 * e.g.
 * $scope.menuOptions = [
    ['Select', function ($rowScope, $event) { //$rowScope represents the scope of the row/ng-repeat element
        //Do something with $rowscope
    }],
    null, // Divider
    ['Remove', function ($rowScope, $event) {
        //Do something with $rowscope
    }]
 * ];
 *
 * Or
 * $scope.menuOptions = [
    ['Select', function ($rowScope, $event) { //$rowScope represents the scope of the row/ng-repeat element
        //Do something with $rowscope
    }, function ($rowScope, $event){
		return true; //Return a boolean, true/false mean to enable/disable the context menu item.
	}],
    null, // Divider
    ['Remove', function ($rowScope, $event) {
        //Do something with $rowscope
    }, function ($rowScope, $event){
		return true; //Return a boolean, true/false mean to enable/disable the context menu item.
	}]
 * ];
 */


angular.module('wf.framework')
.directive('wfContextMenu', ["$parse", function ($parse) {
    var isInView = function(element){
        var viewport = {};
        viewport.top = $(window).scrollTop();
        viewport.bottom = viewport.top + $(window).height();
        var bounds = {};
        bounds.top = element.offset().top;
        bounds.bottom = bounds.top + element.outerHeight();
        element = null;
        return ((bounds.top <= viewport.bottom) && (bounds.bottom <= viewport.bottom));
    };
    var renderContextMenu = function ($scope, event, options, model) {
        if (!$) { var $ = angular.element; }
        $(event.currentTarget).addClass('context');
        var $contextMenu = $('<div></div>');
        $contextMenu.addClass('dropdown clearfix');
        var $ul = $('<ul>');
        $ul.addClass('dropdown-menu');
        $ul.attr({ 'role': 'menu' });
        angular.forEach(options, function (item, i) {
            var $li = $('<li>');
            if (item === null) {
                $li.addClass('divider');
            } else {
                var $a = $('<a>');
                $a.attr({ tabindex: '-1', href: '#' });
                var text = typeof item[0] == 'string' ? item[0] : item[0].call($scope, $scope, event, model);
                $a.text(text);
                $li.append($a);
                var enabled = angular.isDefined(item[2]) ? item[2].call($scope, $scope, event, text, model) : true;
                if (enabled) {
                    $li.on('click', function ($event) {
                        $event.preventDefault();
                        $scope.$apply(function () {
                            $(event.currentTarget).removeClass('context');
                            $contextMenu.remove();
                            item[1].call($scope, $scope, event, model);
                        });
                    });
                } else {
                    $li.on('click', function ($event) {
                        $event.preventDefault();
                    });
                    $li.addClass('disabled');
                }
            }
            $ul.append($li);
        });
        $ul.css({
            display: 'block',
            position: 'absolute',
            left: event.pageX + 'px',
            top: event.pageY + 'px'
        });
        $contextMenu.append($ul);
        var height = Math.max(
            document.body.scrollHeight, document.documentElement.scrollHeight,
            document.body.offsetHeight, document.documentElement.offsetHeight,
            document.body.clientHeight, document.documentElement.clientHeight
        );
        $contextMenu.css({
            width: '100%',
            height: height + 'px',
            position: 'fixed',
            top: 0,
            left: 0,
            zIndex: 9999
        });
        $(document).find('body').append($contextMenu);
        if(!isInView($ul)){
            $ul.css({
                display: 'block',
                position: 'absolute',
                left: event.pageX + 'px',
                top: (event.pageY-$ul.outerHeight()) + 'px'
            });
        }
        $contextMenu.on("mousedown", function (e) {
            if ($(e.target).hasClass('dropdown')) {
                $(event.currentTarget).removeClass('context');
                $contextMenu.remove();
            }
        }).on('contextmenu', function (event) {
            $(event.currentTarget).removeClass('context');
            event.preventDefault();
            $contextMenu.remove();
        });
    };
    return function ($scope, element, attrs) {
        element.on('contextmenu', function (event) {
			var options = $scope.$eval(attrs.wfContextMenu);
			if (options instanceof Array && options.length === 0) {
				return;
			}
            event.stopPropagation();
            $scope.$apply(function () {
                event.preventDefault();
                var options = $scope.$eval(attrs.wfContextMenu);
                var model = $scope.$eval(attrs.model);
                if (options instanceof Array) {
                    if (options.length === 0) { return; }
                    renderContextMenu($scope, event, options, model);
                } else {
                    throw '"' + attrs.contextMenu + '" not an array';
                }
            });
        });
    };
}]);
/**
 * Created by Sudipta Sarkar on 3/6/14.
 */



angular.module('wf.framework')
    .directive('helpFrame', ['$rootScope', function($rootScope){
	    return {
	      restrict: 'EA',
	      scope: {
	        src:'@src',
	        height:'@height',
	        width:'@width',
	        scrolling:'@scrolling'
	      },
	      template: '<iframe class="iframe" height="{{height}}" width="{{width}}" frameborder="0" border="0" scrolling="{{scrolling}}" style="margin-left:4px" src=""></iframe>',
          compile: function(element, attr){
                return {
                     pre: function(scope, element, attr, controller){
                        var loadedSrc = '';
                        var loadHelpFrame = function(){
                            //Conditions make sure that once the files are loaded on a click for a particular source it will not again loaded.
                            if(true == $rootScope.loadFrame && loadedSrc != scope.src){
                                element.find('iframe').attr('src', scope.src);
                                $rootScope.loadFrame = false;
                                loadedSrc = scope.src;
                            }
                        }
                        $rootScope.$watch('loadFrame', loadHelpFrame);
                        scope.$watch('src', loadHelpFrame);
                     }
                 }
            }
	    };
	}])
	.directive('wfHelp', function(){
		return {
	      restrict: 'E',
	      replace : true,
	      template: '<div class="help-icon" help-link help-content="#help-content"	main-content="#wrap" help-close=".help-close" help-width="300px">'+
	    			'<i class="icon-large icon-question-sign"></i>'+
	    			'</div>'
	    };
	})
	.directive('helpLink', ['$rootScope', function($rootScope) {
	  return {
	    restrict: 'A',
	    link: function(scope, elem, attrs) {
	      var panel = elem.bigSlide({
	        menu: attrs.helpContent,
	        menuWidth: attrs.helpWidth,
	        push: attrs.mainContent
	      }); 
	      
		  $rootScope.loadFrame = false;
          elem.bind('click', function() {
             $rootScope.loadFrame = true;
             $rootScope.$apply()
          });
		  
	      // this attaches click event handlers to all elements via a passed in selector
	      // these will close the panel
	      $(attrs.helpClose).click(function() {
	        panel.close();  
	      })

          elem.on('$destroy', function(){
              $(attrs.helpClose).unbind();
          })
	    }
	  }
	}]);

/**
 *  Main grid directive
 */

/**
 //USAGE

 tableGridOptions = {
  	data : 'tabledata',
  	title : 'Search User Results',


	//enables editing
	enableEdit : true,

	//enables paging
	enablePaging : true,
	//enables repeated paging links at bottom of grid
	enablePagingBottom : true,

	//paging options
	paging : {
                startIndex : 1,
                currentPage : 1,
                totalPages : 1,
                totalRecords : 0,
                rowsPerPage : 25,
                endIndex : 25
    	};,

	//enables sorting - only server side currently
	enableSorting : true,
	enableDefaultSortButton : true,

	//enables grouping
	enableGrouping : true,

 	//if not provided and grouping is enabled then data array should be of structure [{groupBy:'groupingfield, dataList : []'}]
	groupInfo : {
		// group column header name
		displayName : 'Group',

		//groupBy field (default - 'groupBy')
		field :'subId',

		//results field (default - 'dataList')
		data : 'results'
	},

	sortInfo : {fields:['firstname'],directions:['asc']},
	// only applicable if enableDefaultSortButton is true.  Establishes the baseline/default sort configuration used
	// to determine if the the button should be enabled or not
	defaultSortInfo : {fields:['firstname'],directions:['asc']},

	//use server side sorting (default - false)
	useExternalSorting : true,

	// not implemented yet
	useExternalPaging : true,

	//To enable/ disable the expand collapse feature on a grid use below.
	enableTableExpandCollapse: true

	columnDefs : [
			{
				//field in the row
				field : 'firstname',

				/column header name
				displayName : 'First Name'

				//populate column with the template specified
				// record can be accessed  using variable 'row' and column field can be accessed by 'COL_FIELD'
				//here 'row.firstname' or 'COL_FIELD' represents same
				cellTemplate : '<a>row.firstname<a>',

				// enables innerCell (a nested cell that will float in zIndex across adjacent cells
				// simulating COLSPAN type behaviors without requiring the containing cell to do so - allows for
				// expanded details as used in the fulfillment pipeline page for contact and loan details
                innerCellTemplate: '<span>Bar((((((((((((((((((((((((((((((((()))))))))))))))))))))))))))))))))))))))))))))))))))))</span>
			},
			{
				field : 'lastname',
				displayName : 'Last Name'
			},
			{
				field : 'sub',
				displayName : 'Sub ID',

				// makes field non editable (default - editable)
				editable : false
			}, {
				field : 'dept',
				displayName : 'Department'
			} ]
  };
 **/


angular.module('wf.framework') // By not including the dependencies this will not replace the existing wf.framework
    .factory('wfGridService', ['$rootScope', '$injector', '$q', function($rootScope, $injector, $q) {
        function collectionHas(a, b) { //helper function (see below)
            for(var i = 0, len = a.length; i < len; i ++) {
                if(a[i] == b) return true;
            }
            return false;
        }

        function findParentBySelector(elm, selector) {
            if (collectionHas(elm, selector)) {
                // short circuit if already there
                return elm;
            }
            var all = document.querySelectorAll(selector);
            var cur = elm.parentNode;
            while(cur && !collectionHas(all, cur)) { //keep going up until you find a match
                cur = cur.parentNode; //go up
            }
            return cur; //will return null if not found
        }

        function getSortInfo($scope) {
            if (!$scope.options.sortInfo) {
                $scope.options.sortInfo = {};
                $scope.options.sortInfo.fields = [];
                $scope.options.sortInfo.directions = [];
                return $scope.options.sortInfo;
            } else {
                return $scope.options.sortInfo;
            }
        }

        function defaultSortDisabled($scope) {
            return $scope.options.initialSortOrder;
        }

        function defaultSort($scope) {
            if ($scope.options.enableDefaultSortButton && $scope.options.sortInfo && !defaultSortDisabled($scope)) {
                $scope.changeSortColumn($scope.options.defaultSortInfo.fields[0]);

                if (!($scope.options.useExternalSorting == undefined || $scope.options.useExternalSorting == true)) {
                    $scope.sortInternally($scope.options.sortInfo.fields[0]);
                } else {
                    $scope.loader();
                }
                $scope.options.initialSortOrder = true;
                if ($scope.options.enablePaging) {
                    $scope.resetCurrentPage();
                }
            }
        }

        function isDefaultSortInEffect($scope) {
            if (! $scope.options.enableDefaultSortButton || ! $scope.options.sortInfo ||
                angular.equals($scope.options.defaultSortInfo, getSortInfo($scope)) ||
                // for purposes of this comparison, we will equate null and undefined
                (($scope.options.defaultSortInfo.fields[0] === null || $scope.options.defaultSortInfo.fields[0] === undefined) &&
                 ($scope.options.sortInfo.fields[0] === null || $scope.options.sortInfo.fields[0] === undefined))) {
                return true;
            }
            return false;
        }

        function isSortable(colDef) {
            if (colDef.sortable == undefined || colDef.sortable == true) {
                if (colDef.field) {
                    colDef.sortable = true;
                    return true;
                }
            }
            return false;
        };

        function updateGridRows($scope, $log) {
            $scope.rows = [];

            if ($scope.options.enableGrouping) {
                if (typeof($scope.$eval($scope.options.data)) !== 'undefined') {
                    $scope.rows = $scope.$eval($scope.options.data);
                }
            } else {
                //Added by Sudipta
                $scope.options.data = $scope.options.data.replace('ROW_INDEX', $scope.rowIndex);
                $scope.rows.push($scope.$eval($scope.options.data));
                //$scope.rows.push($scope.$eval($scope.options.data+" | orderBy:'firstname'"));
            }

            if (typeof($scope.$eval($scope.options.data)) === 'undefined' || ($scope.$eval($scope.options.data) && $scope.$eval($scope.options.data).length === 0)) {
                // create an empty row to enable '-'
                if ($scope.options.enableGrouping) {
                    $scope.rows[0] = {};
                } else {
                    $scope.rows[0] = [{}];
                }
            }

            if ($scope.options.enableSorting && !($scope.options.useExternalSorting == undefined || $scope.options.useExternalSorting == true)) {

                if ($scope.options.enablePaging) {
                    $log.warn("Paging is enabled with internal sorting... Sort result might vary in different pages")
                }

                var sortInfo = $scope.options.sortInfo;

                if (sortInfo) {
                    var fields = sortInfo.fields;
                    var orders = sortInfo.directions;

                    angular.forEach(fields, function(field, key) {
                        $scope.sortRowsInternally(field, orders[key]);
                    });
                }
            }
        };

        function applyColumnSecurity(namespace, columnDefs) {
            var securityService;
            try {
                securityService = $injector.get('securityService');
            } catch (err) {
                return;
            }
            angular.forEach(columnDefs, function(colDef) {
                var id = colDef.columnId || colDef.id;
                if (id) {
                    var permission = securityService.getElementPermission(namespace, id);
                    if (permission === 'DENY' || permission.action === 'DENY') {
                        colDef.hide = true;
                    }
                    if($rootScope.securityHelperEnabled) {
                        var securityRule = null;
                        if (permission && angular.isObject(permission)) {
                            securityRule = permission.condition;
                        }
                        if (!$rootScope.securityInfo[namespace]){
                            $rootScope.securityInfo[namespace] = [];
                        }
                        $rootScope.securityInfo[namespace].push({
                            elementId: id,
                            permission: permission,
                            inheritedNamespace: true,
                            childElements: [],
                            appliedSecurityRule : securityRule !== null ? securityRule : null
                        });

                    }
                }
            });
        };

        function getBlockElements(nodes) {
            var startNode = nodes[0],
                endNode = nodes[nodes.length - 1];
            if (startNode === endNode) {
                return $(startNode);
            }

            var element = startNode;
            var elements = [element];

            do {
                element = element.nextSibling;
                if (!element) break;
                elements.push(element);
            } while (element !== endNode);

            return $(elements);
        };
        // Allow for the the resetting of the saved scroll value.
        function resetScrollValue(id) {
            if (id) {
                this.scrollValues[id] = null;
            }
            else if (id === undefined) {
                this.scrollValues = {};
            }
        }

        //Allows the fn function to run after post digest cycle
        function runPostDigest(fn) {
            var cancelFn, defer = $q.defer();
            defer.promise.$$cancelFn = function ngAnimateMaybeCancel() {
                cancelFn && cancelFn();
            };

            $rootScope.$$postDigest(function ngAnimatePostDigest() {
                cancelFn = fn(function ngAnimateNotifyComplete() {
                    defer.resolve();
                });
            });

            return defer.promise;
        }
		
		function getExpandState(gridId) {
			if (this.expandStates[gridId])
				return this.expandStates[gridId];
			return false;
		}
		
		function setExpandState(gridId, state) {
			this.expandStates[gridId] = state;			
		}
		
		function resetExpandState() {
			this.expandStates = [];
		}

        return {
            collectionHas: collectionHas,
            findParentBySelector: findParentBySelector,
            getSortInfo: getSortInfo,
            defaultSortDisabled: defaultSortDisabled,
            defaultSort: defaultSort,
            isDefaultSortInEffect: isDefaultSortInEffect,
            isSortable: isSortable,
            updateGridRows: updateGridRows,
            applyColumnSecurity: applyColumnSecurity,
            resetScrollValue: resetScrollValue,
            scrollValues: {},
			expandStates: [],
            getBlockElements : getBlockElements,
            runPostDigest : runPostDigest,
			getExpandState: getExpandState,
			setExpandState: setExpandState,
			resetExpandState: resetExpandState
        }
    }])
    .directive('wfGrid', ['$compile', '$log', '$sce', 'wfGridService', function($compile, $log, $sce, wfGridService) {
        return {
            restrict: 'E',
            scope: true,

            controller: ['$scope', function($scope) {
        var dataListeners = [];
                this.registerDataListener = function(listener) {
        	dataListeners.push(listener);
        };

                this.notifyDataListeners = function(dataPath) {
            angular.forEach(dataListeners, function(listener) {
                listener(dataPath);
            });
                };
            }],

            compile: function() {
                return {
                    pre: function($scope, $element, $attrs, gridCtrl) {

                        $scope.options = $scope.$eval($attrs.detail);
                        if($attrs.id){
                            $scope.options.widgetId = $attrs.id;
                        }
                        if ($scope.options.columnDefsString != null) {
                            $scope.options.columnDefs = $scope.$parent.$eval($scope.options.columnDefsString);
                            //console.log("columnDefs: " + $scope.options.columnDefs)
                            wfGridService.applyColumnSecurity($scope.namespace, $scope.options.columnDefs);
                        }

                        if ($attrs.style) {
							$scope.style = "width:100%; " + $attrs.style;
						} else {
							$scope.style = "width:100%;";
						}
                        if ($attrs.height) {
                            $scope.innerStyle = {'max-height': $attrs.height, 'overflow': 'auto','width' : '100%'};
                        }else{
                            $scope.innerStyle = {'overflow': 'auto','width' : '100%'};
                        }
                        //Remove the id in wf-gris so that the id is present only in the html table element
                        $element.removeAttr("id");
                        /*if ($scope.options.title != null) {
                         $scope.options.title = $sce.trustAsHtml($scope.options.title);
                         }*/
						 
						//Code for expand/collapse grid 
						if ($scope.options.enableTableExpandCollapse) {
							$scope.tableBodyExpanded = false;
							if ($scope.options.widgetId) {
								$scope.tableBodyExpanded = wfGridService.getExpandState($scope.options.widgetId);
								
							}
							$scope.expandCollapse = function() {
								$scope.tableBodyExpanded = !$scope.tableBodyExpanded;
								if ($scope.options.widgetId) {
									wfGridService.setExpandState($scope.options.widgetId, $scope.tableBodyExpanded);
								}
							}
						}
						
                        $scope.loader = function() {
                            var loaderFn = $attrs.loader;
                            if (loaderFn.indexOf("(") != -1) {
                                loaderFn = loaderFn.substring(0, loaderFn.indexOf("("));
                            }
                            $scope.$eval(loaderFn + "(options.sortInfo, options.paging)");
                        };

                        $scope.sortRowsInternally = function(field, order) {

                            var reverse = false;

                            if (!order) {
                                order = 'asc';
                            }

                            if (order == 'desc') {
                                reverse = true;
                            }

                            if (!$scope.options.enableGrouping) {
                                $scope.rows = []
                                $scope.rows.push($scope.$eval($scope.options.data + " | orderBy:'" + field + "':" + reverse));
                            } else {
                                $log.warn('sorting based on grouping is not implement yet')
                            }
                        };

                        $scope.defaultSortDisabled = function() {
                            return wfGridService.defaultSortDisabled($scope);
                        }

                        $scope.defaultSort = function() {
                            wfGridService.defaultSort($scope);
                        }

                        var updateGridRows = wfGridService.updateGridRows;

                        updateGridRows($scope, $log);

                        var unwatchData = $scope.$watchCollection($scope.options.data, function(newVal) {
                            if (newVal) {
                            	updateGridRows($scope, $log);
                                gridCtrl.notifyDataListeners($scope.options.data);
                            }

                        });

                        var unwatchColumnDefsString = function(){};
                        if ($scope.options.columnDefsString != null) {
                        	unwatchColumnDefsString = $scope.$watch($scope.options.columnDefsString, function (newVal, oldVal) {
                                //console.log("coldef updated");
                                if (newVal) {
                                    if ($scope.options.columnDefsString != null) {
                                        $scope.options.columnDefs = newVal;
//                                        console.log("columnDefs: " + $scope.options.columnDefs)
                                        wfGridService.applyColumnSecurity($scope.namespace, $scope.options.columnDefs);
                                    }
                                    updateGridRows($scope, $log);
                                }

                            }, true);
                        }

                        $element.on("$destroy", function(){
                        	unwatchData();
                        	unwatchColumnDefsString();
                        });
                    }
                }
            },

            templateUrl: 'template/wfGrid.html'
        };
    }])

/**
 * Grid definition for Scrollable Grid with fixed headers
 *
 * Currently does not support columnDefsString
 */
    .directive('wfScrollableGrid', ['$compile', '$log', '$sce', '$window', '$timeout', 'wfGridService', function ($compile, $log, $sce, $window, $timeout, wfGridService) {
        return {
            restrict: 'E',
            scope: true,
            compile: function () {
                return {
                    pre: function ($scope, $element, $attrs) {

                        $scope.isScrollableGrid = true;
                        $scope.options = $scope.$eval($attrs.detail);
                        if($attrs.id){
                            $scope.options.widgetId = $attrs.id;
                        }
                        if($attrs.optimizeHeaders == "true"){
                        	$scope.updateHeaderMinWidths = true;
                        }else{
                        	$scope.updateHeaderMinWidths = false;
                        }

                        if ($scope.options.columnDefsString != null) {
                            $scope.options.columnDefs = $scope.$parent.$eval($scope.options.columnDefsString);
                            wfGridService.applyColumnSecurity($scope.namespace, $scope.options.columnDefs);
                        }

                        if ($attrs.style) {
							$scope.style = "width:100%; " + $attrs.style;
						} else {
							$scope.style = "width:100%;";
						}
                        if ($attrs.scrollableHeight) {
                            $scope.innerStyle = {'max-height': ($attrs.scrollableHeight?$attrs.scrollableHeight:'500px'), 'overflow': 'auto','width':'100%'};
                        } else {
                            $scope.innerStyle = {'max-height': '300px','overflow': 'auto','width':'100%'};
                        }
                        // The default behavior is to restore scroll position upon returning to the page.
                        var scrollTimer;
                        if (typeof $scope.options.restoreScroll === 'undefined' || $scope.options.restoreScroll) {
                            // Get wf-table-body scroll position as we are leaving the page
                            $scope.$on("$stateChangeStart", function () {
                                var id = $scope.options.widgetId;
                                if (id) {
                                    wfGridService.scrollValues[id] = $scope.getScrollPos();
//                                    console.log("restoreScroll: stateChangeStart event: " + wfGridService.scrollValues[id] + " id: " + id);
                                }
                            });

                            // Load wf-table-body scroll position after everything has rendered
                            scrollTimer = $timeout(function () {
                                var id = $scope.options.widgetId;
                                if (id) {
                                    var scrollY = wfGridService.scrollValues[id] ? wfGridService.scrollValues[id] : 0;
                                    if (scrollY > 0) {
//                                        console.log("restoreScroll: Setting Scroll to: " + scrollY);
                                        $scope.setScrollPos(scrollY);
                                        $scope.scrollPos(scrollY);
                                    }
                                }
                            }, 0);
                        }

                        // Cleanup the scrollTimer
                        $element.on("$destroy", function () {
                            if (scrollTimer) {
                                $timeout.cancel(scrollTimer);
                            }
                        });
                        $scope.loader = function () {
                            var loaderFn = $attrs.loader;
                            if (loaderFn.indexOf("(") != -1) {
                                loaderFn = loaderFn.substring(0, loaderFn.indexOf("("));
                            }
                            $scope.$eval(loaderFn + "(options.sortInfo, options.paging)");
                        };

                        $scope.sortRowsInternally = function (field, order) {

                            var reverse = false;

                            if (!order) {
                                order = 'asc';
                            }

                            if (order == 'desc') {
                                reverse = true;
                            }

                            if (!$scope.options.enableGrouping) {
                                $scope.rows = []
                                $scope.rows.push($scope.$eval($scope.options.data + " | orderBy:'" + field + "':" + reverse));
                            } else {
                                $log.warn('sorting based on grouping is not implement yet')
                            }
                            $scope.fixHeaderWidths();
                        };

                        $scope.defaultSortDisabled = function() {
                            return wfGridService.defaultSortDisabled($scope);
                        }

                        $scope.defaultSort = function() {
                            wfGridService.defaultSort($scope);
                        }

                        var isFixHeadersInProgress = false;
                        var isFixHeadersWatchTimeoutInProgress = false;
                        $scope.fixHeaderWidths = function(){
                            if(!isFixHeadersInProgress){
                                var fixHeaders = $timeout(function(){
                                    if($element.find(".wf-table").is(":visible")) {
                                        if(isFixHeadersInProgress){
                                            fixHeaderWidths();
                                            $timeout.cancel(fixHeaders);
                                            isFixHeadersInProgress = false;
                                        }
                                    }else{
                                        var fixAfterVisible = undefined;
                                        var renderedWatch = $scope.$watch(
                                            function() {
                                                if(!isFixHeadersWatchTimeoutInProgress){
                                                    isFixHeadersWatchTimeoutInProgress = true;
                                                    if(fixAfterVisible){
                                                        $timeout.cancel(fixAfterVisible);
                                                    }
                                                    fixAfterVisible = $timeout(function(){
                                                        if($element.find(".wf-table").is(":visible") && isFixHeadersInProgress){
                                                            fixHeaderWidths();
                                                            $timeout.cancel(fixHeaders);
                                                            $timeout.cancel(fixAfterVisible);
                                                            isFixHeadersInProgress = false;
                                                        }
                                                        isFixHeadersWatchTimeoutInProgress = false;
                                                    },0,false);
                                                }

                                                return $element.find(".wf-table").is(":visible");
                                            },
                                            function(isVisible){
                                                if(isVisible){
                                                    renderedWatch();
                                                }
                                            }, true);

                                    }
                                },0,false);
                                isFixHeadersInProgress = true;
                            }
                        }

                        var updateGridRows = wfGridService.updateGridRows;

                        updateGridRows($scope, $log);

                        var unwatchData = $scope.$watchCollection($scope.options.data, function (newVal) {
                            if (newVal) {
                                updateGridRows($scope, $log);
                                $scope.fixHeaderWidths();
                            }

                        });

                        var unwatchColumnDefsString = function(){};
                        if ($scope.options.columnDefsString != null) {
                        	unwatchColumnDefsString =  $scope.$watch($scope.options.columnDefsString, function (newVal, oldVal) {
                                if (newVal) {
                                    if ($scope.options.columnDefsString != null) {
                                        $scope.options.columnDefs = newVal;
                                        wfGridService.applyColumnSecurity($scope.namespace, $scope.options.columnDefs);
                                    }
                                }
                            }, true);
                        }

                        var unwatchColumnDefsLength = $scope.$watch('options.columnDefs.length', function(newVal){
                            if(newVal) {
                                $scope.fixHeaderWidths();
                            }
                        });

                        $element.on('$destroy', function(){
                        	unwatchColumnDefsLength();
                        	unwatchColumnDefsString();
                        	unwatchData();
                        });

                        function fixHeaderWidths() {

                        	var wfTableHeaderGroup = $element.find('.wf-table .table-column-header-group .wf-grid-column-header-group');
                            var wfRows = $element.find('.wf-table .wf-table-body');

                            if($(wfRows).get(0).scrollHeight > $(wfRows).get(0).clientHeight){
                            	wfTableHeaderGroup.css({'margin-right': '12px'});
                            } else{
                                wfTableHeaderGroup.css({'margin-right': '0px'});
                            }


                            var rows = $element.find('.wf-table .wf-table-body tr:first td');
                            var columns = $element.find(" .wf-table .table-column-header th");

                            if($scope.updateHeaderMinWidths){
                            	rows.each(function(index, el){
                            		var width = $(el).outerWidth();
                            		var columnOuterWidth = $(columns[index]).outerWidth();
                            		$(columns[index]).css('max-width','');
                            		$(columns[index]).css('min-width','');

                                	if(width && width < columnOuterWidth){
                                        $(columns[index]).css('width',width);
                                        var outerWidth = $(columns[index]).outerWidth();
                                        if( outerWidth && (outerWidth <= $scope.options.columnDefs[index].$minwidth))
                                        {
                                            $(el).css('min-width',outerWidth);
                                            $(el).css('max-width',outerWidth);
                                        }else{
                                            $(el).css('min-width',$scope.options.columnDefs[index].$minwidth);
                                            $(el).css('max-width',$scope.options.columnDefs[index].$minwidth);
                                        }
                                        $(columns[index]).css('width','');
                                    }else if(width && width > columnOuterWidth){
                                    	//$(el).css('min-width',width);
                                        $(el).css('max-width',width);
                                    }
                                });
                            }

                            columns.each(function(index,el){
                                el = $(el);
                                el.css('min-width', '');
                                el.css('max-width', '');
                                if(rows[index]){
                                    var width = 0;
                                    var minWidth = 0;
                                    var padding = $(rows[index]).outerWidth() - $(rows[index]).width();
                                    var width = $(rows[index]).width() + padding ;
                                    if(width){
                                        el.css('min-width', width);
                                        el.css('max-width', width);
                                    }
                                }
                            });
                        }
                    }
                }
            },

            templateUrl: 'template/wfScrollableGrid.html'
        };
    }])

/**
 * Directive to include pagination in the grid
 */

    .directive('wfGridPaging', ['wfGridService', function(wfGridService) {
        return {
            restrict: 'E',
            scope: true,
            compile: function() {
                return {
                    pre: function($scope, $element, $attrs) {
                        $scope.pageSizes = [10, 25, 50, 75, 100];   // , 'All' (has been removed)
                        $scope.paginationSize = 4;

                        if (! $scope.options.paging) {
                            $scope.options.paging = {}; //default to empty if not present
                        }
                        if ($scope.options.paging.rowsPerPage) {
                            $scope.options.paging.selectedPageSize = $scope.options.paging.rowsPerPage;
                        } else {
                            $scope.options.paging.rowsPerPage = $scope.options.paging.selectedPageSize = 25;    // default value - 25
                        }

                        $scope.showFirstOrPreviousPageLink = false;

                        $scope.showLastOrNextPageLink = false;

                        var determineStartEndIndex = function() {
                            $scope.options.paging.startIndex = (($scope.options.paging.currentPage * $scope.options.paging.rowsPerPage) - $scope.options.paging.rowsPerPage) + 1;
                            var endIndex = ($scope.options.paging.currentPage * $scope.options.paging.rowsPerPage);
                            if (endIndex > $scope.options.paging.totalRecords) {
                                endIndex = $scope.options.paging.totalRecords
                            }
                            if($scope.options.paging.startIndex < 1 && $scope.options.paging.totalPages > 0 ){
                                $scope.options.paging.startIndex = 1;
                                endIndex = $scope.options.paging.rowsPerPage
                            }

                            if($scope.options.paging.totalPages == 0 ){
                                $scope.options.paging.startIndex = 0;
                                endIndex = 0;
                            }
                            $scope.options.paging.endIndex = endIndex;
                        }

                        var calculatePaging = function() {

                            var totalRecords = $scope.options.paging.totalRecords;
                            $scope.options.paging.totalPages = (totalRecords != undefined || totalRecords === 0) ? Math.ceil(totalRecords / $scope.options.paging.rowsPerPage) : 1;
                            determineStartEndIndex();

                            $scope.pages = [];
                            for (var page_index = 0; page_index < $scope.options.paging.totalPages; page_index++) {
                                if (page_index == 0) {
                                    $scope.pages.push({number: page_index + 1, active: true});
                                } else {
                                    $scope.pages.push({number: page_index + 1});
                                }
                            }
                            $scope.previousDisabled = true;
                            $scope.nextDisabled = false;

                        }

                        var updateLinkEnableStatus = function() {
                            if ($scope.options.paging.currentPage > 1) {
                                $scope.showFirstOrPreviousPageLink = true;
                                $scope.previousDisabled = false;
                            } else {
                                $scope.showFirstOrPreviousPageLink = false;
                                $scope.previousDisabled = true;
                            }
                            if ($scope.options.paging.currentPage == $scope.options.paging.totalPages ||
                                $scope.options.paging.totalPages === 0) {
                                $scope.showLastOrNextPageLink = false;
                                $scope.nextDisabled = true;
                            } else {
                                $scope.showLastOrNextPageLink = true;
                                $scope.nextDisabled = false;
                            }
                        }

                        var unwatchPaging = $scope.$watch('options.paging', function(newValue, oldValue) {
                            if (newValue)
                                calculatePaging();
                        });

                        var unwatchCurrentPage = $scope.$watch('options.paging.currentPage', function(newValue, oldValue) {
                            if (newValue !== oldValue) {
                                if (newValue === 1) {
                                    $scope.$parent.resetCurrentPage();
                                }
                            }
                        });

                        $scope.loadData = function() {
                            //$scope.options.paging.totalRecords = 0;
                            //calculatePaging();
                            $scope.loader();
                        }

                        var unwatchTotalRecords = $scope.$watch('options.paging.totalRecords', function(newValue, oldValue) {
                            if (newValue  || newValue === 0) {
                                $scope.options.paging.currentPage = 1;
                                $scope.options.paging.startIndex = 1;
                                $scope.options.paging.oldPage = $scope.options.paging.currentPage;
                                calculatePaging();

                                updateLinkEnableStatus();
                            }
                        });

                        var unwatchRowsPerPage = $scope.$watch('options.paging.rowsPerPage', function(newValue, oldValue) {
                            if (newValue) {
                                calculatePaging();

                                updateLinkEnableStatus();
                            }
                        });

                        $element.on('$destroy', function(){
                        	unwatchRowsPerPage();
                        	unwatchTotalRecords();
                        	unwatchCurrentPage();
                        	unwatchPaging();
                        });

                        $scope.getFirstPage = function() {
                            $scope.options.paging.currentPage = 1;
                            $scope.options.paging.startIndex = 1;
                            $scope.options.paging.oldPage = $scope.options.paging.currentPage;
                            $scope.loadData();
                        }

                        $scope.getPreviousPage = function() {
                            //$scope.options.paging.currentPage = $scope.options.paging.currentPage - 1;
                            //$scope.loadData();
                            var pageNumber =  $scope.options.paging.currentPage - 1;
                            if (pageNumber < 1 || pageNumber > $scope.options.paging.totalPages) {
                                return;
                            }
                            $scope.selectPage(pageNumber);

                        }

                        $scope.getNextPage = function() {
                            //$scope.options.paging.currentPage = $scope.options.paging.currentPage + 1;
                            //$scope.loadData();
                            var pageNumber =  $scope.options.paging.currentPage + 1;
                            if (pageNumber < 1 || pageNumber > $scope.options.paging.totalPages) {
                                return;
                            }
                            $scope.selectPage(pageNumber);

                        }

                        $scope.getLastPage = function() {
                            $scope.options.paging.currentPage = $scope.options.paging.totalPages;
                            $scope.options.paging.oldPage = $scope.options.paging.currentPage;
                            $scope.loadData();
                        }

                        $scope.perPageListBoxChange = function() {
                            if ($scope.options.paging.selectedPageSize === 'All') {
                                $scope.options.paging.rowsPerPage = $scope.options.paging.totalRecords;
                            } else {
                                $scope.options.paging.rowsPerPage = $scope.options.paging.selectedPageSize;
                            }
                            $scope.options.paging.currentPage = 1;
                            $scope.options.paging.startIndex = 1;
                            $scope.options.paging.oldPage = $scope.options.paging.currentPage;
                            $scope.loadData();
                        }

                        $scope.selectPage = function(pageNumber) {
                            pageNumber = Number(pageNumber).valueOf();
                            if (pageNumber == NaN) {
                                console.log('selectPage called with a non-numeric pageNumber');
                                return false;
                            }
                            if ($scope.options.paging.oldPage && (pageNumber === $scope.options.paging.oldPage)) {
                                // no need to reload existing page
                                return false;
                            }

                            $scope.options.paging.currentPage = pageNumber;
                            $scope.options.paging.oldPage = $scope.options.paging.currentPage;
                            determineStartEndIndex();

                            if (pageNumber < 1 || pageNumber > $scope.options.paging.totalPages) {
                                return;
                            }

                            var containingGrid = wfGridService.findParentBySelector($element[0], '.wf-grid-table');
                            var pagers = containingGrid.getElementsByClassName('pagination-top-container');

                            if (pagers) {
                                for (var i = 0; i < pagers.length; i++) {
                                    var pager = pagers[i];
                                    angular.element(pager).scope().adjustPageLinks(pageNumber, angular.element(pager).scope().pages);
                                }
                            }

                            $scope.loadData();
                        }

                        $scope.adjustPageLinks = function(pageNumber, pages) {
                            if(pages[(pageNumber-1)] !== null && pages[(pageNumber-1)] !== undefined){ // prevents errors on page links when going from page > 1 to blank information
                                var index_Incrementor ;//used to find number of positions to be shifted for identifying the current page position
                                //show paginationSize (4) pages at any point in time if total number of pages are more than paginationSize    (used to be 10)
                                $scope.paginationSize = 4;
                                if($scope.options.paging.totalPages < $scope.paginationSize){
                                    //show actual number of pages if total pages are less than 10
                                    $scope.paginationSize = $scope.options.paging.totalPages;
                                }
                                var tempPaginationSize; // Used to prevent pages[-1] from ever being called
                                if($scope.paginationSize <= 0){
                                    tempPaginationSize = 0;
                                    $scope.paginationSize = 0;
                                } else {

                                    tempPaginationSize = $scope.paginationSize-1;
                                }
                                //midPagination is used to find position of the current page
                                var midPagination = ~~($scope.paginationSize/2);

                                if (pages[0] && pageNumber < pages[midPagination].number) {
                                    if (pages[0].number <= 1) {
                                        index_Incrementor = 0;
                                    } else {
                                        index_Incrementor = -(pages[midPagination].number - pageNumber);
                                    }
                                }

                                if(pages[0] && pageNumber >= pages[midPagination].number) {
                                    if(pages[tempPaginationSize].number >= $scope.options.paging.totalPages
                                        && (pages[tempPaginationSize].number - pageNumber < midPagination)){
                                        index_Incrementor = 0;
                                    }else {
                                        index_Incrementor = pageNumber - pages[midPagination].number;
                                    }
                                }

                                if(pages[0] && index_Incrementor != 0) {
                                    for(var i=0; i< $scope.paginationSize;i++){
                                        pages[i].number = pages[i].number + index_Incrementor;
                                        if(pages[0].number < 1
                                            || pages[i].number < 1){
                                            for(var j=0;j<$scope.paginationSize;j++){
                                                pages[j].number = j + 1;
                                            }
                                            break;
                                        }

                                        if(pages[($scope.paginationSize-1)].number > $scope.options.paging.totalPages
                                            || pages[i].number > $scope.options.paging.totalPages){
                                            for(var j=0;j<$scope.paginationSize;j++){
                                                pages[j].number = $scope.options.paging.totalPages - ($scope.paginationSize-1) + j;
                                            }
                                            break;
                                        }
                                    }
                                }
                                for (var page_index = 0; page_index < $scope.paginationSize; page_index++) {
                                    if (pages[page_index].number == pageNumber) {
                                        pages[page_index].active = true;
                                    } else {
                                        pages[page_index].active = false;
                                    }
                                }

                                if (pageNumber == 1) {
                                    $scope.previousDisabled = true;
                                } else {
                                    $scope.previousDisabled = false;
                                }
                                if (pageNumber == $scope.options.paging.totalPages) {
                                    $scope.nextDisabled = true;
                                } else {
                                    $scope.nextDisabled = false;
                                }
                            }
                        }

                        $scope.setPage = function(pageNumber) {
                            if ($scope.options.paging.currentPage < 1 || $scope.options.paging.currentPage > $scope.options.paging.totalPages) {
                                return;
                            }
                            // pageNumber === $scope.options.paging.currentPage as set by ng-model
                            $scope.selectPage($scope.options.paging.currentPage);
                        }

                        //used to resetting current page
                        //used in sorting
                        $scope.$parent.resetCurrentPage = function() {
                            $scope.options.paging.currentPage = 1;
                            $scope.options.paging.startIndex = 1;
                            $scope.options.paging.oldPage = $scope.options.paging.currentPage;
                            calculatePaging();

                            var containingGrid = wfGridService.findParentBySelector($element[0], '.wf-grid-table');
                            var pagers = containingGrid.getElementsByClassName('pagination-top-container');
                            if (pagers) {
                                for (var i = 0; i < pagers.length; i++) {
                                    var pager = pagers[i];
                                    angular.element(pager).scope().adjustPageLinks($scope.options.paging.currentPage, $scope.pages);
                                }
                            }
                        };

                    }
                };
            },

            replace: true,
            templateUrl: 'template/wfGridPaging.html'
        }
    }])

    .directive('wfGridColumnHeaderGroup', ['$compile', '$log', function ($compile, $log) {

        return {
            restrict: 'C',
            compile: function ($scope) {
                return {
                    pre: function ($scope, $element, $attrs, ctrl) {

                        $scope.scrollHeader = function (scrollLeft, addMargin) {
                            $element.scrollLeft(scrollLeft);
                            if (addMargin) {
                                $element.css({'margin-right': '12px'});
                            } else{
                                $element.css({'margin-right': '0px'});
                            }
                        };

                        var unwatchDataLength = $scope.$watch($scope.options.data + '.length', function (newVal, oldVal) {
                            if (!newVal)
                                $element.css('overflow', 'auto');
                            else
                                $element.css('overflow', 'hidden');

                        });

                        $element.on('$destroy',function(){
                        	unwatchDataLength();
                        });
                    }
                };
            }
        }
    }])

    .directive('wfGridHeaderRow', ['$compile', '$log', 'wfGridService', function($compile, $log, wfGridService) {
        return {
            restrict: 'C',

            compile: function($scope, $element, $attrs) {
                return {
                    pre: function($scope, $element, $attrs) {

                        if ($scope.options.enableDefaultSortButton && ! $scope.options.defaultSortInfo) {
                            // If no defaultSortInfo is specified, then default to no fields and no direction
                            $scope.options.defaultSortInfo = {};
                            $scope.options.defaultSortInfo.fields = [];
                            $scope.options.defaultSortInfo.directions = [];
                        }
                        if (wfGridService.isDefaultSortInEffect($scope)) {
                            $scope.options.initialSortOrder = true;
                        } else {
                            $scope.options.initialSortOrder = false;
                        }

                        $scope.getSortClass = function(field) {

                            if ($scope.options.enableSorting) {

                                var sortInfo = wfGridService.getSortInfo($scope);

                                var fields = sortInfo.fields;
                                var orders = sortInfo.directions;
                                var sortClass = '';
                                angular.forEach($scope.options.columnDefs, function(colDef) {
                                    if (colDef.field == field && wfGridService.isSortable(colDef)) {
                                        sortClass = 'icon-sort';
                                    }
                                });



                                if (fields.indexOf(field) != -1) {
                                    var order = orders[fields.indexOf(field)];

                                    if (order == 'asc')
                                        sortClass = 'icon-sort-up';
                                    else if (order == 'desc')
                                        sortClass = 'icon-sort-down';
                                }
                                return sortClass;
                            }

                        };

                        //function will change sort column
                        $scope.changeSortColumn = function(field) {

                            if ($scope.options.enableSorting) {
                                var sortInfo = wfGridService.getSortInfo($scope);

                                var fields = sortInfo.fields;

                                var orders = sortInfo.directions;

                                var sortOrder = '';

                                if (fields.indexOf(field) != -1) {
                                    sortOrder = orders[fields.indexOf(field)];
                                }

                                if (sortOrder == 'asc') {
                                    sortOrder = 'desc';
                                } else {
                                    sortOrder = 'asc';
                                }

                                // single field sorting
                                if (!($scope.options.enableMultipleSorting)) {
                                    $scope.options.sortInfo = {};
                                    if (field) {
                                        $scope.options.sortInfo.fields = [field];
                                        $scope.options.sortInfo.directions = [sortOrder];
                                    } else {
                                        // if the field specified is null, then we do not want to introduce nulls into the
                                        // options.sortInfo.
                                        // (this is probably coming from a return to default sort request where the
                                        // default is configured to be { fields : [], directions: [] } as in Fulfillment pipeline)
                                        $scope.options.sortInfo.fields = [];
                                        $scope.options.sortInfo.directions = [];
                                    }

                                } else {
                                    //to-do multiple sorting
                                }
                                if (wfGridService.isDefaultSortInEffect($scope)) {
                                    $scope.options.initialSortOrder = true;
                                } else {
                                    $scope.options.initialSortOrder = false;
                                }
                                if($scope.options.enablePaging && ($scope.options.useExternalSorting == undefined
                                    || $scope.options.useExternalSorting == true)) {
                                    $scope.resetCurrentPage();
                                }
                            }
                        };

                        $scope.sortInternally = function(sortField) {

                            if ($scope.options.enableSorting) {
                                var sortInfo = wfGridService.getSortInfo($scope);

                                if (sortInfo) {
                                    var fields = sortInfo.fields;
                                    var orders = sortInfo.directions;

                                    if (fields.indexOf(sortField) != -1) {
                                        var order = orders[fields.indexOf(sortField)];
                                        $scope.sortRowsInternally(sortField, order);
                                    }
                                }
                            }
                        };
                    }
                };
            }
        };
    }])

    .directive('wfGridHeaderCol', ['$compile', '$log', 'wfGridService', function($compile, $log, wfGridService) {

        var DISPLAY_NAME = /DISPLAY_NAME/g;
        var SORT_IMG_TEMPLATE = /SORT_IMG_TEMPLATE/g;
        var SORT_CLASS = /SORT_CLASS/g;
        var CHECKBOX_HANDLER = /CHECKBOX_HANDLER/g;
        var CHECKBOX_DISABLED = /CHECKBOX_DISABLED/g;
        var CHECKBOX_TAG = /CHECKBOX_TAG/g;
        var CHECKBOX_ID_TAG = /CHECKBOX_ID_TAG/g;
		var COL_HEADER_EXPAND_COLLAPSE = /COL_HEADER_EXPAND_COLLAPSE/g;

        var colHeaderTag = '<div class="column-header" ng-class="{sortable : options.enableSorting}">COL_HEADER_EXPAND_COLLAPSE<div class="title">{{DISPLAY_NAME}}CHECKBOX_TAG</div>SORT_IMG_TEMPLATE</div>';
        var colHeaderHtmlTag = '<div class="column-header" ng-class="{sortable : options.enableSorting}">COL_HEADER_EXPAND_COLLAPSE<div class="title" wf-bind-html-unsafe="DISPLAY_NAME"></div>SORT_IMG_TEMPLATE</div>';
        var sotImageTag = '<div ng-click="sortColumn();" class="sort"><i ng-class="SORT_CLASS" class="icon-large default"></i></div>';
        var checkboxTag = '<div><input type="checkbox" CHECKBOX_ID_TAG ng-change="selectDeselectAll()" ng-model="checked"CHECKBOX_DISABLED/></div>';
        var sortAscClass = '';
        var sortDescClass = '';

        return {
            restrict: 'C',
            require: '?^wfGrid',
            compile: function($scope) {
                return {
                    pre: function($scope, $element, $attrs, wfGridCtrl) {

                        var colDef = $scope.colDef;
                        var colheader = '';
                        if(colDef.displayNameHtml){
                            colheader = colHeaderHtmlTag.replace(DISPLAY_NAME, 'colDef.displayNameHtml');
							if(colDef.headerMain) {
                                colheader = colheader.replace(COL_HEADER_EXPAND_COLLAPSE,'<span style="padding-right:3px;">'+
                                    '<a href=""  style="text-decoration:none; color:#ffffff;" ng-click="expandCollapseHeader()" >' +
                                    '<span ng-hide="tableHeaderExpanded" class="icon-large default icon-expand"></span>' +
                                    '<span ng-show="tableHeaderExpanded" class="icon-large default icon-collapse"></span>' +
                                    '</a>' +
                                    '</span>' );
                            } else {
                                colheader = colheader.replace(COL_HEADER_EXPAND_COLLAPSE, '');
                            }
                        } else {
                            colheader = colHeaderTag.replace(DISPLAY_NAME, 'colDef.displayName');
							if(colDef.headerMain) {
                                colheader = colheader.replace(COL_HEADER_EXPAND_COLLAPSE, '<span style="padding-right:3px;">'+
                                    '<a href=""  style="text-decoration:none; color:#ffffff;" ng-click="expandCollapseHeader()" >' +
                                    '<span ng-hide="tableHeaderExpanded" class="icon-large default icon-expand"></span>' +
                                    '<span ng-show="tableHeaderExpanded" class="icon-large default icon-collapse"></span>' +
                                    '</a>' +
                                    '</span>' );
                            }else {
                                colheader = colheader.replace(COL_HEADER_EXPAND_COLLAPSE, '');
                            }
                        }
                        var sortImg = '';
                        if ($scope.colDef.width != null) {
                            $scope.colDef.columnStyle = {width: $scope.colDef.width};
                        }
                        if ($scope.options.enableSorting) {

                            if (wfGridService.isSortable(colDef)) {
                                $scope.sortClass = $scope.getSortClass(colDef.field);
                                sortImg = sotImageTag.replace(SORT_CLASS, 'sortClass');
                            }
                        }
                        if (colDef.showCheckbox) {
                            //checkboxTag = checkboxTag.replace(CHECKBOX_HANDLER, colDef.checkboxHandler);
                            var checkboxDisabledFn = (colDef.checkboxDisabledFn ? ' ng-disabled="colDef.checkboxDisabledFn()"'  : '');
                            checkboxTag = checkboxTag.replace(CHECKBOX_DISABLED,checkboxDisabledFn);
                        	colheader = colheader.replace(CHECKBOX_TAG,checkboxTag);
                            if ($scope.options.widgetId) {
                                colheader = colheader.replace(CHECKBOX_ID_TAG, 'id = "' + $scope.options.widgetId + '-checkbox"');
                            } else {
                                colheader = colheader.replace(CHECKBOX_ID_TAG, '');
                            }
                            colheader = colheader.replace(SORT_IMG_TEMPLATE,'');
                        } else {
                            colheader = colheader.replace(SORT_IMG_TEMPLATE,sortImg);
                            colheader = colheader.replace(CHECKBOX_TAG,'');
                        }

                        $element.append($compile(colheader)($scope));

                        if (colDef.title) {
                            $element.find('.title').attr('title', colDef.title);
                        } else {
                            $element.find('.title').attr('title', colDef.displayName);
                        }
                        $scope.sortColumn = function($event) {

                            if ($scope.options.enableSorting) {
                                if (wfGridService.isSortable(colDef)) {
                                    $scope.changeSortColumn(colDef.field);

                                    if (!($scope.options.useExternalSorting == undefined || $scope.options.useExternalSorting == true)) {
                                        $scope.sortInternally(colDef.field)
                                    } else {
                                        $scope.loader();
                                    }
                                }
                            }
                        };

                        var unwatchSortInfo = $scope.$watch('options.sortInfo', function() {
                            $scope.sortClass = $scope.getSortClass(colDef.field);
                            if (wfGridService.isDefaultSortInEffect($scope)) {
                                $scope.options.initialSortOrder = true;
                            } else {
                                $scope.options.initialSortOrder = false;
                            }
                        });

                        $scope.selectDeselectAll = function() {
                            $scope.$eval($scope.colDef.checkboxHandler + '(' +$scope.checked + ')');
                        };

                        // register the callback to be invoked upon changes in data
                        if (wfGridCtrl && colDef.showCheckbox) {
                            wfGridCtrl.registerDataListener(function(dataPath) {
                                // if the data has changed, we will reset to false
                                if ($scope.checked) {
                                    $scope.checked = false;
                                    // also need to reset checkboxhandler for next time
                                    $scope.$eval($scope.colDef.checkboxHandler + '(' +$scope.checked + ')');
                                }
                            });
                        }

                        $scope.$lastColumn = $scope.$last;

                        $element.on('$destroy', function(){
                        	unwatchSortInfo();
                        });
                    },

                    post: function ($scope, $element, $attrs) {
                       if($scope.isScrollableGrid){
                    	   $scope.initializingColumnHeader = true;
                           var initialMinWidth = true;
                           $scope.colDef.$linkElement = undefined;
                           var unwatchTableVisibility = $scope.$watch(
                               function(){
                                   return {width : $element.outerWidth(),visible:$element.is(':visible')};
                               },function(newVal, oldVal){
                                   if(newVal && newVal.visible && newVal.width){
                                       if( !initialMinWidth && newVal.width < $scope.colDef.$minwidth ){
                                           $scope.colDef.$minwidth =  newVal.width;
                                       }else if(initialMinWidth){
                                           $scope.colDef.$minwidth = newVal.width
                                           initialMinWidth = false;
                                       }
                                   }
                                   if(newVal && newVal.visible && $scope.$last){
                                      // $scope.fixHeaderWidths();
                                   }
                               }, true
                           );

                           $scope.isVisible = function(){
                               return $element.is(':visible');
                           }

                           var unwatchVisibility = $scope.$watch('isVisible()',function(newVal, oldVal){
                                   if(newVal && $scope.$lastColumn && $scope.isScrollableGrid){
                                       $scope.fixHeaderWidths();
                                   }
                           });

                           $element.on('$destroy', function(){
                        	   unwatchVisibility();
                        	   unwatchTableVisibility();
                           });

                           $scope.colDef.$minwidth = $element.outerWidth();
                       }
                  }
                }
            }
        }
    }])

    .directive('wfGridRows', ['$compile', '$log', function($compile, $log) {
        var GROUP_BY = 'groupBy';
        var RESULTS = 'dataList';
        return {
            restrict: 'C',
            compile: function($scope, $element, $attrs) {
                return {
                    pre: function($scope, $element, $attrs) {

                        $scope.datarows = undefined;

                        if ($scope.options.enableGrouping) {
                            $scope.groupingIndex = $scope.$index;
                            var groupByField = GROUP_BY;

                            if ($scope.options.groupInfo) {

                                groupByField = $scope.options.groupInfo.field || GROUP_BY;
                                $scope.groupBy = $scope.$eval('groupRow.' + ($scope.options.groupInfo.field || GROUP_BY));

                                $scope.datarows = $scope.$eval('groupRow.' + ($scope.options.groupInfo.data || RESULTS))

                            } else {
                                $scope.groupBy = $scope.$eval('groupRow.' + GROUP_BY);
                                $scope.datarows = $scope.$eval('groupRow.' + RESULTS);
                            }

                            if (!$scope.datarows && angular.equals(($scope.$eval('rows'))[0], {})) {
                                // Enable no data '-' indication
                                var results = $scope.options.groupInfo.data || RESULTS;
                                $scope.groupRow = {};
                                $scope.groupRow[results] = [];
                                $scope.groupRow[results].push([{}]);

                                var groupBy = $scope.options.groupInfo.field || GROUP_BY;
                                $scope.groupRow[groupBy] = '-';
                            } else if (!$scope.datarows) {
                                $log.error("Grouping is invalid : please check the data structure of the your grouping rows");
                            }

                            $scope.$watch('groupRow.' + groupByField, function(newVal){
                                $scope.groupBy = $scope.$eval('groupRow.' + ($scope.options.groupInfo.field || GROUP_BY));
                            });

                        } else {
                            if ($scope.groupRow && !angular.isArray($scope.groupRow)) {
                                $log.error("Rows are invalid in the grid");
                            }
                            $scope.datarows = $scope.groupRow;
                        }
                    }
                };
            }
        };
    }])

    .directive('wfGridDataRow', ['$compile', '$log', function($compile, $log) {
        return {
            restrict: 'C',

            compile: function($scope, $element, $attrs) {
                return {
                    pre: function($scope, $element, $attrs) {
                        $scope.$watch('$index', function(newVal) {
                            if( newVal || newVal === 0 ){
                                $scope.rowIndex = $scope.$index;
                                $scope.$lastRow = $scope.$last;
                            }
                        });

                        $scope.scrollToRow = function () {
                            $scope.resetScrollPos();
                            $scope.setScrollPos($element.offset().top);
                            $scope.scroll();
                        }
                    }
                };
            }
        };
    }])


    .directive('wfTableBody', ['$compile', '$log', function ($compile, $log) {
        return {
            restrict: 'C',

            compile: function ($scope, $element, $attrs) {
                return {
                    pre: function ($scope, $element, $attrs) {
                        var currentScroll = 0;
                        var scrollPos = 0;
                        $scope.setScrollPos = function (pos) {
                            scrollPos = pos;
                        }
                        $scope.getScrollPos = function () {
                            return $element.get(0).scrollTop;
                        }
                        $scope.resetScrollPos = function () {
                            $element.scrollTop(0);
                        }
                        $scope.scrollPos = function(pos) {
                            $element.scrollTop(scrollPos);
                        }
                        $scope.scroll = function (elem) {
                            $element.scrollTop(scrollPos - $element.offset().top);
                        }
                        if($scope.isScrollableGrid){
                            $element.bind('scroll', function (event) {
                                if (currentScroll != event.currentTarget.scrollLeft) {
                                    currentScroll = event.currentTarget.scrollLeft;
                                    $scope.scrollHeader(currentScroll, $element.get(0).scrollHeight > $element.get(0).clientHeight);
                                }
                            });
                        }
                        $scope.isVericalScroll = function(){
                            return ( $element.get(0).scrollHeight > $element.get(0).clientHeight );
                        }
                    }
                };
            }
        };
    }])

/**
 * Directive to create column in the grid with various options
 */
    .directive('wfGridDataCol', ['$compile', 'wfGridService', function($compile, wfGridService) {

        var COL_FIELD = /COL_FIELD/g;

        var DISPLAY_CELL_TEMPLATE = /DISPLAY_CELL_TEMPLATE/g;

        var EDIT_CELL_TEMPLATE = /EDIT_CELL_TEMPLATE/g;

        var INNER_CELL_TEMPLATE = /INNER_CELL_TEMPLATE/g;

        var linkTag = '<a href="RECORD_URL" >RECORD_VALUE</a>';

        var inputTag = '<input  ng-model="COL_FIELD" />'; // ng-input="COL_VALUE"

        // we surround the INNER_CELL_TEMPLATE with a div to ensure the display: block semantics required by the cell height adjustment logic
        var elementTag = '<div ng-if="col" class="cell" style="width: 100%"> ' + '<span ng-hide="inEditMode && col.editable">' + 'DISPLAY_CELL_TEMPLATE' + '</span>' + '<span ng-if="col.editable" ng-show="inEditMode">' + 'EDIT_CELL_TEMPLATE' + '</span> ' + '<div wf-if="col.innerCellTemplate"><div wf-if="col.innerCellTemplate" class="innerCellContainer" onmouseover="if (! angular.element(event.target ? event.target : event.srcElement).scope()[\'cellSeedWidth\']) angular.element(event.target ? event.target : event.srcElement).scope().seedWidth(event);" onclick="angular.element(event.target ? event.target : event.srcElement).scope().adjustHeights(event);"><div wf-if="col.innerCellTemplate">' + 'INNER_CELL_TEMPLATE' + '</div></div wf-if="col.innerCellTemplate"></div wf-if="col.innerCellTemplate">' + '</div>'

        var isEditable = function(colDef) {
            if (colDef.editable == undefined || colDef.editable == true) {
                colDef.editable = true;
                return true;
            }
            return false;
        };

        return {

            restrict: 'C',

            compile: function() {
                return {
                    pre: function(scope, element, attrs) {

                        var record = scope.row;

                        var columnDef = scope.col;

                        var cellValue = undefined;
                        if (scope.col.width != null) {
                            scope.col.columnStyle = {width: scope.col.width};
                        }

                        if (record[columnDef.field] === true || record[columnDef.field] === false) {

                            if (columnDef.inverse === true) {
                                cellValue = '<span ng-bind="row.' + columnDef.field + '|wfBoolean:true"></span>';
                            } else {
                                cellValue = '<span ng-bind="row.' + columnDef.field + '|wfBoolean:false"></span>';
                            }
                        }

                        if (!columnDef.field) {
                            if (columnDef.defaultVal)
                                cellValue = columnDef.defaultVal;
                            else
                                cellValue = "N/A";
                        } else {

                            if (!cellValue)
                                cellValue = '<span>{{row.' + columnDef.field + '}}</span>';
                        }

                        if (columnDef.url) {
                            var paramsUrl;

                            if (columnDef.url.params) {

                                paramsUrl = '?'

                                angular.forEach(columnDef.url.params, function(param, index) {

                                    if (index > 0)
                                        paramsUrl = paramsUrl + '&';

                                    paramsUrl = paramsUrl + param.name + '={{row.' + param.field + '}}';

                                });

                            } else {
                                paramsUrl = '?' + columnDef.field + '={{row.' + columnDef.field + '}}';
                            }

                            if (columnDef.url.img) {
                                cellValue = columnDef.url.img;
                            }

                            if (!columnDef.url.path) {
                                columnDef.url.path = '';
                                paramsUrl = '';
                            }

                            var link = linkTag.replace('RECORD_URL', columnDef.url.path + paramsUrl);

                            if (typeof(scope.$eval('row.' + columnDef.field)) === 'undefined') {
                                // format 'no data' presentation
                                link = link.replace('RECORD_VALUE', '<span>-</span>');
                            } else {
                                link = link.replace('RECORD_VALUE', cellValue);
                            }

                            var template = elementTag;

                            template = template.replace(DISPLAY_CELL_TEMPLATE, link);

                            if (scope.options.enableEdit && isEditable(columnDef)) {

                                if (columnDef.cellEditTemplate) {
                                    var cellEditTemplate = columnDef.cellEditTemplate;
                                    cellEditTemplate = cellEditTemplate.replace(COL_FIELD, 'row.' + columnDef.field);
                                    template = template.replace(EDIT_CELL_TEMPLATE, cellEditTemplate);

                                } else {
                                    var input = inputTag.replace(COL_FIELD, 'row.' + columnDef.field);
                                    template = template.replace(EDIT_CELL_TEMPLATE, input);
                                }

                            } else {
                                template = template.replace(EDIT_CELL_TEMPLATE, '');
                            }

                            element.append($compile(template)(scope));

                        } else if (columnDef.cellTemplate) {

                            // format 'no data' presentation, if appropriate

                            var template = (!columnDef.field || typeof(scope.$eval('row.' + columnDef.field)) === 'undefined') &&
                                angular.equals(scope.$eval('row'), {}) ? '<span>-</span>' : elementTag;

                            var cellTemplate = columnDef.cellTemplate;

                            cellTemplate = cellTemplate.replace(COL_FIELD, 'row.' + columnDef.field);

                            template = template.replace(DISPLAY_CELL_TEMPLATE, cellTemplate);

                            if (scope.options.enableEdit && isEditable(columnDef)) {

                                if (columnDef.cellEditTemplate) {
                                    var cellEditTemplate = columnDef.cellEditTemplate;
                                    cellEditTemplate = cellEditTemplate.replace(COL_FIELD, 'row.' + columnDef.field);
                                    template = template.replace(EDIT_CELL_TEMPLATE, cellEditTemplate);

                                } else {
                                    template = template.replace(EDIT_CELL_TEMPLATE, cellTemplate);
                                }

                            } else {
                                template = template.replace(EDIT_CELL_TEMPLATE, '');
                            }

                            if (columnDef.innerCellTemplate) {
                                var innerCellTemplate = columnDef.innerCellTemplate;
                                innerCellTemplate = innerCellTemplate.replace(COL_FIELD, 'row.' + columnDef.field);
                                template = template.replace(INNER_CELL_TEMPLATE, innerCellTemplate);
                            }

                            var elem = element.append($compile(template)(scope));

                            elem.scope().seedWidth = function(event) {
                                var target = event.target ? event.target : event.srcElement;
                                if (! angular.element(target).scope()['cellSeedWidth']) {
                                    var container = target.className.match(/innerCellContainer/) ? target : wfGridService.findParentBySelector(target, ".innerCellContainer");

                                    var cell = wfGridService.findParentBySelector(container, "td");
                                    angular.element(target).scope()['cellSeedWidth'] = cell.offsetWidth;
                                }
                            }

                            elem.scope().adjustHeights = function(event) {
                                var target = event.target ? event.target : event.srcElement;
                                var container = target.className.match(/innerCellContainer/) ? target : wfGridService.findParentBySelector(target, ".innerCellContainer");

                                // We want to adjust cell height to match the height of the z-indexed content div
                                var cell = wfGridService.findParentBySelector(container, "td");
                                var cellDiv = cell.getElementsByTagName('div')[0];
                                var defaultDelta = cellDiv.offsetHeight - container.scrollHeight;
                                var presentHeight = cell.style.height && (typeof(cell.style.height) != 'string' || ! cell.style.height.match(/auto/)) ? Number(cell.style.height.replace(/\D+/g, '')).valueOf() : (cell.offsetHeight - cellDiv.scrollHeight > defaultDelta ? cell.offsetHeight - (cell.offsetHeight - cellDiv.offsetHeight - defaultDelta) : cell.offsetHeight);
                                var newHeight = presentHeight;
                                //console.log('Present height: [' + cell.style.height + '] [' + cell.offsetHeight + '] compared to ' + presentHeight + ' + ' + container.scrollHeight + ' [' + container.heightControlData + '] ' + defaultDelta);

                                var prezIndexContainerScrollHeight = container.scrollHeight;    // need to save this as applying style will change it, and it may be needed below
                                var ngContainer = angular.element(container);
                                if (ngContainer.css('position') !== 'absolute') {
                                    var ngCell = angular.element(cell);
                                    ngContainer.css({'position': 'absolute', 'z-index': '42'});
                                    //console.log('      Added style ' + container.scrollHeight);

                                    // preserve initial width
//                                    var padding = ngCell.css('padding') ? Number(ngCell.css('padding').replace(/\D+/g, '')).valueOf() : 0;
//                                    var newWidth = container.scrollWidth > cell.offsetWidth ?
//                                        cell.offsetWidth - (container.scrollWidth - cell.offsetWidth) + (padding * 2) :                 // A
//                                        (target.offsetWidth < container.scrollWidth ?
//                                            target.offsetWidth + (2 * (cell.offsetWidth - container.scrollWidth)) + (padding * 2) :     // B
//                                            target.offsetWidth - (cell.offsetWidth - container.scrollWidth) + (padding / 2));           // C
//                                    if (newWidth < container.scrollWidth && target.offsetWidth < container.scrollWidth) {               // only with B
//                                        console.log('\tPadding adjust: ' + newWidth);
//                                        newWidth -= (3 * (padding / 2));
//                                    }
//                                    if (target.offsetWidth < (cell.offsetWidth - container.scrollWidth) && target.offsetWidth < container.scrollWidth) {               // only with B
//                                        console.log('\tIcon adjust: ' + newWidth);
//                                        newWidth = angular.element(target).scope()['cellSeedWidth'];
//                                    }
//                                    if (newWidth < (target.offsetWidth + padding) && target.offsetWidth < container.scrollWidth) {      // only with B
//                                        console.log('\ttarget.offsetWidth fix ' + newWidth);
//                                        newWidth = target.offsetWidth + padding;
//                                    }
//                                    if (((newWidth > container.scrollWidth && newWidth < cell.offsetWidth) || newWidth > cell.offsetWidth ) && target.offsetWidth < container.scrollWidth) {      // only with B
//                                        console.log('\tmidrange fix ' + newWidth);
//                                        newWidth = container.scrollWidth - (cell.offsetWidth - container.scrollWidth) + (padding / 2);
//                                    }
//                                    console.log('Set width to ' + newWidth + ' scrollWidth: ' + container.scrollWidth + ' offsetWidth: ' + cell.offsetWidth + ' padding: ' + padding + ' target.offsetWidth: ' + target.offsetWidth + ' cell.width: ' + cell.style.width );
                                    var newWidth = angular.element(target).scope()['cellSeedWidth'];
                                    ngCell.css({'min-width': newWidth, 'max-width': newWidth});
                                }

                                // store presentHeight for later use
                                if (!container.heightControlData) {
                                    container.heightControlData = presentHeight + ':' + container.scrollHeight;
                                    //console.log('.......... Init to ' + container.heightControlData);
                                }

                                var cellHeight = Number(container.heightControlData.split(':')[0]).valueOf();
                                var innerCellHeight = Number(container.heightControlData.split(':')[1]).valueOf();
                                if (cell.offsetHeight !== (cell.offsetHeight + (container.scrollHeight - innerCellHeight))) {
                                    //console.log('   container.scrollHeight: ' + container.scrollHeight + ' innerCellHeight: ' + innerCellHeight + ' presentHeight: ' + presentHeight + ' cellHeight: ' + cellHeight + ' cell.offsetHeight: ' + cell.offsetHeight + ' ' + (container.scrollHeight > innerCellHeight ? 'true ' + (container.scrollHeight - innerCellHeight) : 'false'));
                                    newHeight += (container.scrollHeight - innerCellHeight);

                                    // need to update stored value as it appears to have changed
                                    container.heightControlData = cellHeight + ':' + container.scrollHeight;
                                    //console.log('.......... Updated to ' + container.heightControlData);
                                } else if (cell.offsetHeight < presentHeight) {
                                    // this case is only used to account for the adjustment following initial application
                                    // of the z-index style above
                                    //console.log('   init container.scrollHeight: ' + container.scrollHeight + ' innerCellHeight: ' + innerCellHeight + ' presentHeight: ' + presentHeight + ' cellHeight: ' + cellHeight + ' cell.offsetHeight: ' + cell.offsetHeight + ' ' + (container.scrollHeight > innerCellHeight ? 'true ' + (container.scrollHeight - innerCellHeight) : 'false'));
                                    newHeight -= (prezIndexContainerScrollHeight - innerCellHeight);
                                    // no update to container.heightControlData required
                                } else {
                                    //console.log('cell.offsetHeight ' + cell.offsetHeight + ' === ' + (cell.offsetHeight + (container.scrollHeight - innerCellHeight)));
                                    //console.log('   container.scrollHeight: ' + container.scrollHeight + ' innerCellHeight: ' + innerCellHeight + ' presentHeight: ' + presentHeight + ' cellHeight: ' + cellHeight + ' cell.offsetHeight: ' + cell.offsetHeight + ' ' + (container.scrollHeight > innerCellHeight ? 'true ' + (container.scrollHeight - innerCellHeight) : 'false'));
                                    newHeight = cell.offsetHeight > presentHeight ? presentHeight : cell.offsetHeight;
                                    // no update to container.heightControlData required
                                }

                                //if (typeof(newHeight) != 'string' && cell.offsetHeight != newHeight) {
                                //    console.log("Going to: " + newHeight + (typeof(newHeight) != 'string' || ! newHeight.match(/auto/) ? 'px' : ''));
                                //}
                                cell.style.height = newHeight + (typeof(newHeight) != 'string' || ! newHeight.match(/auto/) ? 'px' : '');
                            }
                        } else {

                            // format 'no data' presentation, if appropriate
                            var template = (!columnDef.field || typeof(scope.$eval('row.' + columnDef.field)) === 'undefined') &&
                                angular.equals(scope.$eval('row'), {}) ? '<span>-</span>' : elementTag;

                            template = template.replace(DISPLAY_CELL_TEMPLATE, cellValue);

                            var input = inputTag.replace(COL_FIELD, 'row.' + columnDef.field);

                            if (scope.options.enableEdit && isEditable(columnDef)) {

                                if (columnDef.cellEditTemplate) {
                                    var cellEditTemplate = columnDef.cellEditTemplate;
                                    cellEditTemplate = cellEditTemplate.replace(COL_FIELD, 'row.' + columnDef.field);
                                    template = template.replace(EDIT_CELL_TEMPLATE, cellEditTemplate);

                                } else {
                                    template = template.replace(EDIT_CELL_TEMPLATE, input);
                                }

                            } else {
                                template = template.replace(EDIT_CELL_TEMPLATE, '');
                            }
                            element.append($compile(template)(scope));
                        }

                        if (scope.$last && scope.isScrollableGrid ) {
                            if (scope.options && scope.options.scrollToRow === (scope.rowIndex + 1)) {
                                wfGridService.runPostDigest(function(done){
                                    scope.scrollToRow();
                                    done();
                                });
                            }
                        }
                    }
                }
            }
        };
    }])

/**
 * Directive to include inline edit for the rows in the grid.
 */
    .directive('wfGridRowEdit', ['$compile', function($compile) {

        var editLink = '<a href ng-hide="inEditMode">Edit</a>';
        var cancelLink = '<a href ng-show="inEditMode">Cancel</a>';
        var saveLink = '<a href ng-show="inEditMode" style="margin-right: 2px;">Save</a>'

        return {
            restrict: 'C',
            replace: true,
            compile: function() {

                return {
                    pre: function($scope, $element) {
                        var tempRow = {};

                        $scope.inEditMode = false;

                        var editElement = angular.element(editLink);

                        editElement.bind('click', function() {
                            $scope.inEditMode = true;
                            angular.copy($scope.row, tempRow);
                            $scope.$apply();

                        });

                        var cancelElement = angular.element(cancelLink);

                        cancelElement.bind('click', function() {
                            $scope.inEditMode = false;
                            angular.copy(tempRow, $scope.row);
                            tempRow = {};
                            $scope.$apply();

                        });

                        var saveElement = angular.element(saveLink);

                        saveElement.bind('click', function() {
                            $scope.inEditMode = false;
                            tempRow = {};
                            $scope.$apply();

                        });

                        $element.append($compile(editElement)($scope));
                        $element.append($compile(saveElement)($scope));
                        $element.append($compile(cancelElement)($scope));

                    }
                }
            }
        }
    }])
//This directive is same as wfGrid directive but uses a different template file
//Angular doesn't support an easy way to dynamically provide the templateurl.
    .directive('wfGridWithGroup', ['$compile', '$log', 'wfGridService', function($compile, $log, wfGridService) {
        return {
            restrict: 'E',
            scope: true,
            compile: function() {
                return {
                    pre: function($scope, $element, $attrs) {

                        $scope.options = angular.copy($scope.$eval($attrs.detail));
                        if ($scope.options.columnDefsString != null) {
                            $scope.options.columnDefs = $scope.$parent.$eval($scope.options.columnDefsString);
                            //console.log("columnDefs: " + $scope.options.columnDefs)
                            wfGridService.applyColumnSecurity($scope.namespace, $scope.options.columnDefs);
                        }

                        if($attrs.id){
                            $scope.options.widgetId = $attrs.id;
                        }
                        //Remove the id in wf-gris so that the id is present only in the html table element
                        $element.removeAttr("id");

                        $scope.style = $attrs.style;

						//Code for expand/collapse grid 
						if ($scope.options.enableTableExpandCollapse) {
							$scope.tableBodyExpanded = false;
							if ($scope.options.widgetId) {
								$scope.tableBodyExpanded = wfGridService.getExpandState($scope.options.widgetId);
								
							}
							$scope.expandCollapse = function() {
								$scope.tableBodyExpanded = !$scope.tableBodyExpanded;
								if ($scope.options.widgetId) {
									wfGridService.setExpandState($scope.options.widgetId, $scope.tableBodyExpanded);
								}
							}
						}
						
						//Code for expand/collapse header option
                        if ($scope.options.enableHeaderExpandCollapse) {
                            $scope.tableHeaderExpanded = false;
                            if ($scope.options.widgetId) {
                                $scope.tableHeaderExpanded = wfGridService.getExpandState($scope.options.widgetId);

                            }
                            $scope.expandCollapseHeader = function() {
                                $scope.tableHeaderExpanded = !$scope.tableHeaderExpanded;
                                if ($scope.options.widgetId) {
                                    wfGridService.setExpandState($scope.options.widgetId, $scope.tableHeaderExpanded);
                                }
                            }
                        }
						
                        $scope.loader = function() {
                            $scope.$eval($attrs.loader);
                        };

                        $scope.sortRowsInternally = function(field, order) {

                            var reverse = false;

                            if (!order) {
                                order = 'asc';
                            }

                            if (order == 'desc') {
                                reverse = true;
                            }

                            if (!$scope.options.enableGrouping) {
                                $scope.rows = []
                                $scope.rows.push($scope.$eval($scope.options.data + " | orderBy:'" + field + "':" + reverse));
                            } else {
                                $log.warn('sorting based on grouping is not implement yet')
                            }
                        };

                        $scope.defaultSortDisabled = function() {
                            return wfGridService.defaultSortDisabled($scope);
                        }

                        $scope.defaultSort = function() {
                            wfGridService.defaultSort($scope);
                        }

                        var updateGridRows = wfGridService.updateGridRows;

                        updateGridRows($scope, $log);

                        var unwatchData = $scope.$watchCollection($scope.options.data, function(newVal) {
                            if (newVal) {
                                updateGridRows($scope, $log);
                            }
                        });

                        var unwatchColumnDefsString = function(){};
                        if ($scope.options.columnDefsString != null) {
                        	unwatchColumnDefsString = $scope.$watch($scope.options.columnDefsString, function(newVal, oldVal) {
                                //console.log("coldef updated");
                                if (newVal) {
                                    if ($scope.options.columnDefsString != null) {
                                        $scope.options.columnDefs = newVal;
//                                        console.log("columnDefs: " + $scope.options.columnDefs)
                                        wfGridService.applyColumnSecurity($scope.namespace, $scope.options.columnDefs);
                                    }
                                    updateGridRows($scope, $log);
                                }

                            }, true);
                        }

                        $element.on("$destroy", function(){
                        	unwatchData();
                        	unwatchColumnDefsString();
                        });
                    }
                }
            },

            templateUrl: 'template/wfGridWithGroup.html'
        };
    }])
    .directive('wfChecklist', function() {
        return {
            restrict: 'E',
            replace: 'true',			
            scope: {
                list: '=',
                rowObj: '=',
                checked: '=',
                clickHandler: '&',
                id: '@',
                hide: '@',
                disable: '@'
            },
            template: '<input type="checkbox" id="{{id}}" value ="rowObj" ng-checked="checked" fd="{{hide}}" ng-disabled="{{disable}}">',
            link: function(scope, elem, attrs) {
                if (scope.list == undefined)
                    scope.list = [];
                var handler = function(setup) {
                    var checked = elem.prop('checked');
                    var index = scope.list.indexOf(scope.rowObj);

                    if (checked && index == -1) {
                        if (setup) elem.prop('checked', false);
                        else scope.list.push(scope.rowObj);
                    } else if (!checked && index != -1) {
                        if (setup) elem.prop('checked', true);
                        else scope.list.splice(index, 1);
                    }
                };

                var setupHandler = handler.bind(null, true);
                var changeHandler = handler.bind(null, false);

                elem.on('change', function() {
                    scope.$apply(changeHandler);
					if (attrs.clickHandler) {
						scope.$apply(scope.clickHandler());
					}
                });
                var unwatchList = scope.$watch('list', setupHandler, true);

                elem.on('$destroy', function(){
                	$(this).off();
                	unwatchList();
                });
            }
        };
    }).directive('wfBindHtmlUnsafe', ['$compile', '$animate', 'wfGridService', function ($compile, $animate, wfGridService) {
        return function (scope, element, attr) {
            element.addClass('ng-binding').data('$binding', attr.wfBindHtmlUnsafe);
            scope.$watch(attr.wfBindHtmlUnsafe, function bindHtmlUnsafeWatchAction(value) {
                element.html(value || '');
                $compile(element.contents())(scope);
            });
            scope.$on('$destroy', function(){
                $animate.leave(wfGridService.getBlockElements(element));
             });
        };
    }]).directive('wfRepeat', ['$parse', '$animate', function($parse, $animate) {
        var NG_REMOVED = '$$NG_REMOVED';
        var ngRepeatMinErr = Error('ngRepeat');
        var uid               = ['0', '0', '0'];
        function nextUid() {
            var index = uid.length;
            var digit;

            while(index) {
                index--;
                digit = uid[index].charCodeAt(0);
                if (digit == 57 /*'9'*/) {
                    uid[index] = 'A';
                    return uid.join('');
                }
                if (digit == 90  /*'Z'*/) {
                    uid[index] = '0';
                } else {
                    uid[index] = String.fromCharCode(digit + 1);
                    return uid.join('');
                }
            }
            uid.unshift('0');
            return uid.join('');
        };
        function hashKey(obj) {
            var objType = typeof obj,
                key;

            if (objType == 'object' && obj !== null) {
                if (typeof (key = obj.$$hashKey) == 'function') {
                    // must invoke on object to keep the right this
                    key = obj.$$hashKey();
                } else if (key === undefined) {
                    key = obj.$$hashKey = nextUid();
                }
            } else {
                key = obj;
            }

            return objType + ':' + key;
        };
        function getBlockElements(nodes) {
            var startNode = nodes[0],
                endNode = nodes[nodes.length - 1];
            if (startNode === endNode) {
                return $(startNode);
            }

            var element = startNode;
            var elements = [element];

            do {
                element = element.nextSibling;
                if (!element) break;
                elements.push(element);
            } while (element !== endNode);

            return $(elements);
        };
        function forEach(obj, iterator, context) {
            var key;
            if (obj) {
                if (angular.isFunction(obj)){
                    for (key in obj) {
                        // Need to check if hasOwnProperty exists,
                        // as on IE8 the result of querySelectorAll is an object without a hasOwnProperty function
                        if (key != 'prototype' && key != 'length' && key != 'name' && (!obj.hasOwnProperty || obj.hasOwnProperty(key))) {
                            iterator.call(context, obj[key], key);
                        }
                    }
                } else if (obj.forEach && obj.forEach !== forEach) {
                    obj.forEach(iterator, context);
                } else if (angular.isArray(obj)) {
                    for (key = 0; key < obj.length; key++)
                        iterator.call(context, obj[key], key);
                } else {
                    for (key in obj) {
                        if (obj.hasOwnProperty(key)) {
                            iterator.call(context, obj[key], key);
                        }
                    }
                }
            }
            return obj;
        };
        return {
            transclude: 'element',
            priority: 1000,
            terminal: true,
            $$tlb: true,
            link: function($scope, $element, $attr, ctrl, $transclude){
                var expression = $attr.wfRepeat;
                var match = expression.match(/^\s*([\s\S]+?)\s+in\s+([\s\S]+?)(?:\s+track\s+by\s+([\s\S]+?))?\s*$/),
                    trackByExp, trackByExpGetter, trackByIdExpFn, trackByIdArrayFn, trackByIdObjFn,
                    lhs, rhs, valueIdentifier, keyIdentifier,
                    hashFnLocals = {$id: hashKey};

                if (!match) {
                    throw ngRepeatMinErr('iexp', "Expected expression in form of '_item_ in _collection_[ track by _id_]' but got '{0}'.",
                        expression);
                }

                lhs = match[1];
                rhs = match[2];
                trackByExp = match[3];

                if (trackByExp) {
                    trackByExpGetter = $parse(trackByExp);
                    trackByIdExpFn = function(key, value, index) {
                        // assign key, value, and $index to the locals so that they can be used in hash functions
                        if (keyIdentifier) hashFnLocals[keyIdentifier] = key;
                        hashFnLocals[valueIdentifier] = value;
                        hashFnLocals.$index = index;
                        return trackByExpGetter($scope, hashFnLocals);
                    };
                } else {
                    trackByIdArrayFn = function(key, value) {
                        return hashKey(value);
                    };
                    trackByIdObjFn = function(key) {
                        return key;
                    };
                }

                match = lhs.match(/^(?:([\$\w]+)|\(([\$\w]+)\s*,\s*([\$\w]+)\))$/);
                if (!match) {
                    throw ngRepeatMinErr('iidexp', "'_item_' in '_item_ in _collection_' should be an identifier or '(_key_, _value_)' expression, but got '{0}'.",
                        lhs);
                }
                valueIdentifier = match[3] || match[1];
                keyIdentifier = match[2];

                // Store a list of elements from previous run. This is a hash where key is the item from the
                // iterator, and the value is objects with following properties.
                //   - scope: bound scope
                //   - element: previous element.
                //   - index: position
                var lastBlockMap = {};

                $scope.$on('$destroy', function(){
                	for (var key in lastBlockMap) {
                        // lastBlockMap is our own object so we don't need to use special hasOwnPropertyFn
                        if (lastBlockMap.hasOwnProperty(key)) {
                            var block = lastBlockMap[key];
                            var elementsToRemove = getBlockElements(block.clone);
                            $animate.leave(elementsToRemove);
                            forEach(elementsToRemove, function(element) { element[NG_REMOVED] = true; });
                            block.scope.$destroy();
                            block.scope = {};
                            block.clone = {};
                        }
                    }
                });

                //watch props
                $scope.$watchCollection(rhs, function ngRepeatAction(collection){
                    var index, length,
                        previousNode = $element[0],     // current position of the node
                        nextNode,
                    // Same as lastBlockMap but it has the current state. It will become the
                    // lastBlockMap on the next iteration.
                        nextBlockMap = {},
                        arrayLength,
                        childScope,
                        key, value, // key/value of iteration
                        trackById,
                        trackByIdFn,
                        collectionKeys,
                        block,       // last object information {scope, element, id}
                        nextBlockOrder = [],
                        elementsToRemove;

                    if (angular.isArray(collection)) {
                        collectionKeys = collection;
                        trackByIdFn = trackByIdExpFn || trackByIdArrayFn;
                    } else {
                        trackByIdFn = trackByIdExpFn || trackByIdObjFn;
                        // if object, extract keys, sort them and use to determine order of iteration over obj props
                        collectionKeys = [];
                        for (key in collection) {
                            if (collection.hasOwnProperty(key) && key.charAt(0) != '$') {
                                collectionKeys.push(key);
                            }
                        }
                        collectionKeys.sort();
                    }

                    arrayLength = collectionKeys.length;

                    // locate existing items
                    length = nextBlockOrder.length = collectionKeys.length;
                    for(index = 0; index < length; index++) {
                        key = (collection === collectionKeys) ? index : collectionKeys[index];
                        value = collection[key];
                        trackById = trackByIdFn(key, value, index);
                        //assertNotHasOwnProperty(trackById, '`track by` id');
                        if(lastBlockMap.hasOwnProperty(trackById)) {
                            block = lastBlockMap[trackById];
                            delete lastBlockMap[trackById];
                            nextBlockMap[trackById] = block;
                            nextBlockOrder[index] = block;
                        } else if (nextBlockMap.hasOwnProperty(trackById)) {
                            // restore lastBlockMap
                            forEach(nextBlockOrder, function(block) {
                                if (block && block.scope) lastBlockMap[block.id] = block;
                            });
                            // This is a duplicate and we need to throw an error
                            throw ngRepeatMinErr('dupes',
                                "Duplicates in a repeater are not allowed. Use 'track by' expression to specify unique keys. Repeater: {0}, Duplicate key: {1}, Duplicate value: {2}",
                                expression, trackById, toJson(value));
                        } else {
                            // new never before seen block
                            nextBlockOrder[index] = { id: trackById };
                            nextBlockMap[trackById] = false;
                        }
                    }

                    // remove existing items
                    for (key in lastBlockMap) {
                        // lastBlockMap is our own object so we don't need to use special hasOwnPropertyFn
                        if (lastBlockMap.hasOwnProperty(key)) {
                            block = lastBlockMap[key];
                            elementsToRemove = getBlockElements(block.clone);
                            $animate.leave(elementsToRemove);
                            forEach(elementsToRemove, function(element) { element[NG_REMOVED] = true; });
                            block.scope.$destroy();
                            block.scope = {};
                            block.clone = {};
                        }
                    }

                    // we are not using forEach for perf reasons (trying to avoid #call)
                    for (index = 0, length = collectionKeys.length; index < length; index++) {
                        key = (collection === collectionKeys) ? index : collectionKeys[index];
                        value = collection[key];
                        block = nextBlockOrder[index];
                        if (nextBlockOrder[index - 1]) previousNode = getBlockEnd(nextBlockOrder[index - 1]);

                        if (block.scope) {
                            // if we have already seen this object, then we need to reuse the
                             // associated scope/element
                             childScope = block.scope;

                             nextNode = previousNode;
                             do {
                             nextNode = nextNode.nextSibling;
                             } while(nextNode && nextNode[NG_REMOVED]);

                             if (getBlockStart(block) != nextNode) {
                             // existing item which got moved
                             $animate.move(getBlockElements(block.clone), null, $(previousNode));
                             }
                             previousNode = getBlockEnd(block);
                            /*elementsToRemove = getBlockElements(block.clone);
                            $animate.leave(elementsToRemove);
                            forEach(elementsToRemove, function(element) { element[NG_REMOVED] = true; });
                            block.scope.$destroy();*/
                        } else {
                            // new item which we don't know about
                            childScope = $scope.$new();
                        }

                        childScope[valueIdentifier] = value;
                        if (keyIdentifier) childScope[keyIdentifier] = key;
                        childScope.$index = index;
                        childScope.$first = (index === 0);
                        childScope.$last = (index === (arrayLength - 1));
                        childScope.$middle = !(childScope.$first || childScope.$last);
                        // jshint bitwise: false
                        childScope.$odd = !(childScope.$even = (index&1) === 0);
                        // jshint bitwise: true

                        if (!block.scope) {
                            $transclude(childScope, function(clone) {
                                //clone[clone.length++] = document.createComment(' end ngRepeat: ' + expression + ' ');
                                $animate.enter(clone, null, $(previousNode));
                                previousNode = clone;
                                block.scope = childScope;

                                // Note: We only need the first/last node of the cloned nodes.
                                // However, we need to keep the reference to the jqlite wrapper as it might be changed later
                                // by a directive with templateUrl when its template arrives.
                                block.clone = clone;
                                nextBlockMap[block.id] = block;
                            });
                        }
                    }

                    lastBlockMap = nextBlockMap;
                });
            }
        };

        function getBlockStart(block) {
            return block.clone[0];
        }

        function getBlockEnd(block) {
            return block.clone[block.clone.length - 1];
        }
    }])
    .run(["$templateCache", function($templateCache) {
        $templateCache.put("template/wfGrid.html",
            '<table ng-attr-style="{{style}}"><tr><td>' +
            '<div class = "wf-grid-table">' +
              '<div wf-if="options.enablePaging">' +
                '<wf-grid-paging></wf-grid-paging>' +
              '</div>' +
              '<a ng-if="options.enableDefaultSortButton && options.sortInfo" ng-disabled="defaultSortDisabled()" style="position: relative; top: -35px; margin-right: 2px;" class="pull-right" ng-click="defaultSort();" >Apply Default Sort</a>' +
              '<div ng-attr-style="{{style}}" class="wf-table">' +
                '<div class="table-header" ng-hide="options.hideHeader">' +
                    '<span wf-if="options.enableTableExpandCollapse">'+
                        '<a href=""  style="text-decoration:none; color:#ffffff;" ng-click="expandCollapse()" >' +
                            '<span ng-hide="tableBodyExpanded" class="icon-large default icon-expand"></span>' +
                            '<span ng-show="tableBodyExpanded" class="icon-large default icon-collapse"></span>' +
                        '</a>' +
                        '<span class="title" wf-bind-html-unsafe="options.title"></span>' +
                    '</span>'+
                    '<span  wf-if="!options.enableTableExpandCollapse" class="title" wf-bind-html-unsafe="options.title"></span>'+
                '</div>' +
                '<div class="wf-table-body" ng-style="innerStyle" ng-show="(tableBodyExpanded == null || tableBodyExpanded) && !options.hideGrid">' +
                  '<div>' +
                    '<table ng-class="options.gridStyle || \'wf-table-content table table-bordered table-hover table-condensed table-striped\'" id="{{options.widgetId}}">' +
                      '<thead ng-hide="options.hideColumnHeader">' +
                        '<tr class="wf-grid-header-group-row" wf-if="options.enableGrouping && options.groupInfo.displayName">' +
                          '<td wf-if="options.enableGrouping" class="wf-grid-header-group-col" >{{options.groupInfo.displayName}}</td>' +
                          '<td wf-repeat="colDef in options.columnDefs" wf-if="(!$last)||($last && options.enableEdit)" ></td>' +
                        '</tr>' +
                        '<tr class="wf-grid-header-row table-column-header">' +
                          '<th class="wf-grid-header-col" ng-hide="colDef.hide" ng-style="colDef.columnStyle" wf-repeat="colDef in options.columnDefs"></th>' +
                          '<td class="wf-grid-header-edit-Col" wf-if="options.enableEdit" ng-show="options.enableEdit"></td>' +
                        '</tr>' +
                      '</thead>' +
                      '<tbody class="wf-grid-rows" wf-repeat="groupRow in rows">' +
                        '<tr class="wf-grid-data-group-row" wf-if="options.enableGrouping" >' +
                          '<td class="wf-grid-data-group-col"  colspan="{{options.columnDefs.length}}">' +
                             '<a href="" style="text-decoration:none; color:black;" ng-init="isexpanded = true" ng-click="isexpanded = !isexpanded " >' +
                               '<span ng-hide="isexpanded" class="icon-large default icon-expand"></span>' +
                               '<span ng-show="isexpanded" class="icon-large default icon-collapse"></span>' +
                              '{{groupBy}}' +
                             '</a>' +
                             '<span wf-bind-html-unsafe="options.groupInfo.moreInfoCellTemplate"></span>' +
                          '</td>' +
                        '</tr>' +
                        '<tr class="wf-grid-data-row" ng-form name="rowForm{{$index}}" exclude-page-changed wf-repeat="row in datarows" ng-show="(isexpanded == null || isexpanded)" ng-class="options.rowClassFunction(row, rowIndex)">' +
                          '<td ng-hide="col.hide" ng-style="col.columnStyle" class="wf-grid-data-col" ng-class="(isexpanded && options.enableGrouping) && \'grouped\' || col.colClassFunction(row, rowIndex)|| col.columnClass || \'\' " wf-repeat="col in options.columnDefs">' +
                          '</td>' +
                          '<td class="wf-grid-row-edit wf-grid-data-edit-col" wf-if="options.enableEdit" ng-show="options.enableEdit"></td>' +
                        '</tr>' +
                        '<tr class="grid-combined-credit-summary-spacer-bottom" ng-show="options.enableSummary" wf-repeat="footer in options.footer">' +
                            '<td wf-repeat="f in footer" ng-class="f.columnClass"  ng-attr-style="{{f.columnStyle}}" colspan="{{f.colspan}}">{{f.text}}</td>' +
                        '</tr>' +
                      '</tbody>' +
                    '</table>' +
                  '</div>' +
                '</div>' +
                '<div class="table-footer" ng-show="(tableBodyExpanded == null || tableBodyExpanded) && options.showFooter">' +
                '</div> ' +
              '</div>' +
              '<div wf-if="options.enablePagingBottom">' +
                  '<wf-grid-paging></wf-grid-paging>' +
              '</div>' +
            '</div>' +
            '</td></tr></table>');

        $templateCache.put("template/wfScrollableGrid.html",
            '<table ng-attr-style="{{style}}"><tr><td>' +
                '<div class = "wf-grid-table">' +
                    '<div wf-if="options.enablePaging">' +
                        '<wf-grid-paging></wf-grid-paging>' +
                    '</div>' +
                    '<button ng-if="options.enableDefaultSortButton && options.sortInfo" ng-disabled="defaultSortDisabled()" style="position: relative; top: -35px; margin-right: 2px;" class="btn btn-primary pull-right" ng-click="defaultSort();" >Apply Default Sort</button>' +
                    '<div ng-attr-style="{{style}}" class="wf-table">' +
                        '<div class="table-header" ng-hide="options.hideHeader">' +
                            '<span class="title" wf-bind-html-unsafe="options.title"></span>' +
                        '</div>' +
                        '<div class="table-column-header-group" >' +
                            '<div class="wf-grid-column-header-group">' +
                                '<table style="width:100%">' +
                                    '<thead ng-hide="options.hideColumnHeader" >' +
                                    '<tr class="wf-grid-header-group-row" wf-if="options.enableGrouping">' +
                                        '<th wf-if="options.enableGrouping" class="wf-grid-header-group-col" >{{options.groupInfo.displayName}}</th>' +
                                        '<th wf-repeat="colDef in options.columnDefs" wf-if="(!$last)||($last && options.enableEdit)" ></th>' +
                                    '</tr>' +
                                    '<tr class="wf-grid-header-row table-column-header">' +
                                        '<th class="wf-grid-header-col table-column-header-cell" ng-hide="colDef.hide" ng-style="colDef.columnStyle" wf-repeat="colDef in options.columnDefs"></th>' +
                                        '<th class="wf-grid-header-edit-Col table-column-header-cell" wf-if="options.enableEdit" ng-show="options.enableEdit"></th>' +
                                    '</tr>' +
                                    '</thead>' +
                                '</table>' +
                            '</div>' +
                        '</div>' +
                       '<div class="wf-table-body" ng-style="innerStyle">' +
                            '<div>' +
                                '<table ng-class="options.gridStyle || \'wf-table-content table table-bordered table-hover table-condensed table-striped\'" id="{{options.widgetId}}">' +
                                    '<tbody class="wf-grid-rows" wf-repeat="groupRow in rows">' +
                                    '<tr class="wf-grid-data-group-row" wf-if="options.enableGrouping" >' +
                                        '<td class="wf-grid-data-group-col" >' +
                                            '<a href="" style="text-decoration:none; color:black" ng-init="isexpanded = $first ; " ng-click="isexpanded = !isexpanded " >' +
                                                '<span ng-hide="isexpanded" class="icon-large default icon-expand"></span>' +
                                                '<span ng-show="isexpanded" class="icon-large default icon-collapse"></span>' +
                                                '{{groupBy}}' +
                                            '</a>' +
                                        '</td>' +
                                        '<td style="border-left:1px inset gray;" wf-repeat="col in options.columnDefs" wf-if="(!$last)||($last && options.enableEdit)" >' +
                                        '</td>' +
                                    '</tr>' +
                                    '<tr class="wf-grid-data-row" wf-repeat="row in datarows" ng-show="(isexpanded == null || isexpanded)" ng-class="options.rowClassFunction(row, rowIndex)">' +
                                        '<td ng-hide="col.hide" ng-style="col.columnStyle" class="wf-grid-data-col" ng-class="(isexpanded && options.enableGrouping) && \'grouped\' || col.colClassFunction(row, rowIndex)|| col.columnClass || \'\' " wf-repeat="col in options.columnDefs">' +
                                        '</td>' +
                                        '<td class="wf-grid-row-edit wf-grid-data-edit-col" wf-if="options.enableEdit" ng-show="options.enableEdit"></td>' +
                                    '</tr>' +
                                    '<tr wf-scroll-footer class="grid-combined-credit-summary-spacer-bottom" ng-show="options.enableSummary" wf-repeat="footer in options.footer">' +
                                        '<td  wf-repeat="f in footer" ng-class="f.columnClass"  ng-style="f.columnStyle" colspan="{{f.colspan}}">{{f.text}}</td>' +
                                    '</tr>' +
                                    '</tbody>' +
                                '</table>' +
                            '</div>' +
                        '</div> ' +
                        '<div class="table-footer" ng-show="options.showFooter">' +
                        '</div>' +
                    '</div>' +
                    '<div wf-if="options.enablePagingBottom">' +
                        '<wf-grid-paging></wf-grid-paging>' +
                    '</div>' +
                '</div>' +
            '</td></tr></table>');


        $templateCache.put("template/wfGridPaging.html",
            '<div class="pagination-top-container">' +
                '<div class="pagination-display">Displaying <strong class="ng-binding">{{options.paging.startIndex}} to {{options.paging.endIndex}} of {{options.paging.totalRecords}}</strong></div>' +
                '<div class="pagination-small pagination" direction-links="true" boundary-links="false" total-items="totalItems" page="currentPage" previous-text="‹ Previous" next-text="Next ›">' +
                    '<ul>' +
                        '<li>' +
                            '<select ng-model="options.paging.selectedPageSize" ng-options="value for value in pageSizes" ng-change="perPageListBoxChange();"/>' +
                        '</li>' +
                        '<li ng-class="{active: page.active, disabled: previousDisabled}" ng-show="options.paging.showBoundaryLinks">' +
                            '<a href="" ng-click="selectPage(1)">&lsaquo;&lsaquo;First</a>' +
                        '</li>' +
                        '<li ng-class="{active: page.active, disabled: previousDisabled}">' +
                            '<a href="" ng-click="getPreviousPage()">&lsaquo; Previous</a>' +
                        '</li>' +
                        '<li ng-repeat="page in pages | limitTo: paginationSize" ng-class="{active: page.active, disabled: page.disabled}">' +
                            '<a href="" ng-click="selectPage(page.number);">{{page.number}}</a>' +
                        '</li>' +
                        '<li ng-class="{active: page.active, disabled: nextDisabled}">' +
                            '<a href="" ng-click="getNextPage()">Next &rsaquo;</a>' +
                        '</li>' +
                        '<li ng-class="{active: page.active, disabled: nextDisabled}" ng-show="options.paging.showBoundaryLinks">' +
                            '<a href="" ng-click="selectPage(pages.length)">Last&rsaquo;&rsaquo;</a>' +
                        '</li>' +
                    '</ul>' +
                '</div>' +
                '<div class="go-to-page"><span>Go to Page:</span>' +
                    '<form ng-submit="paginationForm.$valid && setPage(options.paging.currentPage)" name="paginationForm">' +
                        '<input type="text" class="form-control page-input" wf-max-number="{{options.paging.totalPages}}"  ng-model="options.paging.currentPage">' +
                    '</form>' +
                '</div>' +
            '</div>');


        $templateCache.put("template/wfGridWithGroup.html",
                '<div class = "wf-grid-table">' +
                  '<div wf-if="options.enablePaging">' +
                    '<wf-grid-paging></wf-grid-paging>' +
                  '</div>' +
                  '<button ng-if="options.enableDefaultSortButton && options.sortInfo" ng-disabled="defaultSortDisabled()" style="position: relative; top: -35px; margin-right: 2px;" class="btn btn-primary pull-right" ng-click="defaultSort();" >Apply Default Sort</button>' +
                    '<div ng-attr-style="{{style}}" class="wf-table">' +
                    '<div ng-class="options.headerStyle || \'table-header\'" ng-hide="options.hideHeader">' +
                        '<span wf-if="options.enableTableExpandCollapse">'+
                            '<a href=""  style="text-decoration:none; color:#ffffff;" ng-click="expandCollapse()" >' +
                                '<span ng-hide="tableBodyExpanded" class="icon-large default icon-expand"></span>' +
                                '<span ng-show="tableBodyExpanded" class="icon-large default icon-collapse"></span>' +
                            '</a>' +
                            '<span class="title" wf-bind-html-unsafe="options.title"></span>' +
                        '</span>'+
                        '<span wf-if="!options.enableTableExpandCollapse" class="title">{{options.title}}</span>' +
                    '</div>' +
                    '<div class="wf-table-body" ng-show="(tableBodyExpanded == null || tableBodyExpanded)">' +
                      '<div>' +
                        '<table class="wf-table-content table table-bordered table-hover table-condensed table-striped" id="{{options.widgetId}}">' +
                          '<thead ng-hide="options.hideColumnHeader">' +
                            '<tr class="wf-grid-header-row table-column-header">' +
                              '<th class="wf-grid-header-col" wf-repeat="colDef in options.columnDefs" ng-style="colDef.columnStyle"></th>' +
                              '<td class="wf-grid-header-edit-Col" wf-if="options.enableEdit" ng-show="options.enableEdit"></td>' +
                            '</tr>' +
                          '</thead>' +
                          '<tbody class="wf-grid-rows" wf-repeat="groupRow in rows" ng-show="(tableHeaderExpanded == null || tableHeaderExpanded)">' +
                            '<tr ng-init="groupIndex=$index" class="wf-grid-data-group-row" wf-if="options.enableGrouping && !groupRow.hideGroup">' +
                              '<td class="wf-grid-data-group-col" colspan="{{options.columnDefs.length}}">' +
                                  '{{groupBy}}' +
                              '</td>' +
                            '</tr>' +
							'' +
                            '<tr style="background-color: #ffffff;" class="wf-grid-data-group-row" wf-if="options.enableGrouping" wf-repeat="header in groupRow.headers">' +
                              '<td class="wf-grid-data-group-col" wf-repeat="headercol in header" colSpan="{{headercol.colspan || 1}}" ng-class="headercol.class">' +
                                '<div wf-bind-html-unsafe="headercol.data"></div>' +
                              '</td>' +
                            '</tr>' +
                            '<tr class="wf-grid-data-row" wf-repeat="row in datarows">' +
                              '<td class="wf-grid-data-col" ng-style="col.columnStyle" rowspan = "{{col.rowSpan|| 1}}" ng-if="(col.rowSpan && (rowIndex%col.rowSpan)==0) || !col.rowSpan" ng-class="(options.enableGrouping) && \'grouped\' || \'\'" wf-repeat="col in options.columnDefs">   ' +
                              '</td>' +
                              '<td class="wf-grid-row-edit wf-grid-data-edit-col" wf-if="options.enableEdit" ng-show="options.enableEdit"></td>' +
                            '</tr>' +
                            '' +
                            '<tr style="background-color: #ffffff;" class="wf-grid-data-group-row" wf-if="options.enableGrouping" wf-repeat="footer in groupRow.footers">' +
                              '<td class="wf-grid-data-group-col" wf-repeat="footercol in footer" colSpan="{{footercol.colspan || 1}}">' +
                                '<div ng-class="footercol.class">{{footercol.data}}</div>' +
                              '</td>' +
                            '</tr>' +
                          '</tbody>' +
                        '</table>' +
                      '</div>' +
                    '</div>' +
                    '<div ng-class="options.footerStyle || \'wf-table-footer\'" ng-show="(tableBodyExpanded == null || tableBodyExpanded) && options.showFooter">' +
                    '</div> ' +
                  '</div>' +
                  '<div wf-if="options.enablePaging">' +
                      '<wf-grid-paging></wf-grid-paging>' +
                  '</div>' +
                '</div>');


    }])
;
//Preformance Service
(function(){
function PerformanceService($log) {
    this.logger = $log.getInstance('PerformanceService');
    this.logger.enableLogging(2);
    this.startTime = undefined;
    this.stopTime = undefined;
    this.isRunning = false;
    this.instanceName = undefined;
}
PerformanceService.prototype.start = function startPerf(name){
    if(!this.isRunning){
        this.startTime = performance.now();
        this.instanceName = name;
    }
    this.isRunning = true;    
}
PerformanceService.prototype.reset = function resetPerf(){
    this.startTime = 0;
    this.stopTime = 0;    
    this.isRunning = false;
}
PerformanceService.prototype.stop = function stopPerf(callback){
    if(this.isRunning){
        this.stopTime = performance.now();
        var time = this.stopTime-this.startTime;
        if(callback && typeof callback === 'function'){
            callback();   
        }
        this.logger.debug((this.instanceName?this.instanceName+" - ":'')+"Performance in Mills : "+ time);
        this.reset(); 
        return time;
    }else{
        this.logger.error("$perf needs to be started before stopping");
    }
}

angular.module('wf.framework').service('$perf', ['$log',PerformanceService]);
})(); 
//Performance Service Ends
//Matrix Controller
(function(){
function MatrixController(scope, $perf, $log, dataFactory, $timeout) {    
    this.logger = $log.getInstance('MatrixController');
    this.logger.enableLogging(2);
    this.$perf = $perf;
    this.watches = [];
    this.dataWatchers = [];
    this.defsWatchers = [];
    this.dataContainer = dataFactory.getContainer($log);
    this.definitionsEqualityWatcher = undefined;
    var _this = this;
    this.updateData = function(data){
        this.dataWatchFunction(data, undefined, undefined);
    } 
    this.dataWatchFunction = function dataWatchFunctionMatrix(newData, oldData, watchScope){
        if(typeof scope.options.beforeDataLoad == 'function' && watchScope){
            scope.options.beforeDataLoad(newData);
        }
        _this.logger.debug("Data watch fired"); 
        _this.dataContainer.setMatrixData(newData,scope.options);
        if(_this.dataWatchers)
            _this.dataWatchers.forEach(function(watcherFn){watcherFn.call(undefined,newData,oldData)});
        //scope.matrix.calculateWidths();
        if(typeof scope.options.afterDataLoad == 'function'&& watchScope){
            $timeout(function(){
                scope.options.afterDataLoad(_this.dataContainer.matrixData);
            })
        }
    }
    this.updateColumnsDefsWatch = function updateColumnsDefsWatch(newData, oldData){
        _this.dataContainer.setMatrixColDefs(newData);
        if(_this.defsWatchers)
            _this.defsWatchers.forEach(function(watcherFn){watcherFn.call(undefined,newData,oldData)});
        if(scope.options.$isMatrixInitialized){
            scope.matrix.calculateWidths()
        }
    }
    this.defsWatchFunction = this.updateColumnDefs = function defsWatchFunctionMatrix(newData, oldData){
        _this.logger.debug("ColumnDefs watch fired")
        
        //columns definitions updated outside of the matrix -- clear defitionsEqualityWatcher and create again.
        if(_this.definitionsEqualityWatcher){
            _this.definitionsEqualityWatcher();
            _this.definitionsEqualityWatcher = undefined;
        }
        
        _this.updateColumnsDefsWatch(newData, oldData);
        
        if (angular.isString(scope.options.columnDefs)) {
            _this.definitionsEqualityWatcher = scope.$parent.$watch(scope.options.columnDefs, _this.updateColumnsDefsWatch, true);
        } else {
            _this.definitionsEqualityWatcher = scope.$parent.$watch(function() { return scope.options.columnDefs; }, _this.updateColumnsDefsWatch,true);
        }         
    }
}   
/*Adds the given watcherFn to be called when adata change occurs*/
MatrixController.prototype.addToDataWatchers = function(watcherFn){
    if(typeof watcherFn == "function")
        this.dataWatchers.push(watcherFn);
}
/*Adds the given watcherFn to be called when adata change occurs*/
MatrixController.prototype.addToColDefsWatchers = function(watcherFn){
    if(typeof watcherFn == "function")
        this.defsWatchers.push(watcherFn);
}
/*Method to remove the watchers on destroy*/
MatrixController.prototype.ngOnDestroy = function ngOnDestroyMatrix(){
    this.watches.forEach(function(dewatch){dewatch();});
    this.dataWatchers = undefined;
    this.defsWatchers = undefined;
    this.appscope = undefined;
    this.logger.debug("Matrix data watches are destroyed");
} 
/*Method to initialize the matrix*/
MatrixController.prototype.ngOnInit = function initializeMatrix(scope, attrs){
    //watcher for column definitions 
    if (angular.isString(scope.options.columnDefs)) {
        this.watches.push(scope.$parent.$watchCollection(scope.options.columnDefs, this.defsWatchFunction));
    } else {
        this.watches.push(scope.$parent.$watchCollection(function() { return scope.options.columnDefs; }, this.defsWatchFunction));
    } 
    //watcher for the data  
    if (angular.isString(scope.options.data)) {
        this.watches.push(scope.$parent.$watchCollection(scope.options.data, this.dataWatchFunction));
    } else {
        this.watches.push(scope.$parent.$watchCollection(function() { return scope.options.data; }, this.dataWatchFunction));
    }
}
    
//Matrix Controller Ends       
angular.module('wf.framework').controller('wfMatrixController',['$scope', '$perf', '$log', 'MatrixDataFactory','$timeout',  MatrixController]);
})(); 
(function(){
/**
 * update the $log to enable context based logging, used to disable the logs in the matrix
 */
angular.module('wf.framework').run(['$log', function($log) {
    $log.enabledContexts = [];
    var stopLogging = false;
    $log.getInstance = function(context, enable) {
        var instance =  {
            log   : enhanceLogging($log.log, context, 3),
            info  : enhanceLogging($log.info, context, 2),
            warn  : enhanceLogging($log.warn, context, 4),
            debug : enhanceLogging($log.debug, context, 1),
            error : enhanceLogging($log.error, context,5),
            enableLogging : function(enable) {
                $log.enabledContexts[context] = enable;
                instance.isEnabled = enable;
            },
            isEnabled:enable
        };
        return instance;
    };
    function enhanceLogging(loggingFunc, context, logLevel) {
        if(stopLogging){
            return function(){};
        }
        return function() {
            var contextEnabled = $log.enabledContexts[context];
            if ($log.enabledContexts[context] == null || contextEnabled) {
                if(!angular.isNumber(contextEnabled)){
                    var modifiedArguments = [].slice.call(arguments);
                    loggingFunc.apply(null, modifiedArguments);
                }else if(logLevel >= contextEnabled){
                    var modArguments = [].slice.call(arguments);
                    loggingFunc.apply(null, modArguments);
                }                
            }
        };
    }
}]);
})();
(function(){
/**
 * Matrix template cache
 */
angular.module('wf.framework').run(["$templateCache", function($templateCache){
    $templateCache.put('div/wf-matrix.html',
        '<div class="wf-matrix wf-matrix-resizable" id="{{matrixId}}" >'+
            '<wf-matrix-pagination></wf-matrix-pagination>'+
            '<div class="matrix-header-holder">'+
                '<div class="matrix-header-canvas">'+
                    '<div class="matrix-header-viewport">'+
                        '<div wf-matrix-header class="matrix-header"> </div>'+
                    '</div>'+
                '</div>'+
            '</div>'+
            '<wf-matrix-loader></wf-matrix-loader>'+
        '</div>'
    );
    $templateCache.put('div/wf-matrix-virtual-loader.html',
        '<div class="wf-matrix-scroll-container matrix-viewport matrix-data-table">'+ 
            '<div class="wf-matrix-data-container">'+
                '<div class="matrix-table">'+
                    
                '</div>'+
            '</div>'+                                            
        '</div>'
    );
    $templateCache.put('div/wf-matrix-rows.html', 
        '<div class="wf-matrix-data-row matrix-row" ng-click="rowClick();" ng-class="{\'row-even\':$rowEven,\'row-odd\':$rowOdd}" ng-repeat="matrixRow in matrix.dataContainer.virtualData" >'+
            '<div class="wf-matrix-data-col matrix-column"  ng-style="{\'min-width\' : matrixCol.calculatedWidth , \'max-width\' : matrixCol.calculatedWidth}"  ng-repeat="matrixCol in matrix.dataContainer.renderedColumns">'+
                
            '</div>'+    
        '</div>'
    );
    $templateCache.put('div/wf-matrix-header.html',
        '<div class="wf-matrix-header-row matrix-header-row" >'+
            
        '</div>'
    );
    $templateCache.put('div/wf-matrix-header-cols.html',
        '<div  ng-repeat="matrixCol in matrix.dataContainer.renderedColumns" ng-style="{\'min-width\' : matrixCol.calculatedWidth , \'max-width\' : matrixCol.calculatedWidth}" class="matrix-header-column" wf-matrix-header-col> '+
        '</div>'
    );
    $templateCache.put('div/wf-matrix-pagination.html',
        '<div class="wf-matrix-pagination"></div>'
    );
    $templateCache.put('pagingTemplate.html',
        '<div><div class="pagination-top-container">'+
            '<div class="pagination-display">Displaying <strong class="ng-binding">{{options.pagingInfo.paging.startIndex + (options.pagingInfo.paging.totalRecords > 0 ? 1 : 0)}} to {{(options.pagingInfo.paging.endIndex > uiTotalRecords) && uiTotalRecords || options.pagingInfo.paging.endIndex+1}}   of {{uiTotalRecords}}</strong></div>'+
            '<div class="pagination-small pagination" direction-links="true" boundary-links="false" total-items="totalItems" page="currentPage" previous-text="‹ Previous" next-text="Next ›">'+
                '<ul>'+
                    '<li>'+
                        '<select ng-model="options.pagingInfo.paging.rowsPerPage" ng-options="value for value in pageSizes" ng-change="perPageListBoxChange();"/>'+
                    '</li>'+
                    '<li ng-class="{disabled: !showFirstOrPreviousPageLink}" ng-show="options.pagingInfo.showBoundaryLinks">'+
                        '<span ng-click="setPage(1)">&lsaquo;&lsaquo;First</span>'+
                    '</li>'+
                    '<li ng-class="{disabled: !showFirstOrPreviousPageLink}">'+
                        '<span href="" ng-click="getPreviousPage()">&lsaquo; Previous</span>'+
                    '</li>'+
                    '<li ng-repeat="page in pages | limitTo: paginationSize" ng-class="{active: page.active, disabled: page.disabled}">'+
                        '<span ng-click="setPage(page.number);">{{page.number}}</span>'+
                    '</li>'+
                    '<li ng-class="{disabled: !showLastOrNextPageLink}">'+
                        '<span ng-click="getNextPage()">Next &rsaquo;</span>'+
                    '</li>'+
                    '<li ng-class="{disabled: !showLastOrNextPageLink}" ng-show="options.pagingInfo.showBoundaryLinks">'+
                        '<span ng-click="setPage(options.pagingInfo.paging.totalPages)">Last&rsaquo;&rsaquo;</span>'+
                    '</li>'+
                '</ul>'+
            '</div>'+
            '<div class="go-to-page" ng-if="options.pagingInfo.enableGoToPage"><span>Go to Page:</span>'+
                '<form ng-submit="paginationForm.$valid && setPage(options.pagingInfo.paging.currentPage)" name="paginationForm">'+
                    '<input type="text" class="form-control page-input" wf-max-number="{{options.pagingInfo.paging.totalPages}}"  ng-model="options.pagingInfo.paging.currentPage">'+
                '</form>'+
            '</div>'+            
        '</div>'+
        '<div style="clear:both"></div></div>'
    );
    $templateCache.put("col-header-sort.html",
        '<span class="sort">' +
        '    <i ng-class="{\'icon-sort\' : (options.sortInfo.fields.indexOf(matrixCol.field) == -1), ' +
        '                  \'icon-sort-up\' : (options.sortInfo.directions[options.sortInfo.fields.indexOf(matrixCol.field)] == \'asc\'), ' +
        '                  \'icon-sort-down\' : (options.sortInfo.directions[options.sortInfo.fields.indexOf(matrixCol.field)] == \'desc\')}" class="icon-large default">'+
        '       {{(options.sortInfo.fields.indexOf(matrixCol.field) != -1 && options.sortInfo.multiple)? options.sortInfo.fields.indexOf(matrixCol.field)+1:\'\'}}'+
        '    </i>'+
        '</span>'
    );
    $templateCache.put("col-sort-remove.html",
        '<span class="remove-sort" ng-show="options.sortInfo.fields && options.sortInfo.fields.indexOf(matrixCol.field) != -1" ng-click="removeSort()" title="Remove Sort"><i class="icon-remove" title="Remove Sort"></i></span>'
    );
    $templateCache.put("col-header.html",
        '<div class="column-header">'+
            '<span class="title"></span>'+
        '</div>'
    );
}]);
})();
(function(){
function MatrixAutoViewportContainer(element, dataContainer, scrollInfo, pagingInfo) {
    if(!element)
        throw Error("ViewportContainer is initialized based on an element. element should be passed as constructor args .")
    this.AVG_HEIGHT=36 //this is with respect to css
    this.maxRows = 0;
    this.currentStartIndex = NaN;
    this.maxIndex = 0;
    this.scrollMax = 0;
    this.rowThreshold = 0;
    this.container = element;
    this.dataContainer = dataContainer;
    this.rowCacheThreshold = 4;
    this.currentRangeStart = 0;
    this.currentRangeEnd = 0;
    this.currentScrollLeft = 0;
    this.currentScrollTop = 0;
    this.rowCache = {};
    this.pagingInfo = pagingInfo;
    this.definedScrollHeight = this.currentMaxScrollHeight = (scrollInfo && scrollInfo.height) ? scrollInfo.height : 400;
}
//cleans up the element references on destroy
MatrixAutoViewportContainer.prototype.onDestroy = function onContainerDestroy() {
    this.container = undefined;
    this.dataConatiner = null;
    this.paging = null;
}
//re-calculates/initializes the viewport container values
MatrixAutoViewportContainer.prototype.reinitializeContainerValues = function calculateContainerValues(){
    this.scrollMax = Math.floor(this.dataContainer.pageData.length*this.AVG_HEIGHT);
    for(var key in this.rowCache){
        if(key < this.dataContainer.pageData.length)
            this.scrollMax = this.scrollMax + this.rowCache[key] - this.AVG_HEIGHT;
    }
    this.setMaxHeight(this.currentMaxScrollHeight);
    this.setDataContainerHeight(this.scrollMax);
    this.rowThreshold = Math.ceil(this.currentMaxScrollHeight/this.AVG_HEIGHT);
    this.setMaxRows(this.rowThreshold);
    this.currentRangeStart = 0;
    this.currentRangeEnd = 0;
    this.maxIndex = this.dataContainer.pageData.length-this.rowThreshold;
    this.currentStartIndex = NaN;
    return this.virtualScrollHandler();
}
MatrixAutoViewportContainer.prototype.getMaxRows = function getMatrixContainerMaxRows() {
    return this.maxRows;
}
MatrixAutoViewportContainer.prototype.setMaxRows = function setMatrixContainerMaxRows(maxRows) {
    this.maxRows = maxRows
};
/*returns the viewport conatiner current height*/
MatrixAutoViewportContainer.prototype.getCurrentHeight = function getContainerCurrentHeight() {
    return this.container.outerHeight()
};
/*returns the viewport conatiner maximum height defined*/
MatrixAutoViewportContainer.prototype.getMaxHeight = function getContainerMaxHeight() {
    return this.container.css('max-height')
};
/*sets the viewport container maximum height*/
MatrixAutoViewportContainer.prototype.setMaxHeight = function setContainerMaxHeight(height) {
    this.currentMaxScrollHeight = height;
    this.container.css('max-height', height)
};
/*sets the data container inside the viewport minimum height*/
MatrixAutoViewportContainer.prototype.setDataContainerHeight = function setDataCotainerMinHeight(scrollMax) {
    this.currentScrollMax=scrollMax;
    this.container.find('.wf-matrix-data-container').css('min-height', scrollMax);
};
MatrixAutoViewportContainer.prototype.getDataContainerHeight = function getDataCotainerMinHeight() {
    return this.container.find('.wf-matrix-data-container').outerHeight();
};
/*Calculates the scroll position for the given index*/
MatrixAutoViewportContainer.prototype.calcScrollPos = function (index) {
    var space = 0;
    var from  = 0;
    while (from < index ) {
        var itemSize = this.getSizeOf(from);
        //if (space + itemSize > scrollPos) break;
        space += itemSize;
        ++from;
    }
    return space;
    
};
/**
 * returns the height of an element in the cache,
 * if not defined returns the defined height which will be modified after the rendering of the element
 */
MatrixAutoViewportContainer.prototype.getSizeOf = function(index){
    if(this.pagingInfo.virtual){
       // adjusting index to match the virtual pagination start index
       index = index + this.pagingInfo.paging.startIndex;
    }
    if(this.rowCache[index]){
        return this.rowCache[index];
    }
    return this.AVG_HEIGHT;
}

/*Method to calculate the start index based on the heights in the rowcache*/
MatrixAutoViewportContainer.prototype.getStartIndex = function(scrollPos){
    var space = 0;
    var from  = 0;
    while (from < (this.dataContainer.pageData.length-1) ) {
        var itemSize = this.getSizeOf(from);
        if (space + itemSize > scrollPos) break;
        space += itemSize;
        ++from;
    }
    return from;
}
/*Method to handle the virtual scroll event*/
MatrixAutoViewportContainer.prototype.virtualScrollHandler = function(event) {
    // console.log("scrolled pos - "+this.container[0].scrollTop+" - height - "+this.getDataContainerHeight());
    var scrollPos = this.currentScrollTop = this.container[0].scrollTop;
    var startIndex = this.getStartIndex(scrollPos);
    startIndex = (startIndex) > this.maxIndex ? this.maxIndex:startIndex;
    return this.scroll(startIndex);
}

MatrixAutoViewportContainer.prototype.renderContainer = function(){
    return this.reinitializeContainerValues();
}

MatrixAutoViewportContainer.prototype.scrollToRow = function(startIndex){
    var startPos = this.calcScrollPos(startIndex,this.maxIndex,this.currentScrollMax);
    this.container[0].scrollTop = startPos;
}

/*Scrolls the container to th especified index*/
MatrixAutoViewportContainer.prototype.scroll = function(startIndex){
    var isMoreDataLoaded = false;
    var upperThresholdMet = (this.currentRangeStart > Math.max(0, startIndex - this.rowCacheThreshold));
    var lowerThresholdMet = (this.currentRangeEnd < (this.rowThreshold + startIndex));
        
    if((upperThresholdMet || lowerThresholdMet) && (isNaN(this.currentStartIndex)||this.currentStartIndex!=startIndex) ){
        /*console.log('------ CALC BEFORE START --------');
        console.log('START_INDEX - '+startIndex);
        console.log('RANGE_START - '+this.currentRangeStart+' - CURRENT_INDEX - '+this.currentStartIndex+' - RANGE_END - '+this.currentRangeEnd+' - MAX_INDEX - '+this.maxIndex);
        console.log('------ CALC END --------');
        console.log('');*/
        var rangeStart = this.currentRangeStart = Math.max(0, startIndex - this.rowCacheThreshold);
        var rangeEnd = this.currentRangeEnd = Math.min(this.dataContainer.pageData.length, this.rowCacheThreshold + this.rowThreshold + startIndex);
        this.dataContainer.virtualData = this.dataContainer.pageData.slice(rangeStart,rangeEnd);
        this.currentStartIndex = startIndex;
        var startPos = this.calcScrollPos(rangeStart);//,this.maxIndex,this.scrollMax);
        this.container.find('.matrix-table').css('transform','translate(0px, '+startPos+'px');
        /*console.log('------ CALC AFTER START --------');
        console.log('START_POS - '+startPos);
        console.log('START_INDEX - '+startIndex);
        console.log('RANGE_START - '+this.currentRangeStart+' - CURRENT_INDEX - '+this.currentStartIndex+' - RANGE_END - '+this.currentRangeEnd+' - MAX_INDEX - '+this.maxIndex);
        console.log('------ CALC END --------');
        console.log('');*/
        
        isMoreDataLoaded = true;
    }
    return isMoreDataLoaded;
}
/*Mehtod to scroll the headers on container scroll*/
MatrixAutoViewportContainer.prototype.scrollHorizontally = function(event){
    var newScrollLeft = this.container[0].scrollLeft;
    if(newScrollLeft != this.currentScrollLeft){
        this.container.parent().find('.matrix-header-viewport')[0].scrollLeft = newScrollLeft;
        this.currentScrollLeft = this.container[0].scrollLeft;
    }
}
/*Mehtod to update the row heights in the cache upon rendering*/
MatrixAutoViewportContainer.prototype.updateRowCache = function(rowIndex, height, adjustTop){
    if(!this.rowCache.hasOwnProperty(rowIndex) || this.rowCache[rowIndex] != height){
        var prev = this.rowCache[rowIndex] || this.AVG_HEIGHT;
        this.rowCache[rowIndex] = height;
        // console.log("setting scrolll top "+this.currentScrollTop);
        this.container.scrollTop(this.currentScrollTop);        
        this.setDataContainerHeight(this.currentScrollMax + (height-prev));
        if(adjustTop){
            var startPos = this.calcScrollPos(this.currentRangeStart);
            this.container.find('.matrix-table').css('transform','translate(0px, '+startPos+'px');
        }
    }
}
/*AutoHeightViewportfactory to return the instances of container*/
function MatrixAutoHeightViewportFactory(){
    return {
        getContainer : function(element, matrix, scrollInfo, pagingInfo){
            return new MatrixAutoViewportContainer(element, matrix, scrollInfo, pagingInfo);
        }
    }
}
angular.module('wf.framework').factory('MatrixAutoHeightViewportFactory', MatrixAutoHeightViewportFactory);
})();

(function(){
angular.module('wf.framework')
.directive('wfMatrixDataCol',['$compile', function($compile){
    return {
        multiElement:true,
        restrict:'C',
        require:'^wfMatrix',
        compile:function(element,attrs){
            return {
                pre: function(scope, element, attrs, mCtrl, transclude){
                    scope.$colIndex = (scope.getColIndex = function(){return scope.$index})();                    
                    if(!scope.options.autoAdjustHeight){                        
                        element.css({'height':mCtrl.viewportContainer.AVG_HEIGHT});
                    }
                    if(scope.matrixRow.$isEmpty){
                        element.append('<div>-</div>'); 
                        return;
                    }
                    if(!scope.options.turnOffAngularCompile && (typeof scope.matrixCol.$$angularcompile == "undefined" || scope.matrixCol.$$angularcompile == true)){
                        if(scope.matrixCol.cellTemplate){
                            element.append($compile('<div>'+scope.matrixCol.cellTemplate+'</div>')(scope));
                        }else if(scope.matrixCol.field && scope.matrixRow.hasOwnProperty(scope.matrixCol.field)){
                            element.append($compile('<div>{{matrixRow[matrixCol.field]}}</div>')(scope));
                        }
                    }else{
                        if(scope.matrixCol.field && scope.matrixRow.hasOwnProperty(scope.matrixCol.field)){
                            element.append('<div>'+scope.matrixRow[scope.matrixCol.field]+'</div>');
                        }
                    }
                }
            }
        }
    }
}]);
})();      

(function(){
function MatrixDataContainer(logger, $filter) {
    this.$filter = $filter;
    this.matrixOriginalData = [];
    this.matrixData = [];
    this.pageData = [];
    this.virtualData = [];
    this.matrixColumns = [];
    this.renderedColumns = [];
}  
/*Sets the updated data to the matrix*/
MatrixDataContainer.prototype.setMatrixData = function(data, options){
    var pageInfo  = options.pagingInfo;
    var sortInfo = options.sortInfo;
    this.matrixData = this.matrixOriginalData = data && data.length > 0 ? data : new Array();   
    
    //storinng the original data index inside the row 
    this.matrixData.forEach(function(value,key){value.$$index = key});    
    
    if(sortInfo.enable && !sortInfo.external){
       //pagination will be taken care after sorting
       this.sortData(sortInfo.sortOrders, pageInfo); 
    }else if(pageInfo.enable && pageInfo.virtual){
       this.setPaging(pageInfo);
    }else{
       this.matrixData = this.pageData = data || new Array();
    }
    
    if(options.showEmptyRow && this.matrixData.length == 0){
        this.pageData.push({$isEmpty:true})
    }
    this.virtualData = [];
}
/*Sorts the matrix data and handles the pagination*/
MatrixDataContainer.prototype.sortData = function(sortOrders, pageInfo){
    if(this.$filter && typeof this.$filter == "function" && Array.isArray(sortOrders) && sortOrders.length>0){
        this.matrixData =  this.$filter('orderBy')(this.matrixOriginalData, sortOrders)
    }else if(!Array.isArray(sortOrders) || !(sortOrders.length>0)){
        this.matrixData = this.matrixOriginalData;
    }
    if(pageInfo.enable && pageInfo.virtual){
        this.setPaging(pageInfo);
    }else{
        this.pageData = this.matrixData ;
    }
    this.virtualData = [];
}
/*Adjust data according to the pages*/
MatrixDataContainer.prototype.setPaging = function(pageInfo){
    this.pageData = this.matrixData.slice(pageInfo.paging.startIndex,pageInfo.paging.startIndex+pageInfo.paging.rowsPerPage);
    pageInfo.paging.endIndex = pageInfo.paging.startIndex + this.pageData.length-1;
    pageInfo.paging.totalRecords = this.matrixData.length;
}
/*Sets the updated column definitions to the matrix*/
MatrixDataContainer.prototype.setMatrixColDefs = function(data){
    this.matrixColumns = data || new Array();
    this.renderedColumns = this.matrixColumns.filter(isRenderableColumn)
}
/*Destroys the conatiner variables*/
MatrixDataContainer.prototype.onDestroy = function(){
    this.scopeData = [];
    this.pageData = [];
    this.virtualData = [];
    this.matrixColumns = [];
    this.renderedColumns = [];
}


function InitializeMatrixColumnDefinition(colDef, key, array){
    var defaults = {
        field : '',
        displayName : '',
        sortable : true,
        isInitialized:true,
        width:'*',
        draggable:true
    }
   array[key] = angular.extend(defaults, colDef);   
};
    
function isRenderableColumn(colDef, key, array){
    colDef.$index = key;
    if(!colDef.isInitialized){
        InitializeMatrixColumnDefinition(colDef, key, array)
    }        
    if(colDef && !colDef.hide){
        return true
    } 
    return false;   
}      
       
/*Datafactory to return the instances of container*/                
function MatrixDataFactory($log, $filter){
    var logger = $log.getInstance("MatrixDataFactory")
    return { 
        getContainer : function(element, matrix, scrollInfo){
            return new MatrixDataContainer(logger, $filter);
        }
    }
}     
           
angular.module('wf.framework').factory('MatrixDataFactory', ['$log','$filter', MatrixDataFactory]);
})();
(function(){  
    
MatrixRowController.$inject = ['$scope'];
function MatrixRowController($scope){
    this.rowClicks = [];
    this.rowClasses = [];
    this.rowClassExpr = '';
    var self = this;
    this.onRowClick = function(row, rowIndex){
        this.rowClicks.forEach(function(rowClickFn){
            if(typeof rowClickFn == "function"){
                rowClickFn.call(undefined, row, rowIndex);
            }
        });
    }
    this.addToClickEvents = function(rowClickFn){
        this.rowClicks.push(rowClickFn);
    }
    this.addToRowClasses = function(expr){
        this.rowClasses.push(expr);
        this.updateRowClassesExpr();
    }
    this.updateRowClassesExpr = function(){
        var expr = "["
        this.rowClasses.forEach(function(classExpr){
            expr = expr+classExpr+','; 
        })
        expr = expr + "]";
        this.rowClassExpr = expr;
    }
    this.removeFromRowClasses = function(className){}
    $scope.$on('$destroy', function(){
        self.rowClicks = []; 
    });
}    
    
angular.module("wf.framework")
.directive('wfMatrixDataRow',['$compile', '$timeout', function($compile, $timeout){
    return {
        multiElement:true,
        restrict:'C',
        require:['^wfMatrix','wfMatrixDataRow'],
        controller : MatrixRowController,
        controllerAs : 'matrixDataRow',
        compile:function(element,attrs){
            return {
                pre: function(scope, elem , attrs, ctrls, transclude){
                        scope.row = scope.matrixRow;
                        scope.$rowIndex = (scope.getRowIndex = function(){
                            if(scope.options.pagingInfo.virtual) {
                                return (scope.options.pagingInfo.paging.startIndex+scope.$index+scope.virtualStartIndex)//+(*scope.options.pagingInfo.paging.currentPage))-1;
                            }
                            return scope.$index+scope.virtualStartIndex;
                        })();
                        scope.$watch('$index',function(){
                            scope.$rowIndex = scope.getRowIndex();
                            scope.$rowEven = (scope.$rowIndex % 2) == 0;
                            scope.$rowOdd = (scope.$rowIndex % 2) != 0;
                        });
                },
                post:function(scope, elem, attrs, ctrls, transclude){
                    ctrls[1].addToRowClasses('$rowEven ? \'row-even\':\'row-odd\'');
                    scope.rowClick = function(){
                        ctrls[1].onRowClick(scope.row,scope.$rowIndex);
                    }
                    if(scope.options.autoAdjustHeight){
                        scope.$evalAsync(function() {
                            ctrls[0].viewportContainer.updateRowCache(scope.$rowIndex, elem.outerHeight(), true);                            
                        });
                        scope.$on('$matrixRowHeightChange', function(){
                            $timeout(function() {
                                ctrls[0].viewportContainer.updateRowCache(scope.$rowIndex, elem.outerHeight(), true);
                            });
                        }); 
                    }else{
                        element.css({height:ctrls[0].viewportContainer.AVG_HEIGHT,'max-height':ctrls[0].viewportContainer.AVG_HEIGHT, 'white-space': 'nowrap'});
                    }
                }
            }
        }
    }
}]);   
})();

(function(){

angular.module('wf.framework')
.directive('wfMatrixHeader', ['$compile', '$perf', '$log', '$templateCache',function($compile, $perf, $log, $templateCache){
    return {
        restrict : 'A',
        require:'^wfMatrix',
        transclude:true,
        link : function(scope, element, attrs, matrixController, transclude){
            var colHeaders = angular.element($templateCache.get('div/wf-matrix-header-cols.html'));
            var headerRow = element.find('.wf-matrix-header-row');
            if(scope.options.headerColumnClasses && Array.isArray(scope.options.headerColumnClasses)){
                scope.options.headerColumnClasses.forEach(function(classExpr){
                    colHeaders.addClass(classExpr);
                })
            }
            if(scope.options.headerRowClasses && Array.isArray(scope.options.headerRowClasses)){
                scope.options.headerRowClasses.forEach(function(classExpr){
                    headerRow.addClass(classExpr);
                })
            }
            /*if(scope.options.enableColumnReordering){
                colHeaders.addClass('wf-matrix-header-draggable');
            }*/
            headerRow.append($compile(colHeaders)(scope));
            headerRow = null;
            colHeaders = null;
        },
        templateUrl: 'div/wf-matrix-header.html'
    }
}])   
.directive('wfMatrixHeaderCol', ['$compile', '$perf', '$log', '$templateCache', 'wfMatrixSortService', '$filter', function($compile, $perf, $log, $templateCache, wfMatrixSort, $filter){
    return {
        restrict : 'A',
        transclude : true,
        compile : function(tElement, tAttrs,ctransclude){
            return {
                pre : function(scope, element, attrs, matrixController,transclude){
                        
                    transclude(function(clone,scope){
                        //logger.debug("Transcluding the display name in to header tag");
                        var captionElement = angular.element($templateCache.get('col-header.html'));
                        if(!scope.options.turnOffAngularCompile && typeof scope.matrixCol.$$angularcompile == "undefined" || scope.matrixCol.$$angularcompile == true){
                            if(scope.matrixCol.headerCellTemplate){
                                captionElement.append($compile(scope.matrixCol.headerCellTemplate)(scope));
                            }else{
                                captionElement.append('{{matrixCol.displayName}}');
                            }
                            element.append($compile(captionElement)(scope));
                        }else{
                            if(scope.matrixCol.displayName){
                                captionElement.append(scope.matrixCol.displayName);
                                element.append(captionElement);
                            }
                        }                            
                        captionElement = null;
                    });
                    
                    if(scope.options.sortInfo.enable && scope.matrixCol.sortable){
                        transclude(scope,function(clone,scope){
                            //logger.debug("Transcluding the sort icon in to header tag");
                            var sortElement = angular.element($templateCache.get('col-header-sort.html'));
                            scope.sortColumn = function(event){
                                wfMatrixSort.sortColumn(scope.options.sortInfo, scope.matrixCol.field);
                                if(!scope.options.sortInfo.external){
                                    scope.matrix.dataContainer.sortData(scope.options.sortInfo.sortOrders, scope.options.pagingInfo)
                                    scope.matrix.renderContainer();
                                    if(typeof scope.options.onSort == 'function'){
                                        scope.options.onSort(scope.options.sortInfo);
                                    }
                                }else{
                                    scope.matrix.loadSortData();
                                }
                                return false;
                            }
                            sortElement.attr('ng-click',"sortColumn();");
                            element.find('.column-header').append($compile(sortElement)(scope));
                            if(scope.options.sortInfo.multiple) {
                                scope.removeSort = function(event){
                                    wfMatrixSort.removeSort(scope.options.sortInfo, scope.matrixCol.field);
                                    if(!scope.options.sortInfo.external){
                                        scope.matrix.dataContainer.sortData(scope.options.sortInfo.sortOrders, scope.options.pagingInfo)
                                        scope.matrix.renderContainer();
                                        if(typeof scope.options.onSort == 'function'){
                                            scope.options.onSort(scope.options.sortInfo, scope.matrix.dataContainer.matrixData);
                                        }
                                    }else{
                                        scope.matrix.loadSortData();
                                    }
                                    return false;
                                }
                                var sortRemoveElement = angular.element($templateCache.get("col-sort-remove.html"));
                                element.find('.column-header').append($compile(sortRemoveElement)(scope));
                            }
                            sortElement = null;
                        });
                    }
                }
            }
        }
    }
}])    
})();
(function(){
function  DragHandleController(scope){
    var self=this;
    this.srcIndex  =  undefined;
    this.init = function($element, draggable, getIndex){
        if(draggable){
            $element.addClass('movable');
            $element.attr('draggable', true);
            this.setDragImage($element, getIndex);
            $element.attr('ondragover', "event.preventDefault()");
            $element.on("drop", function(event) {
                self.dropFn(event, getIndex());
            });
        }
        $element.on('$destroy', function(){
            var $element = $(this);
            $element.removeAttr('draggable');
            $element.removeAttr('ondragover');
            $element.off();
            $element = null;
        })
        $element = null;
    },
    this.createDragImage = function($node, x, y) {
        var $img = $node.find(".column-header").clone().removeAttr('style').removeClass().addClass('moveable-column');
        $img.css({"top": y,"left": x,"pointerEvents": "none"}).appendTo(document.body);
        setTimeout(function() {
            $img.remove();
            $img = null;
        });
        return $img[0];
    },
    this.setDragImage  = function($element, getIndex){
        $element.on("dragstart", function(e) {
            self.srcIndex = getIndex();
            var originalEvent = e.originalEvent,
                dt = originalEvent.dataTransfer;
            dt.setData("text", "text"); //this  is to make draggable work in firefox
            originalEvent= null;
            dt=null;
        });

    },
    this.moveColumn  = function(srcIndex, destIndex){
        var defs = scope.matrix.dataContainer.matrixColumns;
        defs.splice(destIndex, 0, defs.splice(srcIndex, 1)[0]);
        scope.matrix.updateColumnDefs(defs);
    },
    this.dropFn  = function(event, destIndex){
        event.preventDefault();
        this.moveColumn(this.srcIndex, destIndex)
        if(angular.isFunction(scope.options.onTableStateChange)){
            scope.options.onTableStateChange(scope.options.columnDefs);
        }
        if(!scope.$$phase){
            scope.$digest();
        }
        this.srcIndex=undefined;
    }
}
angular.module("wf.framework")
.directive('wfMatrixDraggable', function MatrixHeaderResizable(){
    return {
        restrict : 'C',
        require:'^wfMatrix',
        controller:['$scope',DragHandleController],
        controllerAs:'dragHandler',
        link : function(scope, elem, attrs, matrixCtrl){
            if(!scope.options.headerColumnClasses)
                scope.options.headerColumnClasses = [];
            scope.options.headerColumnClasses.push("wf-matrix-header-draggable");                
            scope.$on('$destroy',function(){
                scope.dragHandler.dropFn=null;
            });
        }
    }
})
.directive('wfMatrixHeaderDraggable', function MatrixHeaderResizable(){
    return {
        restrict : 'C',
        require:['^wfMatrix','^wfMatrixDraggable'],
        link : function(scope, elem, attrs, ctrls){
             //console.log("wfMatrixHeaderDraggable linked");
             var getIndex = function(){
                 return scope.matrixCol.$index;
             }
             if(scope.options.enableColumnReordering && scope.matrixCol.draggable){
                 scope.dragHandler.init(elem, scope.matrixCol.draggable, getIndex);
             }
        }
    }
});
})();
/* global . */
(function(){
function ResizeHandlerController(scope){
    var self = this;
    this.initialWidth = 0;
    this.startPageX   = 0;
    this.columnDef = undefined;
    this.initialHandlerPos = 0;    
    this.isResizing =false;
    this.element = undefined;
    this.colElem = undefined;
    this.headerElem  = undefined;
    this.viewportElem = undefined;
    this.turnoffResizeEvents = function(){
        self.initialWidth = 0;
        self.startPageX = 0;
        self.element.parent().removeClass('header-resizing');
        self.columnDef = undefined;
        self.element = undefined;
        self.colElem = undefined;        
        $(document).off('mouseup',self.upFn);
        $(document).off('mousemove',self.moveFn);
        self.isResizing = false;
    },
    this.upFn = function(event){
        var endPageX = event.clientX;
        var diff = endPageX-self.startPageX;
        var width = self.initialWidth + diff;
        self.columnDef.width = self.columnDef.calculatedWidth = (width>21?width:21);
        
        event.stopPropagation();
        self.headerElem.hide();
        self.viewportElem.hide();
        self.turnoffResizeEvents();
        scope.matrix.calculateWidths();
        if(angular.isFunction(scope.options.onTableStateChange)){
            scope.options.onTableStateChange(scope.matrix.dataContainer.matrixColumns);
        }
        if(scope.options.autoAdjustHeight){
            scope.$broadcast('$matrixRowHeightChange'); 
        }
        scope.$digest();
        return false;
    },
    this.moveFn = function(event){
        event.stopPropagation();
        var endPageX = event.clientX;
        var diff = endPageX-self.startPageX;
        var width = self.initialWidth + diff;
        self.headerElem.show();
        self.viewportElem.show();
        if(width>=21){
            self.headerElem.offset({'left':event.clientX});
            self.viewportElem.offset({'left':event.clientX});
        }
        return false;
    },
    this.turnonResizeEvents = function(pageX, element, matrixCol) {
        self.isResizing = true;
        self.initialWidth = element.outerWidth();
        self.initialHandlerPos = 0;
        self.startPageX = pageX;
        self.columnDef = matrixCol;
        self.element = element;
        self.element.parent().addClass('header-resizing');
        self.viewportElem.css('height',self.viewportElem.parent()[0].clientHeight);
        $(document).on('mousemove', self.moveFn);
        $(document).on('mouseup', self.upFn);
        element.on('$destroy',function(){
            $(this).off();
            self.headerElem = undefined;
            self.viewportElem = undefined;
        });
        element=null;
    }
}

angular.module("wf.framework")
.directive('wfMatrixResizable', function MatrixHeaderResizable(){
    return {
        restrict : 'C',
        require:'^wfMatrix',
        controller:['$scope',ResizeHandlerController],
        controllerAs:'resizeHandler',
        link : function(scope, elem, attrs, matrixCtrl){
            if(scope.options.resizable){
                if(!scope.options.headerColumnClasses)
                    scope.options.headerColumnClasses = [];
                scope.options.headerColumnClasses.push("wf-matrix-header-resizable"); 
                scope.$on('$destroy',function(){
                    scope.resizeHandler.upFn = null;
                });
            }
        }
    }
})
.directive('matrixHeaderHolder', function MatrixHeaderResizable(){
    return {
        restrict : 'C',
        require:'^wfMatrix',
        link : function(scope, elem, attrs, matrixCtrl){
            if(scope.options.resizable){
                elem.prepend('<div class="ui-resizer"></div>');
                scope.resizeHandler.headerElem = elem.find('.ui-resizer');
                scope.resizeHandler.headerElem.hide();
            }
        }
    }
})
.directive('matrixViewport', function MatrixHeaderResizable(){
    return {
        restrict : 'C',
        require:'^wfMatrix',
        link : function(scope, elem, attrs, matrixCtrl){
            if(scope.options.resizable){
                elem.prepend('<div class="ui-resizer"></div>');
                scope.resizeHandler.viewportElem = elem.find('.ui-resizer');
                scope.resizeHandler.viewportElem.hide();
            }
        }
    }
})
.directive('wfMatrixHeaderResizable', ['$compile', function MatrixHeaderResizable($compile){
    var RESIZER_TAG='<div class="resizable-handler" ng-mousedown="resizeStart($event,$index)" style="z-index: 90;"></div>';
    return {
        restrict : 'C',
        require:['^wfMatrix','^wfMatrixResizable'],
        link : function(scope, elem, attrs, ctrls){
            var resizeHandler = ctrls[1];
             if(scope.options.resizable && typeof scope.matrixCol.resizable == "undefined" || scope.matrixCol.resizable ){
                scope.resizeStart = function($event, index){
                    var event = $event.originalEvent;
                    event.stopPropagation();
                    resizeHandler.turnonResizeEvents(event.clientX,elem, scope.matrixCol);
                    event.preventDefault();
                    event = null;
                }
                elem.prepend($compile(RESIZER_TAG)(scope));
             }
             
        }
    }
}]);
})();
/* global columnContainer */

//link -  http://core-confluence.wellsfargo.com:8090/display/FPL/WF+Matrix
/**
 * wf-matrix is the newer version of wf-grid
 */
(function(window){
    
    /**
     * logger for matrix
     */
    var logger = undefined;
    
    /**
     * method to extend the options with the default matrix options
     * @param options
     * @param element
     */
    function InitializeMatrixOptions(scope,sortService){
        var defaults = {
            autoAdjustHeight:false,
            data : 'matrixData',
            title : '',
            columnDefs : 'matrixColumnDefs',
            showEmptyRow: true,
            rowSelection:{
                enable:true
            },
            enableContextMenu : false,
            contextMenuOptions:[],
            enableColumnReordering :false,
            resizable: true            
        }
        if(!scope.options){scope.options = {}}
        scope.options = angular.extend(defaults,scope.options)
        InitializeMatrixSortInfo(scope.options, sortService);
        InitializeMatrixPagingInfo(scope.options);
    }

    /**
     * Initializes sort info and orders for the matrix
     * @param options
     */
    function InitializeMatrixSortInfo(options, sortService){
        var defaults = {fields:[],directions:[],sortOrders:[],multiple:false, enable : false, external : false}
        options.sortInfo = angular.extend(defaults,options.sortInfo);
        //override the option since external sorting callback funcitonality  is not provided yet
        //options.sortInfo.external = false;
        if(options.sortInfo.enable && !options.sortInfo.external)
            sortService.initializeSortOrders(options.sortInfo);
    }
    
    /**
     * Initializes matrix paging info
    */
    function InitializeMatrixPagingInfo(options){
        var defaults = {
                    enable : false,
                    virtual : false,
                    paging : {
                        startIndex : 0,
                        currentPage : 1,
                        totalPages : 1,
                        totalRecords : 0,
                        rowsPerPage : 25,
                        endIndex : 24
                    },
                    pageSizes : [5, 10, 25, 50, 75, 100],
                    enableGoToPage : true,
                    showBoundaryLinks : true
                };
        options.pagingInfo = angular.extend(defaults,options.pagingInfo);
        //override the option since external pagination callback funcitonality  is not provided yet
        //options.pagingInfo.virtual = true;
    }

    function  endsWith(str, suffix) {
      if (!str || !suffix || typeof str !== "string") {
        return false;
      }
      return str.indexOf(suffix, str.length - suffix.length) !== -1;
    }
    
    function setCalculatedWidth(column, width){
        column.calculatedWidth = width>=21?width:21;
    }

    function calculateWidths(renderedColumns, totalWidth, hasScroll){
        //console.log("Calculating widths")
        var asterisksArray = [],
        asteriskNum = 0,
        usedWidthSum = 0,
        ret = '';

        // Get the width of the viewport
        var singleColumnWidth;
        var availableWidth = singleColumnWidth = Math.ceil((totalWidth-(hasScroll?scrollWidth:0)));

        // look at each column, process any manual values or %, put the * into an array to look at later
        renderedColumns.forEach(function(column, i){ 
            var width = 0;
            setCalculatedWidth(column, 21);
            if (angular.isNumber(column.width)) {
                // pixel width, set to this value
                width = parseInt(column.width, 10);
                usedWidthSum = usedWidthSum + width;
                setCalculatedWidth(column, width);

            } else if (endsWith(column.width, "%")) {
                // percentage width, set to percentage of the viewport
                width = parseInt(parseInt(column.width.replace(/%/g, ''), 10) / 100 * availableWidth);

                if ( width > column.maxWidth ){
                width = column.maxWidth;
                }

                if ( width < column.minWidth ){
                width = column.minWidth;
                }

                usedWidthSum = usedWidthSum + width;
                setCalculatedWidth(column, width);
            } else if (angular.isString(column.width) && column.width.indexOf('*') !== -1) {
                // is an asterisk column, the gridColumn already checked the string consists only of '****'
                asteriskNum = asteriskNum + column.width.length;
                asterisksArray.push(column);
            }else if(angular.isNumber(column.calculatedWidth)){
                setCalculatedWidth(column, column.calculatedWidth);
            }
        });
        
        // Get the remaining width (available width subtracted by the used widths sum)
        var remainingWidth = availableWidth - usedWidthSum;

        //var i, column, colWidth;

        if (asterisksArray.length > 0) {
            // the width that each asterisk value would be assigned (this can be negative)
            var asteriskVal = remainingWidth / asteriskNum;

            asterisksArray.forEach(function( column ){
                var width = parseInt(column.width.length * asteriskVal, 10);

                if ( width > column.maxWidth ){
                width = column.maxWidth;
                }

                if ( width < column.minWidth ){
                width = column.minWidth;
                }

                usedWidthSum = usedWidthSum + width;
                setCalculatedWidth(column, width);
            });
        }

        // If the grid width didn't divide evenly into the column widths and we have pixels left over, or our
        // calculated widths would have the grid narrower than the available space,
        // dole the remainder out one by one to make everything fit
        var processColumnUpwards = function(column){
            if ((column.calculatedWidth < column.maxWidth || !column.maxWidth)&& leftoverWidth > 0) {
                column.calculatedWidth++;
                usedWidthSum++;
                leftoverWidth--;
                columnsToChange = true;
            }
        };

        var leftoverWidth = availableWidth - usedWidthSum;
        var columnsToChange = true;

        while (leftoverWidth > 0 && columnsToChange) {
        columnsToChange = false;
        asterisksArray.forEach(processColumnUpwards);
        }

        // We can end up with too much width even though some columns aren't at their max width, in this situation
        // we can trim the columns a little
        var processColumnDownwards = function(column){
        if (( column.calculatedWidth > column.minWidth || !column.minWidth ) && excessWidth > 21) {
            setCalculatedWidth(column, column.calculatedWidth--);
            usedWidthSum--;
            excessWidth--;
            columnsToChange = true;
        }
        };

        var excessWidth =  usedWidthSum - availableWidth;
        columnsToChange = true;

        while (excessWidth > 0 && columnsToChange) {
        columnsToChange = false;
        asterisksArray.forEach(processColumnDownwards);
        }
        return leftoverWidth;
    }
    
    //http://stackoverflow.com/a/13382873/888165
    function getScrollbarWidth() {
        var outer = document.createElement("div");
        outer.style.visibility = "hidden";
        outer.style.width = "100px";
        outer.style.msOverflowStyle = "scrollbar"; // needed for WinJS apps

        document.body.appendChild(outer);

        var widthNoScroll = outer.offsetWidth;
        // force scrollbars
        outer.style.overflow = "scroll";

        // add innerdiv
        var inner = document.createElement("div");
        inner.style.width = "100%";
        outer.appendChild(inner);

        var widthWithScroll = inner.offsetWidth;

        // remove divs
        outer.parentNode.removeChild(outer);

        return widthNoScroll - widthWithScroll;
    }
    var scrollWidth = getScrollbarWidth();

    function InitializeMatrix(scope, element, matrixTemplate, compile){
        var matrixElement = angular.element(matrixTemplate); 
        if(scope.options.enableColumnReordering){
            matrixElement.addClass('wf-matrix-draggable');
        }
        if(scope.options.rowSelection && scope.options.rowSelection.enable){
            matrixElement.addClass('wf-matrix-selectable');
        }
       element.append(matrixElement);
       compile(matrixElement)(scope);
       matrixElement=null;
    }     
    
    function hasScroll(element){
        var el = element.find('.wf-matrix-scroll-container');
        var hasScroll = el[0].scrollHeight > (el[0].clientHeight+2);
        el = null;
        return hasScroll;
    }  
    
    /**
     * Wf-matrix directive
     */
    angular.module('wf.framework').directive('wfMatrix', ['$compile', '$perf', '$log', 'wfMatrixSortService', '$timeout', '$parse', '$templateCache',
    function($compile, $perf, $log, wfMatrixSort, $timeout, $parse, $templateCache){
        return {
            scope :true,
            restrict : 'E',
            replace : true,
            controller : 'wfMatrixController',
            controllerAs : 'matrix',
            compile : function(tElement, tAttrs, cTransclude){
                return {
                    pre : function(scope, element, attrs, matrixController, transclude){
						scope.options = scope.$eval(attrs.options);
                        
                        if(typeof scope.options.beforeInit == 'function'){
                            scope.options.beforeInit(attrs.id); 
                        } 
                        
                        logger = $log.getInstance('wfMatrix');
                        logger.enableLogging(2);
                        
                        InitializeMatrixOptions(scope, wfMatrixSort);
                        
                        $parse(attrs.options).assign(scope.$parent, scope.options);
                        
                        matrixController.ngOnInit(scope, attrs);
                        
                        scope.matrix.loadPageData = function(){
                            //Resets the row height cache on eache page change
                            matrixController.viewportContainer.rowCache = {};                                                           
                            if(scope.options.pagingInfo.virtual){
                                scope.matrix.dataContainer.setPaging(scope.options.pagingInfo);
                                scope.matrix.renderContainer(false, true);
                            }else{
                                scope.$eval(attrs.loader,{pageInfo:scope.options.pagingInfo.paging, sortInfo:scope.options.sortInfo});
                            }
                        }

                        scope.matrix.loadSortData = function(){
                            scope.$eval(attrs.loader,{pageInfo:scope.options.pagingInfo.paging, sortInfo:scope.options.sortInfo});
                        }
                        
                        scope.options.$updateMatrixHeight = function(maxHeight){
                            if(typeof maxHeight == 'number')
                                scope.matrix.resizeMatrix(maxHeight);
                        }
                        
                        scope.$on('$destroy', function(){
                            scope.options.scrollToRow = undefined;
                            matrixController.ngOnDestroy();
                            scope.options.$updateMatrixHeight = null;
                        });
                        
                        // scope.$on('$heightUpdated', function(){
                        //     scope.$broadcast('virtualRowHeightUpdated');                   
                        // });
                        
                        InitializeMatrix(scope, element, $templateCache.get('div/wf-matrix.html'), $compile);
                    },
                    post : function(scope, element, attrs, matrixController){
                        
                        scope.matrix.calculateWidths= function(){
                            var elHasScroll = hasScroll(element);
                            calculateWidths(scope.matrix.dataContainer.renderedColumns, element.outerWidth()-2, elHasScroll); //2 for the border
                            if(elHasScroll){
                                element.find('.matrix-header-viewport').css('margin-right', scrollWidth);
                                element.find('.column-config').css('width', scrollWidth);
                            }else{
                                element.find('.matrix-header-viewport').css('margin-right', '');
                                element.find('.column-config').css('width', '');
                            }
                            if(scope.options.autoAdjustHeight){
                                scope.$broadcast('$matrixRowHeightChange'); 
                            }
                        };
                        
                        if(typeof scope.options.afterInit == 'function'){
                            scope.options.$isMatrixInitialized = true;
                            $timeout(function(){
                                scope.options.afterInit(attrs.id);                                
                            });
                        } 
                    }
                }
            },
            template : '<div class="wf-matrix-wrapper"> </div>'
        }
    }])

 }(window));
(function(){    
angular.module("wf.framework")
.directive('wfMatrixLoader', ['$compile','$perf', 'MatrixViewportFactory', 'MatrixAutoHeightViewportFactory', '$timeout', '$templateCache', '$log', function($compile, $perf, viewportFactory, autoHeightViewportFactory, $timeout, $templateCache, $log){
    logger = $log.getInstance('wfMatrixLoader');
    logger.enableLogging(2);
    return {
        restrict : 'E',
        require : '^wfMatrix',
        transclude:true,
        replace:true,
        compile : function(element, attrs){
            return {
                pre : function(scope, element, attrs, mCtrl, transclude){
                        var rowsTemplate = angular.element($templateCache.get('div/wf-matrix-rows.html'));
                        if(Array.isArray(scope.options.rowClasses)){
                            scope.options.rowClasses.forEach(function(value){
                                rowsTemplate.addClass(value);
                            });
                        }
                        if(scope.options.enableContextMenu){
                            rowsTemplate.attr("wf-context-menu","options.contextMenuOptions");
                        }
                        element.find('.matrix-table').append($compile(rowsTemplate)(scope));
                        rowsTemplate = null;
                    },
                    post : function(scope, element, attrs, mCtrl, transclude) {
                        //logger.debug('Matrix Loader link -- Start');

                        var matrix = scope.matrix;
                        var scrollInfo = scope.options.scrollInfo;
                        var viewportContainer = undefined;
                        if(scope.options.autoAdjustHeight){
                            viewportContainer = scope.matrix.viewportContainer = autoHeightViewportFactory.getContainer(element, matrix.dataContainer, scrollInfo, scope.options.pagingInfo);
                        }else{
                            viewportContainer = scope.matrix.viewportContainer = viewportFactory.getContainer(element, matrix.dataContainer, scrollInfo);
                        }
                        
                        scope.options.scrollToRow = function(rowIndex){
                            scope.matrix.viewportContainer.scrollToRow(rowIndex);
                        }                       
                        
                        matrix.renderContainer = function(force, resetScroll){
                            if(resetScroll)element[0].scrollTop = 0;
                            if(viewportContainer.renderContainer()){
                                updateVirtualStartIndex();
                                if(force){
                                    if(!scope.$$phase) {
                                        scope.$digest();
                                    }
                                }
                                $timeout(function(){
                                    logger.debug("Render Complete")
                                    scope.matrix.calculateWidths();
                                });
                            }
                        }

                        matrix.resizeMatrix = function(viewportMaxHeight){
                            if(viewportMaxHeight){
                                viewportContainer.setMaxHeight(viewportMaxHeight);
                            }
                            matrix.renderContainer(true);
                        }
                        
                        mCtrl.addToDataWatchers(function(newVal){
                            matrix.renderContainer()
                        });
                        /* uncomment if needed to use bind-once since column changes wont get detected unless data changes
                           mCtrl.addToColDefsWatchers(function(newVal){
                           matrix.dataContainer.virtualData = [];
                            $timeout(function(){
                                //mCtrl.updateData(matrix.dataContainer.matrixData)
                                matrix.renderContainer()
                            });
                        });*/
                        element.on('scroll', function(event){
                            if(viewportContainer.virtualScrollHandler(event)){
                                updateVirtualStartIndex();
                                scope.$digest();
                            }
                            viewportContainer.scrollHorizontally();
                        });
                        //function will run on destroy
                        mCtrl.watches.push(function(){
                            viewportContainer.onDestroy();
                            element.off();
                        });

                        function updateVirtualStartIndex(startIndex){
                            if(startIndex){
                                scope.virtualStartIndex = startIndex;
                            }else{
                                scope.virtualStartIndex = viewportContainer.currentRangeStart;
                            }
                        }

                        //logger.debug('Matrix Loader link -- End');
                    }
            }
            
        },
        templateUrl:'div/wf-matrix-virtual-loader.html'
    }
}])
})();
(function(){
        
function page(active, pageNo){
    this.active = active ? true : false;
    this.number = pageNo ? pageNo : 0;
}

angular.module('wf.framework').directive('wfMatrixPagination', ['$compile','$templateCache','$animate',function($compile,$templateCache,$animate){
    return {
        restrict : 'E',
        require : '^wfMatrix',
        scope : true,
        replace : true,
        transclude:true,
        templateUrl : 'div/wf-matrix-pagination.html',
        compile : function(tElement, tAttrs, ctransclude){
            return {
                pre : function($scope, element, attrs, ctrl, transclude ){
                    $scope.paginationSize = 4;
                    $scope.pageSizes = $scope.options.pagingInfo.pageSizes;        
                    
                    if (!$scope.options.pagingInfo.paging.rowsPerPage){                    	
                        $scope.options.pagingInfo.paging.rowsPerPage = 25;    // default value - 25
                    }                        
                
                    $scope.showFirstOrPreviousPageLink = false;
                    
                    $scope.showLastOrNextPageLink = false;
                
                    var calculatePaging = function(){                    	
                        var totalRecords = $scope.options.pagingInfo.paging.totalRecords; 
                        if(!$scope.options.pagingInfo.paging.currentPage || !$scope.uiTotalRecords){
                            $scope.options.pagingInfo.paging.currentPage = 1;
                        }     				
                        $scope.options.pagingInfo.paging.totalPages = (totalRecords != undefined || totalRecords === 0)?Math.ceil(totalRecords/$scope.options.pagingInfo.paging.rowsPerPage) : 1;							
                        $scope.options.pagingInfo.paging.startIndex = (($scope.options.pagingInfo.paging.currentPage * $scope.options.pagingInfo.paging.rowsPerPage) - $scope.options.pagingInfo.paging.rowsPerPage) ;
                        $scope.options.pagingInfo.paging.endIndex =   $scope.options.pagingInfo.paging.startIndex + $scope.options.pagingInfo.paging.rowsPerPage-1;
                        //$scope.options.pagingInfo.paging.endIndex =   $scope.options.pagingInfo.paging.startIndex + $scope.matrix.dataContainer.pageData.length-1;
                        //$scope.options.pagingInfo.paging.endIndex = ($scope.options.pagingInfo.paging.currentPage * $scope.options.pagingInfo.paging.rowsPerPage) - 1;               		    
                    };
                    
                    var resetLinks = function(newValue, oldValue) {						
                        if(newValue || oldValue){							
                            $scope.uiTotalRecords = newValue;
                            calculatePaging();							
                            $scope.adjustPages();							
                            if ($scope.options.pagingInfo.paging.currentPage > 1) {	                             
                                $scope.showFirstOrPreviousPageLink = true;
                            } else {	                            
                                $scope.showFirstOrPreviousPageLink = false;
                            }
                            if ($scope.options.pagingInfo.paging.currentPage >= $scope.options.pagingInfo.paging.totalPages) {	                        
                                $scope.showLastOrNextPageLink = false;
                            } else {	                            
                                $scope.showLastOrNextPageLink = true;
                            }
                            
                        }
                        
                    }

                    $scope.$watch('options.pagingInfo.paging', function(newValue, oldValue) {
                        if(newValue){
                            resetLinks(newValue.totalRecords);
                        }                    		
                    });
                    
                    $scope.$watch('options.pagingInfo.paging.totalRecords', resetLinks);					
                    
                    $scope.loadData = function(){
                        $scope.uiTotalRecords = $scope.options.pagingInfo.paging.totalRecords;
                        $scope.options.pagingInfo.paging.totalRecords = 0;												
                        calculatePaging();               		    
                        $scope.matrix.loadPageData();
                        if($scope.options.pagingInfo.virtual || $scope.options.pagingInfo.paging.totalRecords!=0){
                            resetLinks($scope.options.pagingInfo.paging.totalRecords);
                        }
                    };
                    
                    
                    $scope.pages = [];
                    $scope.adjustPages = function(){						
                        $scope.pages.length = 0
                        var currentPage = $scope.options.pagingInfo.paging.currentPage;						
                        var totalPages = $scope.options.pagingInfo.paging.totalPages;						
                        if(totalPages <= $scope.paginationSize || (currentPage <= $scope.paginationSize-1)){							
                            for(var index = 0; index < $scope.options.pagingInfo.paging.totalPages ; index++){								
                                $scope.pages.push(new page(($scope.options.pagingInfo.paging.currentPage == (index+1)), index+1));
                            }
                        }else{							
                            if(currentPage < totalPages){
                                $scope.pages.push(new page(false, currentPage-2));
                                $scope.pages.push(new page(false, currentPage-1));
                                $scope.pages.push(new page(true, currentPage));
                                $scope.pages.push(new page(false, currentPage+1));
                            }else if(currentPage == totalPages){
                                $scope.pages.push(new page(false, currentPage-3));
                                $scope.pages.push(new page(false, currentPage-2));
                                $scope.pages.push(new page(false, currentPage-1));
                                $scope.pages.push(new page(true, currentPage));
                            }							
                        }
                    }					
                    
                    $scope.setPage = function(pageNo){						
                        pageNo = parseInt(pageNo);
                        if(pageNo){						
                            $scope.options.pagingInfo.paging.currentPage = pageNo;							
                            $scope.loadData();
                        }						
                    }

                    $scope.getFirstPage = function() {	
                        $scope.options.pagingInfo.paging.currentPage = 1;	
                        $scope.loadData();	
                    };

                    $scope.getPreviousPage = function() {						
                        if($scope.showFirstOrPreviousPageLink){						
                            $scope.options.pagingInfo.paging.currentPage = $scope.options.pagingInfo.paging.currentPage - 1;							
                            $scope.loadData();							
                        }
                    };

                    $scope.getNextPage = function() {	
                        if($scope.showLastOrNextPageLink){							
                            $scope.options.pagingInfo.paging.currentPage = $scope.options.pagingInfo.paging.currentPage + 1;							
                            $scope.loadData();							
                        }
                    };

                    $scope.getLastPage = function() {	
                        $scope.options.pagingInfo.paging.currentPage = $scope.options.pagingInfo.paging.totalPages;	
                        $scope.loadData();	
                    };

                    $scope.perPageListBoxChange = function() {	
                        $scope.options.pagingInfo.paging.currentPage = 1;	
                        $scope.loadData();	
                    };
                    
                    //used to reseting current page 
                    //used in sorting
                    $scope.$parent.resetCurrentPage = function(){						
                        $scope.options.pagingInfo.paging.totalRecords = 0;
                        $scope.options.pagingInfo.paging.currentPage = 1;
                        calculatePaging();
                    };
                    
                    if ($scope.options.pagingInfo.enable) {
                        element.append($compile(angular.element($templateCache.get('pagingTemplate.html')))($scope));
                    }
                }
            };
        }
    };
}])
    
})();

/* global his */
(function(){
/*Row Selection options
enable : false
multiple : false, //Enables or disables multiple selection of rows - false by default
rowSelectionId : undefined, //Id to compare the objects - helps in retaining the selections. if not defined then objet references will be used
enablePreviousRowSelectStyle : false, //applies the class to previous selected rows when enabled - false by default - works only when selection is not multiple based
canDeselect : true, //Provides the ability to deselect a selected row - true by default
onRowSelect : function , // callback function after selecting a row with (row , rowindex) as parameters
onInit : function, // call back after initialization of selection object
previousRowSelectStyle : string <CSS CLASS NAME>, //Css class name for previous row selected
currentRowSelectStyle : string <CSS CLASS NAME>, //Css class name for current row selected

//Don't create the following $variables inside this selection config
//These are used by the grid and it may not work properly if these variables are altered
$rowsSelected : object, //Rows selected will be stored in this object by the pattern {index : row}
$backgroundColors : object, //Classes for the selected rows will be in this object by pattern {index : CssClass}
$currentRowIndex : number, //Current selection index will be stored in thios variable
$isInitialized : boolean // Variable specifies if the selection config was loaded into the grid
$getSelectedRows : function(){...}, //Method to get the array of rows selected
$selectRow : function(row){...}, //Method to select a row
$selectMatrixRowByIndex : function(rowIndex){...}, //selects the row in the matrix using the index relative to matrix data
$selectMatrixRow:function(row,rowindex, stopOnSelect)// used by the matrix to select the rows -- rowIndex will be relative to matrix data
$reset : function(resetAll){...} // Method to reset the selection - if resetAll is true then prvious row styles will also be cleared */
MatrixSelectionController.$inject = ['$scope', '$log'];
function MatrixSelectionController($scope, $log){
    this.multiple = false,
    this.rowSelectionId = undefined,
    this.enablePreviousRowSelectStyle = false,
    this.canDeselect = true,
    this.onRowSelect = undefined,
    this.onInit = undefined,
    this.$rowsSelected = {},
    this.$backgroundColors = {},
    this.$currentRowIndex = -1,
    this.$isInitialized = false;
    this.checkboxInfo = {};
    this.$getSelectedRows = function(){
        var $rowsSelected = this.$rowsSelected;
        return  Object.keys($rowsSelected).map(function (key) {
            return $rowsSelected[key];
        });
    },
    this.$getBackgroundSelection = function(){
        var $backgroundColors = this.$backgroundColors;
        return  Object.keys($backgroundColors).map(function (key) {
            return $backgroundColors[key];
        });
    },
    this.$isRowSelected = function(rowIndex){
        this.$rowsSelected.hasOwnProperty(rowIndex);
    },
    //can be used to select the row from the original data
    //onRowSelect callback wont be fired by calling this method
    this.$selectRow = function(row){
        if(row){
           var kIndex = findIndexOFSelectedObject(row, $scope.options.matrix.dataContainer.matrixData, this.rowSelectionId); 
           if (kIndex != -1) {
               this.$selectMatrixRow(row, kIndex, true);
           }else{
            $log.error("Row that needs to be selected does not exist");
           }
        }else{
            $log.error("Row that needs to be selected cannot be empty"); 
        } 
    },
    //selects the row in the matrix using the index relative to matrix data
    this.$selectMatrixRowByIndex = function(index){
        if(typeof index == 'number' && $scope.matrix.dataContainer.matrixData[index]){
            this.$selectMatrixRow($scope.matrix.dataContainer.matrixData[index], index);
        }else{
           $log.error("index should not be empty and should be of type number");  
        }
        
    },
    // used by the matrix to select the rows -- rowIndex will be relative to matrix data
    this.$selectMatrixRow = function(row, rowIndex, stopOnSelect){
        if((this.$currentRowIndex == rowIndex || this.$rowsSelected[rowIndex]) && this.canDeselect){
            if(!this.enablePreviousRowSelectStyle){
                delete this.$backgroundColors[rowIndex];
            }else {
                this.$backgroundColors[rowIndex] = {class : (this.previousRowSelectStyle ? this.previousRowSelectStyle : "selected-prev") ,row : row};
            }
            delete this.$rowsSelected[rowIndex];
            this.$currentRowIndex = -1;
        }else{
            if(!this.multiple){
                if(this.enablePreviousRowSelectStyle && this.$currentRowIndex != -1 && this.$backgroundColors[this.$currentRowIndex]){
                    this.$backgroundColors[this.$currentRowIndex].class=(this.previousRowSelectStyle ? this.previousRowSelectStyle : "selected-prev");
                    this.$backgroundColors[this.$currentRowIndex].isCurrent = false;
                }
                this.$reset();
            }
            this.$rowsSelected[rowIndex] = row;
            this.$backgroundColors[rowIndex] = {class : (this.currentRowSelectStyle ? this.currentRowSelectStyle : "selected-current") ,row : row, isCurrent:true};
            this.$currentRowIndex = rowIndex;
        }
        if(angular.isFunction(this.onRowSelect) && !stopOnSelect) {
            //$$matrixIndex is relative to original data supplied to matrix
            this.onRowSelect(row, row.$$index, rowIndex);
        }
    },
    //resets the matrix selection.
    this.$reset = function(resetAll){
        this.$rowsSelected = {};
        if(!this.enablePreviousRowSelectStyle || resetAll){
            this.$backgroundColors = {};
            this.$currentRowIndex = -1;
        }
    }
}   
  
function InitializeCheckboxOptions (scope){
    var defaults = {
        enable : false,
        columnDef : {
            draggable:false,
            resizable : false,
            headerCellTemplate : '<input type="checkbox" ng-model="selectCtrl.$checkAll" ng-change="selectAllRows(selectCtrl.$checkAll);"/>',
            cellTemplate : '<input type="checkbox" ng-model="selectCtrl.$backgroundColors[$rowIndex].isCurrent" ng-change="onCheckboxChange(row, $rowIndex)" ng-disabled="isCheckDisable($rowIndex)" ng-checked="selectCtrl.$backgroundColors[$rowIndex].isCurrent"/>',
            width:32
        },
        disableHighlighting : true
    }
    scope.options.rowSelection.checkboxInfo = angular.extend(scope.selectCtrl.checkboxInfo,defaults, scope.options.rowSelection.checkboxInfo);
}    

function findIndexOFSelectedObject(obj, list, compareId) {
    var i;
    for (i = 0; i < list.length; i++) {
        if (compareId && list[i][compareId] === obj[compareId]) {
            return i;
        }else if(!compareId && list[i]=== obj){
            return i;
        }
    }
    return -1;
}

    
angular.module("wf.framework")
.directive('wfMatrixSelectable', function MatrixSelectable(){
    return {
        restrict : 'C',
        require:'^wfMatrix',
        controllerAs: 'selectCtrl',
        controller: MatrixSelectionController,
        link : function(scope, element, attrs, matrixCtrl, transclude){            
            InitializeCheckboxOptions(scope);
            if(!scope.options.rowClasses){
                scope.options.rowClasses = [];
            }
            if(scope.options.rowSelection.enable){                
                scope.options.rowClasses.push('matrix-row-selectable');
                if(!scope.selectCtrl.checkboxInfo.enable || (scope.selectCtrl.checkboxInfo.enable && !scope.selectCtrl.checkboxInfo.disableHighlighting)){
                    scope.options.rowClasses.push('{{selectCtrl.$backgroundColors[$rowIndex].class}}');
                }
            }
            scope.options.rowSelection = angular.extend(scope.selectCtrl,scope.options.rowSelection );
            if(scope.selectCtrl.checkboxInfo.enable){
                if(!scope.selectCtrl.multiple){
                    scope.selectCtrl.checkboxInfo.columnDef.headerCellTemplate = undefined;
                }
                matrixCtrl.addToColDefsWatchers(function(){
                    matrixCtrl.dataContainer.renderedColumns.unshift(scope.selectCtrl.checkboxInfo.columnDef);
                    //scope.matrix.calculateWidths();
                });
            }
            /*matrixCtrl.addToDataWatchers(function(){
                //scope.selectAllRows(false);
                //scope.selectCtrl.$checkAll = false;
            })*/
            scope.$watch('matrix.dataContainer.matrixData',function(newVal){
                var rowSelection = scope.options.rowSelection;
                var rowsSelected = rowSelection.$getSelectedRows();
                var backGroundSelection = rowSelection.$getBackgroundSelection();                
                if(rowSelection){
                    rowSelection.$reset(true);
                    if(rowSelection.enablePreviousRowSelectStyle){
                        for(var key in backGroundSelection){
                            var index = findIndexOFSelectedObject(backGroundSelection[key].row, newVal, rowSelection.rowSelectionId);
                            if (index != -1) {
                                rowSelection.$backgroundColors[index] = {class : (this.previousRowSelectStyle ? this.previousRowSelectStyle : "selected-prev") ,row : newVal[index]};
                            }
                        }
                    }
                    for (var k = 0; k < rowsSelected.length; k++) {
                        var kIndex = findIndexOFSelectedObject(rowsSelected[k], newVal, rowSelection.rowSelectionId);
                        if (kIndex != -1) {
                            rowSelection.$selectMatrixRow(newVal[kIndex], kIndex);
                        }
                    }
                }
                scope.selectCtrl.$checkAll = (Object.keys(scope.selectCtrl.$rowsSelected).length == matrixCtrl.dataContainer.matrixData.length); 
                rowsSelected.length=0;
            });
            scope.selectAllRows = function(checked){
                if(checked){
                    scope.selectCtrl.$reset(true);
                    matrixCtrl.dataContainer.matrixData.forEach(function(row,rowIndex){
                        scope.selectCtrl.$selectMatrixRow(row, rowIndex);
                    })  
                }else{
                    scope.selectCtrl.$reset(true);
                }
            }
            
            scope.options.rowSelection.$isInitialized = true;
            if(typeof scope.options.rowSelection.onInit == 'function'){
                scope.options.rowSelection.onInit();
            }
        }
    }
})
.directive('matrixRowSelectable', function MatrixRowSelectable(){
    return {
        restrict : 'C',
        require:['^wfMatrix','^wfMatrixSelectable', 'wfMatrixDataRow'],
        controller: MatrixSelectionController,
        link : function(scope, element, attrs, ctrls, transclude){
            var matrixCtrl = ctrls[0];
            var selectionCtrl = ctrls[1];
            var matrixRowCtrl = ctrls[2];
            if(scope.options.rowSelection.enable){
                 //matrixRowCtrl.addToRowClasses('selectCtrl.$backgroundColors[$rowIndex].class')
                 if(!scope.selectCtrl.checkboxInfo.enable || (scope.selectCtrl.checkboxInfo.enable && !scope.selectCtrl.checkboxInfo.disableHighlighting)){
                    matrixRowCtrl.addToClickEvents(function(row,rowIndex){
                        if(!scope.matrixRow.$isEmpty){
                            selectionCtrl.$selectMatrixRow(row, rowIndex);  
                            selectionCtrl.$checkAll = (Object.keys(selectionCtrl.$rowsSelected).length == matrixCtrl.dataContainer.matrixData.length); 
                        }
                    }); 
                 }
                 
                 scope.onCheckboxChange = function(row, rowIndex){
                     if(scope.selectCtrl.checkboxInfo.enable && scope.selectCtrl.checkboxInfo.disableHighlighting){
                        if(!scope.matrixRow.$isEmpty){
                            selectionCtrl.$selectMatrixRow(row, rowIndex);  
                            selectionCtrl.$checkAll = (Object.keys(selectionCtrl.$rowsSelected).length == matrixCtrl.dataContainer.matrixData.length); 
                        }
                     }
                 }
            }
        }
    }
});   
})();

(function(){
/**
 * Sorting Service for matrix
 */
function MatrixSortingService($log){
    var DESCENDING = 'desc', ASCENDING = 'asc';
    this.logger = $log.getInstance('MatrixController');
    this.logger.enableLogging(2);
    /**
     * function to sort the column
     * @param sortInfo
     * @param field
     */
    this.sortColumn = function(sortInfo, field){
        this.logger.debug("Sorting matrix on "+field);
        if(this.isExist(sortInfo, field)){
            this.changeDirection(sortInfo, this.getFieldIndex(sortInfo, field));
        }else{
            if(sortInfo.multiple){
                sortInfo.fields.push(field);
                sortInfo.directions.push(ASCENDING);
                if(!sortInfo.external)
                    sortInfo.sortOrders.push(field);
            }else{
                sortInfo.fields = [field];
                sortInfo.directions = [ASCENDING];
                if(!sortInfo.external)
                    sortInfo.sortOrders = [field];
            }
        }
    };

    /**
     * function to initialize sort orders
     * @param sortInfo
     */
    this.initializeSortOrders = function(sortInfo){
        this.logger.debug("Initializing sort orders for the grid columns");        
        angular.forEach(sortInfo.fields, function(field, index){
            if(sortInfo.sortOrders == undefined)
                sortInfo.sortOrders = [];
            if(sortInfo.directions[index] === DESCENDING)
                sortInfo.sortOrders[index] = '-'+field;
            else
                sortInfo.sortOrders[index] = field;
        });
    }

    /**
     * function to remove sort on a field
     */
    this.removeSort = function(sortInfo, field){
        var index = this.getFieldIndex(sortInfo, field);
        sortInfo.fields.splice(index,1);
        sortInfo.directions.splice(index,1);
        sortInfo.sortOrders.splice(index,1);
    }

    /**
     * function to change the sort direction
     * @param sortInfo
     * @param index
     */
    this.changeDirection = function(sortInfo, index){
        this.logger.debug("Changing sorting order");
        if(sortInfo.directions[index] === ASCENDING){
            sortInfo.directions[index] = DESCENDING;
            if(!sortInfo.external)
                sortInfo.sortOrders[index] = '-'+sortInfo.fields[index];
        }
        else if(sortInfo.directions[index] === DESCENDING){
            sortInfo.fields.splice(index,1);
            sortInfo.directions.splice(index,1);
            sortInfo.sortOrders.splice(index,1);
        }else{
            sortInfo.directions[index] = ASCENDING;
            if(!sortInfo.external)
                sortInfo.sortOrders[index] = sortInfo.fields[index];
        }
    };

    /**
     * Checks if the field exist in the sortInfo fields
     * @param sortInfo
     * @param field
     * @returns {boolean}
     */
    this.isExist = function(sortInfo, field){
        return sortInfo.fields.indexOf(field) != -1;
    };

    /**
     *  returns the field index in sortInfo fields array
     * @param sortInfo
     * @param field
     * @returns {number}
     */
    this.getFieldIndex = function(sortInfo, field){
        return sortInfo.fields.indexOf(field);
    };

    return this;
}
angular.module('wf.framework').service('wfMatrixSortService', ['$log',MatrixSortingService]);
})();
(function(){
function MatrixViewportContainer(element, dataContainer, scrollInfo) {
    if(!element)
        throw Error("ViewportContainer gets created based on an element. element should be passed as constructor args .")
    this.AVG_HEIGHT=36 //this is with respect to css
    this.maxRows = 0;
    this.currentStartIndex = NaN;
    this.maxIndex = 0;
    this.scrollMax = 0;
    this.rowThreshold = 0;
    this.container = element;
    this.dataContainer = dataContainer;
    this.rowCacheThreshold = 4;
    this.currentRangeStart = 0;
    this.currentRangeEnd = 0;
    this.currentScrollLeft = 0;
    this.currentScrollTop = 0;
    this.definedScrollHeight = this.currentMaxScrollHeight = (scrollInfo && scrollInfo.height) ? scrollInfo.height : 400;
}
//cleans up the element references on destroy
MatrixViewportContainer.prototype.onDestroy = function onContainerDestroy() {
    this.container = undefined;
    this.dataConatiner = null;
}
//re-calculates/initializes the viewport container values
MatrixViewportContainer.prototype.reinitializeContainerValues = function calculateContainerValues(){
    this.scrollMax = Math.floor(this.dataContainer.pageData.length*this.AVG_HEIGHT);
    this.setMaxHeight(this.currentMaxScrollHeight);
    this.setDataContainerHeight(this.scrollMax);
    this.rowThreshold = Math.ceil(this.currentMaxScrollHeight/this.AVG_HEIGHT);
    this.setMaxRows(this.rowThreshold);
    this.currentRangeStart = 0;
    this.currentRangeEnd = 0;
    this.maxIndex = this.dataContainer.pageData.length-this.rowThreshold;
    this.currentStartIndex = NaN;
    return this.virtualScrollHandler();
}
MatrixViewportContainer.prototype.getMaxRows = function getMatrixContainerMaxRows() {
    return this.maxRows;
}
MatrixViewportContainer.prototype.setMaxRows = function setMatrixContainerMaxRows(maxRows) {
    this.maxRows = maxRows
};
/*returns the viewport conatiner current height*/
MatrixViewportContainer.prototype.getCurrentHeight = function getContainerCurrentHeight() {
    return this.container.outerHeight()
};
/*returns the viewport conatiner maximum height defined*/
MatrixViewportContainer.prototype.getMaxHeight = function getContainerMaxHeight() {
    return this.container.css('max-height')
};
/*sets the viewport container maximum height*/
MatrixViewportContainer.prototype.setMaxHeight = function setContainerMaxHeight(height) {
    this.currentMaxScrollHeight = height;
    this.container.css('max-height', height)
};
/*sets the data container inside the viewport minimum height*/
MatrixViewportContainer.prototype.setDataContainerHeight = function setDataCotainerMinHeight(scrollMax) {
    this.container.find('.wf-matrix-data-container').css('min-height', scrollMax);
};
MatrixViewportContainer.prototype.getDataContainerHeight = function getDataCotainerMinHeight() {
    return this.container.find('.wf-matrix-data-container').outerHeight();
};
/*Calculates the scroll position for the given index*/
MatrixViewportContainer.prototype.calcScrollPos = function (index) {
    var pos = 0;
    if (index > 0) {
        if (index > this.maxIndex) { pos = this.scrollMax }
        else { pos = index * Math.floor(this.scrollMax / this.dataContainer.pageData.length); }
    }
    return this.validatePos(pos, this.scrollMax, index);
};
/*Validates the scroll position*/
MatrixViewportContainer.prototype.validatePos = function (pos, index) {
    if (angular.isUndefined(index) || angular.isUndefined(this.maxIndex)) {
        return pos <= 0 ? 0 : pos >= this.scrollMax ? this.scrollMax : pos;
    }
    return pos <= 0 && index > 0 ? 0 : pos >= this.scrollMax && index < this.maxIndex ? this.scrollMax - 1 : pos;
}
/*Method to handle the virtual scroll event*/
MatrixViewportContainer.prototype.virtualScrollHandler = function(event) {
    var scrollPos = this.currentScrollTop = this.container[0].scrollTop;
    var startIndex = (startIndex = Math.floor(scrollPos/this.AVG_HEIGHT)) > this.maxIndex ? this.maxIndex:startIndex;
    return this.scroll(startIndex);
}

MatrixViewportContainer.prototype.renderContainer = function(){
    return this.reinitializeContainerValues();
}

MatrixViewportContainer.prototype.scrollToRow = function(startIndex){
    var startPos = this.calcScrollPos(startIndex,this.maxIndex,this.scrollMax);
    this.container[0].scrollTop = startPos;
}

/*Scrolls the container to th especified index*/
MatrixViewportContainer.prototype.scroll = function(startIndex){
    var isMoreDataLoaded = false;
    var upperThresholdMet = (this.currentRangeStart >= startIndex);
    var lowerThresholdMet = (this.currentRangeEnd <= (this.rowThreshold + startIndex));
    if((upperThresholdMet || lowerThresholdMet) && (isNaN(this.currentStartIndex)||this.currentStartIndex!=startIndex) ){
        /*console.log('------ CALC BEFORE START --------');
        console.log('START_INDEX - '+startIndex);
        console.log('RANGE_START - '+this.currentRangeStart+' - CURRENT_INDEX - '+this.currentStartIndex+' - RANGE_END - '+this.currentRangeEnd+' - MAX_INDEX - '+this.maxIndex);
        console.log('------ CALC END --------');
        console.log('');*/
        var rangeStart = this.currentRangeStart = Math.max(0, startIndex - this.rowCacheThreshold);
        var rangeEnd = this.currentRangeEnd = Math.min(this.dataContainer.pageData.length, this.rowCacheThreshold + this.rowThreshold + startIndex);
        this.dataContainer.virtualData = this.dataContainer.pageData.slice(rangeStart,rangeEnd);
        this.currentStartIndex = startIndex;
        var startPos = this.calcScrollPos(rangeStart,this.maxIndex,this.scrollMax);
        this.container.find('.matrix-table').css('top',startPos);
        /*console.log('------ CALC AFTER START --------');
        console.log('START_INDEX - '+startIndex);
        console.log('RANGE_START - '+this.currentRangeStart+' - CURRENT_INDEX - '+this.currentStartIndex+' - RANGE_END - '+this.currentRangeEnd+' - MAX_INDEX - '+this.maxIndex);
        console.log('------ CALC END --------');
        console.log('');*/
        isMoreDataLoaded = true;
    }
    return isMoreDataLoaded;
}
/*Mehtod to scroll the headers on container scroll*/
MatrixViewportContainer.prototype.scrollHorizontally = function(event){
    var newScrollLeft = this.container[0].scrollLeft;
    if(newScrollLeft != this.currentScrollLeft){
        this.container.parent().find('.matrix-header-viewport')[0].scrollLeft = newScrollLeft;
        this.currentScrollLeft = this.container[0].scrollLeft;
    }
}
/*Viewportfactory to return the instances of container*/
function MatrixViewportFactory(){
    return {
        getContainer : function(element, matrix, scrollInfo){
            return new MatrixViewportContainer(element, matrix, scrollInfo);
        },        
        getAutoHeightContainer : function(element, matrix, scrollInfo, pagingInfo){
            return new MatrixAutoViewportContainer(element, matrix, scrollInfo, pagingInfo);
        }
    }
}
angular.module('wf.framework').factory('MatrixViewportFactory', MatrixViewportFactory);
})();
/**
 * wfModal directive
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
    .directive('wfModal', ['$window', '$compile', 'wfModalService', function($window, $compile, wfModalService) {
	return {
		restrict : 'E',
		replace : true,
		transclude : true,
		scope : {
			show : '=',
			headerTitle : '@',
			modalStyle: '@',
			onClose : '&',
			hideFooter : '@',
			modalAlert : '@',
			securityNamespace : "@"
		},
		compile : function($scope, $element, $transclude) {
                return {
				pre : function($scope, $element, $attrs) {

				 $scope.isAlert = $attrs.modalAlert;
					$scope.hideClose = $attrs.hideCloseButton;
					if($scope.show !== true){
						$scope.show = false;
					}

                    var element = $element.find('.wf-modal-header .close');
                    element.bind('click', function() {
                        $scope.show = false;
                        $scope.onClose();
                        $scope.$apply();
					});

					var height = $('body').height();
					height = height - (height * (7/100));
					height = Math.round(height)-300;

					var modalBody = $element.find('.wf-modal-body');
                        modalBody.css('max-height',height+'px');

                        $element.find('.wf-modal-options').draggable({handle: ".wf-modal-header"}).on('$destroy',function(){
                            $(this).unbind();
                            $(this).empty();
                            $(this).remove();
                        });

					$transclude($scope.$parent, function(node){
					  var nodeEle = angular.element('<div></div>');
					  nodeEle.append(node);
					  var modalfoot = nodeEle.find('wf-modal-footer');
					  $element.find('#content').append(node);
					  node.remove('wf-modal-footer');
					  $element.find('.wf-modal-footer').append(modalfoot);
					});
				},

                post: function ($scope, $element, $attrs) {
                    $scope.$watch('show', function(newVal, oldVal) {
                        if (newVal) {
                            wfModalService.beginModalBehavior($element[0]);
                            $scope.$on('$destroy', function() {
                                wfModalService.endModalBehavior();
                            });
                        }
                        if (typeof(newVal) !== 'undefined' && ! newVal) {
                            wfModalService.endModalBehavior();
                        }
                    });
                }
			};
		},
        templateUrl: 'template/wfModal.html'
	};
    }])
    .run(["$templateCache", function($templateCache) {
        $templateCache.put("template/wfModal.html",
            '<div ng-show="show" title="">' +
                '<div class="wf-modal-glass"  ng-class="(isAlert) && \'wf-modal-alert\' || \'\'" ></div>' +
                '<div class="wf-modal-options"  ng-class="(isAlert) && \'wf-modal-alert\' || \'\'"  align="center">' +
                    '<div class="wf-modal-layer" ng-class="(isAlert) && \'wf-modal-alert\' || \'\'" ng-attr-style="{{modalStyle}}">' +
                        '<div class="wf-modal" >' +
                            '<div class="wf-modal-header">' +
                                '<span class="title">{{headerTitle}}</span>' +
                                '<span class="close" style="font-size:20px" ng-hide="hideClose">&times;</span>' +
                                '<div style="clear: both;" />' +
                            '</div>' +
                            '<div class="wf-modal-body-header"></div>' +
                            '<div class="wf-modal-body" ng-class="(isAlert) && \'wf-modal-alert\' || \'\'" align="left">' +
                                '<div id="content"></div>' +
                            '</div>' +
                            '<div class="wf-modal-body-footer" ></div>' +
                            '<div class="wf-modal-footer" ng-hide="hideFooter" align="right">' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                    '<div style="clear: both;" />' +
                '</div>' +
            '</div>');
    }])
;


//Html Elements
angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
.directive('wfMultiSelect', function() {
    return {
        restrict: 'E',
        scope: {
            tempsrc: '=src',
            dest: '=',
            maxLength : '@',
            selectItemsCallback: '&',
            deselectItemsCallback: '&',
            width :'@',
            orderDest : '@',
            disableWidgets : '=',
            srcLabel: '=',
            destLabel: '=',
			sync : '@'
        },
        link: function(scope, elem) {

            // Disable the select boxes and deselect all the items so the gray text on the gray background
            // doesn't make it look like the selected items disappear.
            scope.disableAll = function() {
                if (scope.disableWidgets) {
                    var i;
                    var sel = elem.find('select')[0];
                    for(i=0;i<sel.options.length;i++) {
                        sel.options[i].selected=false;
                    }
                    var sel = elem.find('select')[1];
                    for(i=0;i<sel.options.length;i++) {
                        sel.options[i].selected=false;
                    }
                }
                return scope.disableWidgets;
            }
        },
        controller: ['$scope', function($scope) {
            $scope.selectedItemsTemp = [];
            $scope.deSelectedItemsTemp = [];

            // Do not order the dest list if order-dest=false CREG-13882
            if ($scope.orderDest === undefined || $scope.orderDest === "true") {
                $scope.destordered = " | orderBy:'name'";
            }

            function updateRecords(){
            		angular.forEach($scope.dest, function(tempvalue){
                        angular.forEach($scope.src, function(srcvalue, i){
                        if(srcvalue.value == tempvalue.value) {
                               $scope.src.splice(i, 1);
                            }

                        });
                    });
            }

            function updateLists(selectedList, src, dest){
            	angular.forEach(selectedList, function(tempvalue){
                    angular.forEach(src, function(srcvalue, i){
                        if(srcvalue.value == tempvalue.value) {
                        	dest.push(tempvalue);
                        	src.splice(i, 1);
            	}
            });
                });
            }

            $scope.$watch('tempsrc',function(newVal){
            	if(newVal){
                    if(!$scope.src){
                        $scope.src = [];
                    }
                    if(!($scope.sync == 'true' || $scope.sync == true)){
                        angular.copy($scope.tempsrc, $scope.src);
                    }else{
                        $scope.src = $scope.tempsrc;
                    }
            		updateRecords();
                }
            }, true);

            $scope.$watch('dest',function(newVal){
            	if(newVal){
            		updateRecords();
            	}
            }, true);

            $scope.selectItems = function(){
            	if($scope.maxLength){
            		$scope.selectedItemsTemp = $scope.selectedItemsTemp.splice(0,$scope.maxLength);
            	}
            	updateLists($scope.selectedItemsTemp,$scope.src, $scope.dest);
                $scope.selectedItemsTemp = [];
                if (angular.isFunction($scope.selectItemsCallback)) {
                    $scope.selectItemsCallback();
                }
            };

            $scope.deSelectItems = function(){
            	updateLists($scope.deSelectedItemsTemp,$scope.dest, $scope.src);
                $scope.deSelectedItemsTemp = [];
                if (angular.isFunction($scope.deselectItemsCallback)) {
                    $scope.deselectItemsCallback();
                }
            } ;
        }],
        replace: true,
        template:
            '<table> ' +
                '<tr> ' +
                    '<td> ' +
                        '<div ng-show="srcLabel || destLabel" style="white-space: nowrap;"><label>{{srcLabel}}</label></div> ' +
                        '<select class="multi-select" style="{{\'width:\'+(width||\'250px\')}}; overflow:auto;" multiple size="8" style="min-width: 100%" id="multiSelectSourceList" ng-model="selectedItemsTemp" ng-options="c.name for c in src | orderBy:\'name\'" ng-disabled="disableAll()"></select> ' +
                    '</td> ' +
                    '<td> ' +
                        '<button class="btn btn-primary" style="width: auto" ng-click="selectItems()" id="multiSelectAddButton"  ng-disabled="selectedItemsTemp.length == 0 || (selectedItemsTemp.length + dest.length ) > maxLength || dest.length >= maxLength || src.length == 0 || disableWidgets">&gt;&gt;</button><br/> ' +
                        '<button class="btn btn-primary" style="width: auto" ng-click="deSelectItems()" id="multiSelectRemoveButton" ng-disabled="deSelectedItemsTemp.length == 0 || dest.length == 0 || disableWidgets">&lt;&lt;</button> ' +
                    '</td> ' +
                    '<td> ' +
                        '<div ng-show="destLabel || srcLabel" style="white-space: nowrap;"><label>{{destLabel}}</label></div> ' +
                        '<select class="multi-select" style="{{\'width:\'+(width||\'250px\')}}; overflow:auto;" multiple size="8" style="min-width: 100%" id="multiSelectDestinationList"  ng-model="deSelectedItemsTemp" ng-options="{{\'c.name for c in dest\'+destordered}}" ng-disabled="disableAll()"></select> ' +
                    '</td> ' +
                '</tr> ' +
            '</table>'

    };
});

/**
 * This directive is to create a auto-resizable textarea.
 * The height of the text area will auto-resize depending on the content. 
*/
angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
    .directive("wfResize", ['$timeout', function ($timeout) {
        return {
			link: function(scope, element, attrs) {
				element.css('overflow-y', 'hidden');
				
				//Resize the textarea on load
                $timeout(function(){
                    element.css('height', 'auto' );
                    element.height( element.prop('scrollHeight') );
                }, 0);
	  
				element.bind('input', function() {
					element.css('height', 'auto' );
					element.height( this.scrollHeight ); 
				});
			}
		}
    }]);
/**
 * Directive to make the Right-Rail float on the screen along with the scroll
 */
angular.module('wf.framework').directive('wfRightRail',[function(){
    return {
        restrict: 'A',
        link : function(scope, element, attrs){
           var resetLayout = function(){
                element.css({'position':'', 'top':'', 'left':''});
                $('#footer').css({'position':'', 'top':'', 'left':''});
           };
           
           var setRightRailCss = function(element, css){
        	   var footerPos = $('#footer').position();
        	   if(element.position().top+$('#right-rail').outerHeight() < footerPos.top){
        		   element.css(css);
        	   }        	   
           }

           var floatRightRail = function(){
                var alignTop = attrs.alignTop ? parseInt(attrs.alignTop):0;
                var delay = attrs.delay ? parseInt(attrs.delay):0;
                var elementHeight = element.find('#right-rail').outerHeight();
                var bodyHeight = $('body').outerHeight();
                var footerPos = $('#footer').position();
                var isDealTemplate = $("#deal-template").length > 0;
                var leftPos = 0;
                if(isDealTemplate)//305 is the margin used on right-rail
                	leftPos = $("#deal-template > div.content-left").offset().left + $("#deal-template > div.content-left").outerWidth()+305-this.pageXOffset; 
                if(alignTop+elementHeight > bodyHeight){
                    if(window.pageYOffset > ((elementHeight+alignTop+delay-bodyHeight))){
                        if(window.pageYOffset>delay){
                        	if(isDealTemplate)
                        		setRightRailCss(element,{'position':'fixed', 'top':alignTop-(elementHeight+alignTop-bodyHeight), 'left' : leftPos})
                        	else
                        		setRightRailCss(element,{'position':'fixed', 'top':alignTop-(elementHeight+alignTop-bodyHeight)})
                        }
                    }else{
                        resetLayout();
                    }
                }else if(scope.changeClass && (window.pageYOffset>delay)){
                	if(isDealTemplate)
                		setRightRailCss(element,{'position':'fixed', 'top':alignTop+1, 'left' : leftPos});
                	else
                		setRightRailCss(element,{'position':'fixed', 'top':alignTop+1});
                }else{
                    resetLayout();
                }
           }

           $(window).bind('scroll', floatRightRail);
           $(window).resize(floatRightRail);

            //unbind the events on destroy
           scope.$on('$destroy',function(){
               $(window).unbind('scroll', floatRightRail);
               $(window).unbind('resize', floatRightRail);
           })
        }
    };
}]);



angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
.directive(	"wfSelect",	['$compile', function($compile) {
	
var mapSelect = '<select style="width:auto;max-width:200px;{{selectStyle}}" class="gwt-ListBox" ng-disabled="disableExpr" ng-model="assignTo" ng-options="key as value for (key, value) in listOptions" id="{{::selectId}}" ><option value="">--SELECT--</option></select>';
	
	var arraySelect = '<select style="width:auto;max-width:200px;{{selectStyle}}" class="gwt-ListBox" ng-disabled="disableExpr" ng-model="assignTo" ng-options="opt.value as opt.name for opt in listOptions" id="{{::selectId}}"><option value="">--SELECT--</option></select>';
	
	return {
		restrict : 'E',
		
		scope : {
			assignTo : '=',
			onChange : '&',
			listOptions : '=',
			disableExpr : '=',
			init : '&',
			selectId:'@'
		},
		
		template : '<div></div>',
		
		replace : true,
		
		compile : function($scope, $element) {
			return {

				pre : function($scope, $element, $attrs) {
					
					$scope.selectStyle=$attrs.style;
					
					var select = undefined;

					var datatype = $attrs.datatype;

					var process = function() {

						$element.text('');

						if (datatype === 'map')
							select = angular.element(mapSelect);
						else
							select = angular.element(arraySelect);

						$element.append($compile(select)($scope));
					};

					process();

					select.bind('focus', function() {
						if (!$scope.initialized) {
							$scope.init();
							$scope.initialized = true;
							$scope.$apply();
						}
					});

					$scope.$watch('listOptions', function(new1, old) {
						if (new1) {
							if (!angular.isArray(new1)) {
								if (datatype != 'map') {
									datatype = 'map';
									process();																	
								}
							} else if (angular.isArray(new1)) {
								if (datatype === 'map') {
									datatype = 'array';
									process();
								}
							}
						}
					});
					
					$scope.$watch('assignTo', function(newValue, oldValue) {
						 if (newValue != oldValue) 
						 $scope.onChange();
				    });
				}

			};
		}
	};
}]);

/**
 * wfTab directives
 *
 * Created by U062274 on 11/19/13.
 */


angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
//The following directives are used for tabs. This is modeled around the
//bootstrap tab directive with core styles
    .controller('WfTabsetController', ['$scope', '$element',
        function TabsetCtrl($scope, $element) {

            var ctrl = this,
                tabs = ctrl.tabs = $scope.tabs = [];

            ctrl.select = function(tab) {
                angular.forEach(tabs, function(tab) {
                    tab.active = false;
                });
                tab.active = true;
            };

            ctrl.addTab = function addTab(tab) {
                tabs.push(tab);
                if (tabs.length === 1 || tab.active) {
                    ctrl.select(tab);
                }
            };

            ctrl.removeTab = function removeTab(tab) {
                var index = tabs.indexOf(tab);
                //Select a new tab if the tab to be removed is selected
                if (tab.active && tabs.length > 1) {
                    //If this is the last tab, select the previous tab. else, the next tab.
                    var newActiveIndex = index == tabs.length - 1 ? index - 1 : index + 1;
                    ctrl.select(tabs[newActiveIndex]);
                }
                tabs.splice(index, 1);
            };
        }
    ]).directive('wfTabset', function() {
        return {
            restrict: 'EA',
            transclude: true,
            replace: true,
            require: '^wfTabset',
            scope: {},
            controller: 'WfTabsetController',
            compile: function(elm, attrs, transclude) {
	            return{ 
	                pre :function(scope, element, attrs, tabsetCtrl) {
	                    scope.vertical = angular.isDefined(attrs.vertical) ? scope.$eval(attrs.vertical) : false;
	                    scope.type = angular.isDefined(attrs.type) ? scope.$parent.$eval(attrs.type) : 'tabs';
	                    scope.direction = angular.isDefined(attrs.direction) ? scope.$parent.$eval(attrs.direction) : 'top';
	                    scope.tabsAbove = (scope.direction != 'below');
	                    tabsetCtrl.$scope = scope;
	                    tabsetCtrl.$transcludeFn = transclude;
                	}
                };
            },
            templateUrl: 'template/wfTabset.html'

        };
    }).directive('wfTab', ['$parse', '$http', '$templateCache', '$compile',
        function($parse, $http, $templateCache, $compile) {
            return {
                require: '^wfTabset',
                restrict: 'EA',
                replace: true,
                transclude: true,
                scope: {
                    heading: '@',
                    onSelect: '&select', //This callback is called in contentHeadingTransclude
                    //once it inserts the tab's content into the dom
                    onDeselect: '&deselect'
                },
                controller: function() {
                    //Empty controller so other directives can require being 'under' a tab
                },
                compile: function(elm, attrs, transclude) {
                    return function postLink(scope, elm, attrs, tabsetCtrl) {
                        var getActive, setActive;
                        if (attrs.active) {
                            getActive = $parse(attrs.active);
                            setActive = getActive.assign;
                            scope.$parent.$watch(getActive, function updateActive(value) {
                                scope.active = !! value;
                            });
                            scope.active = getActive(scope.$parent);
                        } else {
                            setActive = getActive = angular.noop;
                        }

                        scope.$watch('active', function(active) {
                            setActive(scope.$parent, active);
                            if (active) {
                                tabsetCtrl.select(scope);
                                scope.onSelect();
                            } else {
                                scope.onDeselect();
                            }
                        });

                        scope.disabled = false;
                        if (attrs.disabled) {
                            scope.$parent.$watch($parse(attrs.disabled), function(value) {
                                scope.disabled = !! value;
                            });
                        }

                        scope.select = function() {
                            if (!scope.disabled) {
                                scope.active = true;
                            }
                        };

                        tabsetCtrl.addTab(scope);
                        scope.$on('$destroy', function() {
                            tabsetCtrl.removeTab(scope);
                        });
                        if (scope.active) {
                            setActive(scope.$parent, true);
                        }


                        //We need to transclude later, once the content container is ready.
                        //when this link happens, we're inside a tab heading.
                        scope.$transcludeFn = transclude;
                    };
                },
                templateUrl: 'template/wfTab.html'
            };
        }
    ])

    .directive('wfTabHeadingTransclude', [
        function() {
            return {
                restrict: 'A',
                require: '^wfTab',
                link: function(scope, elm, attrs, tabCtrl) {
                    scope.$watch('headingElement', function updateHeadingElement(heading) {
                        if (heading) {
                            elm.html('');
                            elm.append(heading);
                        }
                    });
                }
            };
        }
    ])

    .directive('wfTabContentTransclude', ['$compile', '$parse',
        function($compile, $parse) {
            return {
                restrict: 'A',
                require: '^wfTabset',
                link: function(scope, elm, attrs) {
                    var tab = scope.$eval(attrs.wfTabContentTransclude);

                    //Now our tab is ready to be transcluded: both the tab heading area
                    //and the tab content area are loaded.  Transclude 'em both.
                    tab.$transcludeFn(tab.$parent, function(contents) {
                        angular.forEach(contents, function(node) {
                            if (isTabHeading(node)) {
                                //Let tabHeadingTransclude know.
                                tab.headingElement = node;
                            } else {
                                elm.append(node);
                            }
                        });
                    });
                }
            };

            function isTabHeading(node) {
                return node.tagName && (
                    node.hasAttribute('tab-heading') ||
                        node.hasAttribute('data-tab-heading') ||
                        node.tagName.toLowerCase() === 'tab-heading' ||
                        node.tagName.toLowerCase() === 'data-tab-heading'
                    );
            }
        }
    ])

    .directive('wfTabsetTitles', ['$http', function($http) {
        return {
            restrict: 'A',
            require: '^wfTabset',
            templateUrl: 'template/wfTabsetTitles.html',
            replace: true,
            link: function(scope, elm, attrs, tabsetCtrl) {
                if (!scope.$eval(attrs.wfTabsetTitles)) {
                    elm.remove();
                } else {
                    //now that tabs location has been decided, transclude the tab titles in
                    tabsetCtrl.$transcludeFn(tabsetCtrl.$scope.$parent, function(node) {
                        elm.append(node);
                    });
                }
            }
        };
    }])
    .run(["$templateCache", function($templateCache) {
        $templateCache.put("template/wfTabset.html",
            '<div class="core-tabs" ng-class="{\'tabs-right\': direction == \'right\', \'tabs-left\': direction == \'left\', \'tabs-below\': direction == \'below\'}">' +
              '<div class="wf-nav-titles" wf-tabset-titles="tabsAbove"></div>' +
              '<div class="wf-tab-content tab-content" style="clear: both; min-width: 300px;">' +
                '<div class="tab-pane" ' +
                     'ng-repeat="tab in tabs" ' +
                     'ng-class="{active: tab.active}"' +
                     'wf-tab-content-transclude="tab">' +
                '</div>' +
              '</div>' +
              '<div class="wf-nav-titles" wf-tabset-titles="!tabsAbove"></div>' +
            '</div>');


        $templateCache.put("template/wfTab.html",
            '<li class="wf-tab-heading" ng-class="{active: active, disabled: disabled}" ng-click="select()">' +
              '<a wf-tab-heading-transclude>{{heading}}</a>' +
            '</li>');

        $templateCache.put("template/wfTabsetTitles.html",
            '<ul class="nav {{type && \'nav-\' + type}}" ng-class="{\'nav-stacked\': vertical}"></url>');

    }])
;

angular.module('wf.framework') // By not including the dependencies this will not replace the existing core.directives
    .directive("wfToolTip", ['$window', function ($window) {
        return function(scope, element, attrs) {

            element.bind('mouseover',function(){
                element.find('.sub-nav').css('top',element.position().top+element.height()+'px');
            });

            scope.$on('$destroy', function(){
               element.unbind('mouseover');
            });
        };
    }]);

(function(document, angular, window){

    function FileUpload(file){
        this.name = file.name;
        this.size = file.size;
        this.type = file.type;
    }

    function digestScope(scope, isApply){
        if(!scope.$$phase && !scope.$root.$$phase){
            if(isApply)
                scope.$apply();
            else
                scope.$digest();
        }
    }

    /* Thumbnail code
     var f = files[0];
     var reader = new FileReader();

     reader.onload = (function(theFile) {
     return function(e) {
     document.getElementById('list').innerHTML = ['<img src="', e.target.result,'" title="', theFile.name, '" width="50" />'].join('');
     };
     })(f);

     reader.readAsDataURL(f);
     */

    /**
     * WFFileUploaderService handles the configuration , validation and uploading  files to given URL
     */
    angular.module('wf.framework').constant("UPLOAD_STATUS", {
        'IN_PROGRESS': "In Progress", 'CANCELLED' : 'Cancelled', 'INVALID' : 'Invalid', 'FAILED' : 'Failed', 'COMPLETED' : 'Completed'
    })
        .service('wfFileUploaderService', ['$http', '$q', function($http, $q){
            var _this = this;

            this.MAX_PARALLEL = 3;
            this.CURRENT_PARALLEL = 0;
            this.asyncQueue = [];

            var defaultOptions = {
                maxFileSize : 50/*in MB*/,
                minFileSize : 1/**in KB**/,
                maxCombinedFileSize : 50/*in MB*/,
                allowedFileTypes : {
                    'application/pdf' : {allowed : true, iconClass : 'fa-file-pdf-o' },
                    'image/jpeg': {allowed : true, iconClass : 'fa-file-image-o' },
                    'image/tiff': {allowed : true, iconClass : 'fa-file-image-o' },
                    'image/gif' : {allowed : true, iconClass : 'fa-file-image-o' },
                    'image/png' : {allowed : true, iconClass : 'fa-file-image-o' },
                    'image/bmp' : {allowed : true, iconClass : 'fa-file-image-o' }
                },
                uploadParameters: {},
                messages: {
                    fileMinSizeError: "This document doesn't meet our minimum file size of 1 kilobyte.  Please increase the size of the document, and try again.",
                    fileDirError: "Directory Upload is not allowed.",
                    fileMaxSizeError: " The individual file exceeds the file size limit of 50 megabytes.  Please reduce the size of the document, and try again",
                    fileFormatError: "We are unable to accept this file type.  Please resave your document as an accepted file type (e.g. *.pdf, *.jpeg, *.gif, *.png, *.tif, *.bmp), and try again",
                    maxCombinedSizeError: "The document files exceed the total file size limit of 50 megabytes per upload.  Please reduce the size of the documents, and try again",
                    deleteError: "An error has occurred while deleting the file",
                    confirmDelete: "Please confirm you want to delete the selected file.",
                    unspecifiedUrlError: "URL to upload files is not specified.Upload tool will not work.",
                    uploadErrorMessage: "An error has occurred while uploading the file",
                    invalidUploadMessage: "Invalid Upload",
                    uploadCancelled: "Upload Cancelled"
                }
            };

            this.getUploadOptions = function(userOptions){
                if(angular.isObject(userOptions)){
                    var messages = undefined;
                    if(userOptions.messages){
                        messages = angular.extend({},defaultOptions.messages, userOptions.messages);
                    }
                    var uploadOptions = angular.extend({},defaultOptions, userOptions);
                    if(uploadOptions.fileTypes){
                        angular.forEach(uploadOptions.fileTypes, function(fileType){
                            if(angular.isString(fileType)){
                                if(uploadOptions.allowedFileTypes[fileType])
                                    uploadOptions.allowedFileTypes[fileType].allowed = true;
                                else{
                                    uploadOptions.allowedFileTypes[fileType] = {allowed : true}
                                }
                            }else if(angular.isObject(fileType) && fileType.type){
                                uploadOptions.allowedFileTypes[fileType.type] = fileType;
                            }
                        });
                    }
                    if(messages){
                        uploadOptions.messages = messages;
                    }
                    return uploadOptions;
                }else{
                    return angular.extend({},defaultOptions);
                }
            };

            this.validateAndCreateFileUploads =  function(files, items, uploadOptions){
                var fileUploads = [];
                for(var index = 0; index < files.length ; index++){
                    var file = files[index];
                    var item = items ? items[index] : undefined;
                    var fileUpload = new FileUpload(file);
                    fileUpload.valid = true;

                    if(file.error){
                        fileUpload.valid = false;
                        if(!fileUpload.errorMessage) fileUpload.errorMessage = file.error;
                    }

                    if(file.size < (uploadOptions.minFileSize*1024)){
                        fileUpload.valid = false;
                        if(!fileUpload.errorMessage) fileUpload.errorMessage = uploadOptions.messages.fileMinSizeError;
                    }

                    //file dropped is a directory
                    if(fileUpload.valid && item && item.webkitGetAsEntry && item.webkitGetAsEntry() && item.webkitGetAsEntry().isDirectory){
                        fileUpload.valid = false;
                        if(!fileUpload.errorMessage) fileUpload.errorMessage = uploadOptions.messages.fileDirError;
                    }

                    //file size greater than 25 MB
                    if( fileUpload.valid && file.size > (uploadOptions.maxFileSize*1024*1024)){
                        fileUpload.valid = false;
                        if(!fileUpload.errorMessage) fileUpload.errorMessage = uploadOptions.messages.fileMaxSizeError;
                    }

                    //file extension check
                    if(fileUpload.valid && !(file.type && uploadOptions.allowedFileTypes[file.type] && uploadOptions.allowedFileTypes[file.type].allowed)){
                        fileUpload.valid = false;
                        if(!fileUpload.errorMessage) fileUpload.errorMessage = uploadOptions.messages.fileFormatError
                    }

                    fileUploads.push(fileUpload);
                }
                return fileUploads;
            };

            this.asyncQueueUpload = function(file, fileUpload, uploadConfig, uploadOptions){
                if(_this.CURRENT_PARALLEL < _this.MAX_PARALLEL){
                    _this.uploadFile(file, fileUpload, uploadConfig, uploadOptions);
                }else{
                    _this.asyncQueue.unshift({file : file, fileUpload : fileUpload, uploadConfig : uploadConfig, uploadOptions:uploadOptions})
                }
            };

            this.asyncNextInQueueUpload = function(){
                _this.CURRENT_PARALLEL > 0 ? _this.CURRENT_PARALLEL-- : _this.CURRENT_PARALLEL=0;
                if(_this.asyncQueue.length > 0 && _this.CURRENT_PARALLEL < _this.MAX_PARALLEL ){
                    var fileUploadConfig = _this.asyncQueue.pop();
                    _this.uploadFile(fileUploadConfig.file, fileUploadConfig.fileUpload, fileUploadConfig.uploadConfig, fileUploadConfig.uploadOptions);
                }
            };

            this.uploadFile = function(file, fileUpload, uploadConfig, uploadOptions){
                var formData = new FormData();
                formData.append('file', file, file.name);
                for(var key in uploadOptions.uploadParameters){
                    formData.append(key, uploadOptions.uploadParameters[key]);
                }
                if(fileUpload.valid){
                    _this.CURRENT_PARALLEL++;
                    $.ajax({
                        data:formData,
                        type: 'post',
                        url: uploadConfig.url,
                        cache: false,
                        contentType: false,
                        processData: false,
                        dataType: 'json',
                        xhrFields:{withCredentials : true},
                        xhr: function()
                        {
                            var xhr = new window.XMLHttpRequest();
                            //Upload progress
                            xhr.upload.addEventListener("progress",uploadConfig.progress(fileUpload), false);
                            xhr.upload.addEventListener("load",uploadConfig.progress(fileUpload),false);

                            fileUpload.abort = function(){
                                uploadConfig.abort(xhr,fileUpload);
                            }
                            return xhr;
                        },
                        success: function(data){
                            uploadConfig.complete(fileUpload,data);
                            _this.asyncNextInQueueUpload();
                        },
                        error : function(xhr, error){
                            if(xhr && xhr.responseJSON)
                                uploadConfig.error(fileUpload,xhr.responseJSON);
                            else
                                uploadConfig.error(fileUpload);
                            _this.asyncNextInQueueUpload();
                        }
                    });
                }else{
                    uploadConfig.invalid(fileUpload);
                }
            };

            this.uploadFiles = function(uploadConfig, files, items, uploadOptions){
                var fileUploads = _this.validateAndCreateFileUploads(files, items, uploadOptions);
                for( var index = 0 ; index < fileUploads.length ; index++){
                    var file = files[index];
                    var fileUpload = fileUploads[index];
                    _this.asyncQueueUpload(file, fileUpload, uploadConfig,uploadOptions);
                }
                return fileUploads;
            };

        }])
        .directive('wfUpload', ['wfFileUploaderService','UPLOAD_STATUS', '$dialog', function(wfFileUploaderService, uploadStatus, $dialog){
            return {
                restrict : 'E',
                require : ['wfUpload', '?^form'],
                scope : {
                    fileUploads : '=',
                    userOptions : '=',
                    onUploadComplete : '&',
                    onUploadError : '&',
                    onDelete : '&'
                },
                template : '<div>' +
                    '   <div id="file-uploader">' +
                    '        <span class="drag-text"> Drag files here </span><br/> <span class="select-text">Or, if you prefer... </span><br/>' +
                    '        <button id="file-selector" class="btn btn-default">Browse Files</button> ' +
                    '        <input id="file-selector-input" type="file" style="" multiple="multiple"/> ' +
                    '   </div>' +
                    '   <div id="file-upload-status">' +
                    '        <div ng-repeat="fs in fileUploads">' +
                    '               <div class="fa fa-3x" ng-class="getFileIconClass(fs.type)"> </div> <a class="file-name" ng-click="previewFile($index)" href="">{{fs.name}}</a>' +
                    '               <div class="upload-bar">' +
                    '                  <div class="upload-bar-progress" ng-class="{\'invalid\' : (fs.status == \'Invalid\' || fs.status == \'Cancelled\')}" ng-style="uploadStatusStyle(fs)"></div>' +
                    '               </div> ' +
                    '               <label class="upload-percent">{{fs.percentComplete ? fs.percentComplete : \'0\'}}%</label>' +
                    '               <i class="icon-stop" style="color: red;" ng-if="fs.status == \'In Progress\'" title="Abort" ng-click="fs.abort();"></i>' +
                    '               <i class="icon-remove" ng-if="fs.status != \'In Progress\'" title="Remove"  ng-click="removeFile($index);"></i>' +
                    '               <div class="error-message"> {{fs.errorMessage}}</div>' +
                    '       </div>' +
                    '   </div>' +
                    '</div>',
                controller : ['$scope', '$http', function($scope, $http){
                    var files = undefined;
                    var combinedFileSize = 0;
                    this.addFiles = function(filesArray){
                        var maxCombinedFileSize = $scope.uploadOptions.maxCombinedFileSize*1024*1024;
                        if(files == undefined)
                            files = [];
                        for( var index = 0 ; index < filesArray.length ; index++){
                            if(combinedFileSize + filesArray[index].size > maxCombinedFileSize){
                                if(filesArray[index].size > maxCombinedFileSize){
                                    filesArray[index].error = "The individual file "+filesArray[index].name+" exceeds the total file size limit of "+$scope.uploadOptions.maxCombinedFileSize+" megabytes.  Please reduce the size of the document, and try again";
                                }else{
                                    filesArray[index].error =  $scope.uploadOptions.messages.maxCombinedSizeError;
                                }
                            }else{
                                combinedFileSize = combinedFileSize + filesArray[index].size;
                            }
                            files.push(filesArray[index]);
                        }
                    }
                    
                    
                    $scope.uploadStatusStyle = function(fileUpload){
                        return {'max-width':fileUpload.percentComplete+'%'};
                    }

                    $scope.fileUploads = [];

                    $scope.getFileIconClass = function(filetype){
                        if($scope.uploadOptions.allowedFileTypes[filetype] && $scope.uploadOptions.allowedFileTypes[filetype].iconClass){
                            return $scope.uploadOptions.allowedFileTypes[filetype].iconClass;
                        }
                        return 'fa-file';
                    }

                    $scope.$watch('fileUploads', function(newVal){
                        if(!newVal)
                            files = undefined;
                        else if(newVal.length == 0)
                            files = [];
                    })

                    $scope.previewFile = function(index){
                        if($scope.fileUploads[index].status && $scope.fileUploads[index].status==uploadStatus.COMPLETED){
                            var previewWindow = window.open(window.webkitURL.createObjectURL(files[index]),"_blank","modal=yes");
                            previewWindow.onload = function(){
                                previewWindow.document.title= "Eupload - "+files[index].name;
                                previewWindow.locationbar.visible=false;
                            }
                        }
                    }
                    var removeFileFromUploads = function(index){
                        $scope.fileUploads.splice(index, 1);
                        if(angular.isArray(files)){
                            if(!files[index].error){
                                combinedFileSize = combinedFileSize - files[index].size;
                            }
                            files.splice(index,1);
                        }
                        if(angular.isFunction($scope.onDelete)){
                            $scope.onDelete();
                        }
                    }
                    var deleteFile = function(fileUpload, index){
                        if($scope.uploadOptions.deleteUrl){
                            if(fileUpload.status == uploadStatus.COMPLETED){
                                $.ajax({
                                    data:JSON.stringify({fileId : fileUpload.response.fileId}),
                                    type: 'post',
                                    url: $scope.uploadOptions.deleteUrl,
                                    contentType: 'application/json;charset=UTF-8',
                                    dataType: 'json',
                                    xhrFields:{withCredentials : true},
                                    success: function(data){
                                        $scope.$apply(function(){
                                            removeFileFromUploads(index);
                                        });
                                    },
                                    error : function(xhr, error){
                                        $scope.$apply(function(){
                                            fileUpload.errorMessage = $scope.uploadOptions.messages.deleteError;
                                        });
                                    }
                                });
                            }else{
                                removeFileFromUploads(index);
                            }
                        }else{
                            removeFileFromUploads(index);
                        }
                    }

                    $scope.removeFile = function(index){
                        $dialog.messageBox('Delete Confirmation', $scope.uploadOptions.messages.confirmDelete, [{
                            result: 'delete',
                            label: 'Delete'
                        }, {
                            result: 'cancel',
                            label: 'Cancel'
                        }], function(result) {
                                if(result === 'delete'){
                                    deleteFile($scope.fileUploads[index], index);
                                }
                            }
                        );

                    }
                }],
                link : function preLink(scope, iElement, iAttrs, controllers ) {
                    var uploadCtrl = controllers[0];
                    var formCtrl = controllers[1];
                    var isFormDirty = formCtrl?formCtrl.$dirty:false;
                    //get user-options
                    scope.uploadOptions = wfFileUploaderService.getUploadOptions(scope.userOptions);

                    if(!scope.uploadOptions || !scope.uploadOptions.url){
                        scope.$root.alert(scope.uploadOptions.messages.unspecifiedUrlError)
                    }else{
                        var uploadConfig = {

                            url : scope.uploadOptions.url,

                            select : function(event){
                                if(event.target.files.length > 0){
                                    event.preventDefault();
                                    if(formCtrl && !isFormDirty){
                                        formCtrl.$setDirty();
                                    }
                                    try{
                                        uploadCtrl.addFiles(event.target.files);
                                        scope.fileUploads = scope.fileUploads.concat(wfFileUploaderService.uploadFiles(uploadConfig, event.target.files, undefined, scope.uploadOptions));
                                        digestScope(scope, true);
                                    }catch(error){
                                        $dialog.messageBox('Error', error.message, [{result: 'ok',label: 'OK'}]);
                                    }
                                }
                            },

                            drop : function(event){
                                if(event.dataTransfer.files.length > 0){
                                    event.preventDefault();
                                    if(formCtrl && !isFormDirty){
                                        formCtrl.$setDirty();
                                    }
                                    try{
                                        uploadCtrl.addFiles(event.dataTransfer.files);
                                        scope.fileUploads = scope.fileUploads.concat(wfFileUploaderService.uploadFiles(uploadConfig, event.dataTransfer.files, event.dataTransfer.items, scope.uploadOptions));
                                        digestScope(scope, true);
                                    }catch(error){
                                        $dialog.messageBox('Error', error.message, [{result: 'ok',label: 'OK'}]);
                                    }
                                }
                            },

                            progress : function(fileUpload){
                                return function(evt){
                                    if (evt.lengthComputable) {
                                        fileUpload.percentComplete = Math.floor((evt.loaded/evt.total)*100);
                                        fileUpload.status = uploadStatus.IN_PROGRESS;
                                        digestScope(scope);
                                    }
                                }
                            },

                            abort : function(xhr, fileUpload){
                                xhr.abort();
                                fileUpload.status = uploadStatus.CANCELLED;
                                fileUpload.abort = angular.noop;
                                fileUpload.errorMessage = scope.uploadOptions.messages.uploadCancelled
                                digestScope(scope, true);
                            },

                            complete : function(fileUpload, data){
                                fileUpload.status = uploadStatus.COMPLETED;
                                fileUpload.abort = angular.noop;
                                fileUpload.response = data;
                                if(angular.isFunction(scope.onUploadComplete))
                                    scope.onUploadComplete({fileUpload:fileUpload});
                                digestScope(scope, true);
                            },

                            error : function(fileUpload, response){
                                fileUpload.status = uploadStatus.FAILED;
                                fileUpload.abort = angular.noop;
                                if(response && response.errorMessage)
                                    fileUpload.errorMessage = response.errorMessage;
                                if(!fileUpload.errorMessage) fileUpload.errorMessage = scope.uploadOptions.messages.uploadErrorMessage;
                                if(angular.isFunction(scope.onUploadError))
                                    scope.onUploadError({fileUpload:fileUpload});
                                digestScope(scope, true);
                            },

                            invalid : function(fileUpload){
                                fileUpload.status = uploadStatus.INVALID;
                                fileUpload.abort = angular.noop;
                                if(!fileUpload.errorMessage) fileUpload.errorMessage = scope.uploadOptions.messages.invalidUploadMessage;
                                if(angular.isFunction(scope.onUploadError))
                                    scope.onUploadError({fileUpload:fileUpload});
                                digestScope(scope, true);
                            }
                        };

                        // Adding drag events to file uploader widget
                        var dragListener = function(evt) {
                            evt.preventDefault();
                        }
                        iElement[0].addEventListener("dragover",dragListener , false);
                        iElement[0].addEventListener("dragenter", dragListener, false);
                        iElement[0].addEventListener("drop", uploadConfig.drop , false);

                        //Adding click event to file-selector button
                        var fileSelectorButton = iElement.find('#file-selector');
                        var fileInput = iElement.find('#file-selector-input');

                        fileSelectorButton.bind('click', function(event){
                            fileInput[0].value = null;
                            fileInput[0].click(event);
                        });

                        fileInput.bind('change', uploadConfig.select);

                        scope.$on('$destroy',function(){
                            iElement[0].removeEventListener("dragover", dragListener, false);
                            iElement[0].removeEventListener("dragenter", dragListener, false);
                            iElement[0].removeEventListener("drop", uploadConfig.drop ,false);
                            fileSelectorButton.unbind('click');
                        })
                    }
                }
            }
        }]);
})(document, angular, window);
/**
 * Usage
 * 
 */
(function(){

    VirtualScrollController.$inject = ['$scope'];
    function VirtualElement(elem, container){
        this.conatinerRef =
        this.element = elem;
        this.offset = elem.offset();
        this.height = elem.outerHeight();

        this.recalculateHeight = function(){
            var prevheight = this.height;
            this.height = elem.outerHeight();
            if(this.height != this.prevHeight){

            }
        }
    }

    function VirtualViewportContainer(){

    }

    function VirtualScrollController($scope){
        this.isRendered = false;

        this.containerViewport= {scrollTop:0};

        //cache for variable height rows
        this.rowCache = {};

        //Container height related variables
        this.containerHeight = 0;
        this.elementHeightDefined = 0;
        this.canvasHeight = $(window).height();
        this.canvasTop = 0;

        //container data related variables
        this.virtualList = [];
        this.dataList = [];

        //current view related variables
        this.currentStartIndex = 0;
        //this.currentSpace = 0;
        this.virtualStartIndex = 0;
        this.currentEndIndex = 0;
        this.rangeStartIndex = 0;
        this.rangeEndIndex = 0;

        /**
         * function to load the data into virtual list
         */
        this.loadData = function (){
            this.virtualList = this.dataList;
            this.isRendered = true;
            if(!$scope.$$phase){
                $scope.$digest();
            }
        }

        /**
         * returns the height of an element in the cache,
         * if not defined returns the defined height which will be modified after the rendering of the element
         */
        this.getSizeOf = function(index){
            if(this.rowCache[index]){
                return this.rowCache[index];
            }
            return this.elementHeightDefined;
        }

        /**
         * calculates the buffer space to be rendered
         * @param from
         * @param max
         * @returns {number}
         */
        this.getThreshold = function(from, max){
            var defaultVal = 100;
            var calc = 0;
            if(from == 0 ){
                calc = this.elementHeightDefined >  this.getSizeOf(0) ? this.elementHeightDefined :  this.getSizeOf(0);
            }else{
                calc = this.elementHeightDefined >  this.getSizeOf(from-1) ? this.elementHeightDefined :  this.getSizeOf(from-1);
            }
            console.log("threshold : " + calc)
            return calc > defaultVal ?  calc :  defaultVal;
        }

        /**
         * function to load virtual data on scroll
         */
        this.scrollEventHandler = function(){
            var amountScrolled =  (this.containerViewport.scrollTop - this.containerViewport.prevScrollTop);
            var from = this.virtualStartIndex;
            var threshold = this.getThreshold(from, this.dataList.length-1);
            var start = this.containerViewport.scrollTop - (threshold);
            var end = this.containerViewport.scrollTop + this.canvasHeight + (threshold) ;
            if(amountScrolled > 0 ){
                while (from < (this.dataList.length-1) ) {
                    var itemSize = this.getSizeOf(from);
                    if ((this.canvasTop + itemSize) > start) break;
                    this.canvasTop += itemSize;
                    ++from;
                }
            }else if(amountScrolled < 0 ){
                while (from < (this.dataList.length-1) ) {
                    var itemSize = this.getSizeOf(from);
                    if ((this.canvasTop - itemSize) < start) break;
                    this.canvasTop -= itemSize;
                    --from;
                }
            }else{
                from = 0;
                this.canvasTop = 0;
            }
            if(from<0){
                from = 0;
            }
            if(this.canvasTop < 0 ){
                this.canvasTop = 0;
            }
            var startSpace = this.canvasTop;
            var maxSize = this.dataList.length - from;
            var size = 0;
            while (size < maxSize && startSpace < end) {
                var itemSize = this.getSizeOf(from + size);
                startSpace += itemSize;
                ++size;
            }
            var to = from + size;
            if(this.virtualStartIndex != from || this.virtualEndIndex != to || !this.isRendered){
                this.virtualStartIndex = from;
                this.virtualEndIndex = to;
                this.virtualList = this.dataList.slice(from, from+size);
                $scope.updateCanvasTop(this.canvasTop);
                this.isRendered = true;
                if(!$scope.$$phase){
                    $scope.$digest();
                }
            }
        }

        /**
         * function to load virtual data on scroll
         */
        this.scroll = function (){
            var scrollPos = this.containerViewport.scrollTop;
            var space = 0;
            var from  = 0;
            var size = 0;

            var start = this.containerViewport.scrollTop - (this.elementHeightDefined );
            var end = this.containerViewport.scrollTop + this.canvasHeight + ( this.elementHeightDefined * 2) ;

            while (from < (this.dataList.length-1) ) {
                var itemSize = this.getSizeOf(from);
                if (space + itemSize > start) break;
                space += itemSize;
                ++from;
            }
            var startSpace = space;
            var maxSize = this.dataList.length - from;

            while (size < maxSize && space < end) {
                var itemSize = this.getSizeOf(from + size);
                /*if (itemSize == null) {
                 size = Math.min(size + Math.ceil(this.canvasHeight/this.elementHeightDefined), maxSize);
                 break;
                 }*/
                space += itemSize;
                ++size;
            }

            if(this.virtualStartIndex != from || !this.isRendered){
                this.virtualStartIndex = from;
                this.virtualList = this.dataList.slice(from, from+size+1);
                this.canvasTop = startSpace;
                $scope.updateCanvasTop(startSpace);
                this.isRendered = true;
                if(!$scope.$$phase){
                    $scope.$digest();
                }
            }
        }

        /**
         * function to remove the data from the virtual list when the conatiner is not in view
         */
        this.removeData = function(){
            this.virtualList = [];
            this.isRendered = false;
            if(!$scope.$$phase){
                $scope.$digest();
            }
        }

        /**
         * function to update the element height
         * @param height
         */
        this.updateElementHeight = function( height ){
            this.elementHeightDefined = height;
        }

        /**
         * function to update the virtual container height
         * @param height
         */
        this.updateContainerHeight = function( height ){
            this.containerHeight = height;
            $scope.updateContainerHeight(height);
        }

        /**
         * Updates the row cache
         * @param index
         * @param height
         */
        this.updateRowCache = function(index, height){
            if(!this.rowCache.hasOwnProperty(this.virtualStartIndex + index) || this.rowCache[this.virtualStartIndex + index] != height){
                var prev = this.rowCache[this.virtualStartIndex + index] || this.elementHeightDefined;
                this.rowCache[this.virtualStartIndex + index] = height;
                this.updateContainerHeight(this.containerHeight + (height-prev));
            }
        }

    }
    /**
     * directive to calculate the positions of virtual elements in a container
     */
    angular.module('wf.framework').directive('wfVirtualListContainer',['$timeout', '$window', function($timeout, $window){
        return {
            restrict : 'A',
            controller : VirtualScrollController,
            controllerAs : 'vc',
            scope:true,
            link : function(scope, elem, attrs, ctrl){
                var isInManualScroll = false;
                var isInScroll = false;
                var definedElmHeight = parseInt(attrs.height);
                scope.$watchCollection(attrs.virtuallist, function(newVal){
                    ctrl.dataList = newVal;
                    if(ctrl.dataList){
                        ctrl.updateContainerHeight(ctrl.dataList.length * definedElmHeight);
                        virtualScroll();
                    }
                })
                ctrl.updateElementHeight(definedElmHeight);

                /**
                 * function to update the virtual container element height
                 * @param height
                 */
                scope.updateContainerHeight = function(height){
                    elem.find('.virtual-container').css('min-height', height);
                }

                /**
                 * function to update the virtual container canvas element position
                 * @param height
                 */
                scope.updateCanvasTop = function(top){
                    isInManualScroll = true;
                    elem.find('.virtual-canvas').css('transform','translate(0px, '+top+'px');
                    //elem.find('.virtual-canvas').css({top:top,position:'relative'});
                }

                /**
                 * function to call when the last element in the virtual list is rendered
                 */
                scope.$renderedlast = function() {
                    isInManualScroll = true;
                };

                /**
                 * Checks if the conatiner is visible in the viewport
                 * @returns {boolean}
                 */
                function isContainerNotInView(){
                    var viewport = {};
                    viewport.top = $(window).scrollTop();
                    viewport.bottom = viewport.top + $(window).height();
                    var bounds = {};
                    bounds.top = elem.offset().top;
                    bounds.bottom = bounds.top + elem.outerHeight();
                    var notInView = ((bounds.top <= viewport.top) && (bounds.bottom <= viewport.top))
                        ||((bounds.top >= viewport.bottom))
                    var scrollTop = (viewport.top - bounds.top) > 0 ? (viewport.top - bounds.top) : 0;
                    ctrl.containerViewport = {isInView : !notInView , scrollTop : scrollTop, prevScrollTop : ctrl.containerViewport.scrollTop};
                    return notInView;
                };

                /**
                 * function to call on the scroll event
                 * @param event
                 */
                function virtualScroll(event){
                    var isInView = !isContainerNotInView()
                    if(!isInView && ctrl.isRendered){
                        ctrl.removeData();
                    }
                    if(!isInScroll && isInView){
                        isInScroll = true;
                        $timeout(function(){
                            if(!isInManualScroll){
                                ctrl.scroll()
                            }
                            isInManualScroll = false;
                            isInScroll = false;
                        },30)
                    }
                };

                //binds the window scroll event for the container rendering
                angular.element($window).bind('scroll', virtualScroll);

                //binds the window scroll event on the scope destroy
                scope.$on('$destroy', function(){
                    angular.element($window).unbind('scroll', virtualScroll)
                })
            }
        }
    }]);

    /**
     * works only when there is a repeater on the element
     */
    angular.module('wf.framework').directive('wfVirtualRepeatedElement',function(){
        return {
            restrict : 'A',
            require : '^wfVirtualListContainer',
            link : function(scope, elem, attrs, ctrl){

                //updates the element height after the rendering
                scope.$evalAsync(function() {
                   if(elem.outerHeight() != ctrl.elementHeightDefined){
                       ctrl.updateRowCache(scope.$index, elem.outerHeight());
                   }
                   if(scope.$last) {
                        scope.$renderedlast();
                   }
                });

                //listens to the emitter events for element height changes
                scope.$on('virtualRowHeightUpdated', function(){
                    setTimeout(function() {
                        if(elem.outerHeight() != ctrl.elementHeightDefined){
                            ctrl.updateRowCache(scope.$index, elem.outerHeight());
                        }
                    });
                });
            }
        }
    });

})()
/**
 * Created by U062274 on 8/28/14.
 */


/* Filters */
// This module is declared in framework/modules.js
angular.module('wf.framework').
    filter('interpolate', ['version', function(version) {
        return function(text) {
            return String(text).replace(/\%VERSION\%/mg, version);
        }
    }])
    .filter('replace', function() {
        return function(input, text) {
            return text.replace("${currentObject}", input)
        }
    })
    //formats positive percents as xxx.xxx and negative percents as (xxx.xxx)
    .filter('formatPercent', ['$filter', function($filter) {
        return function(input) {
            if(input != null && input < 0){
                input = Big(input).times(Big(-1));
                input = $filter("number")(input, 3);
                return "("+input+")";
            }else if(input != null && input >= 0) {
                return $filter("number")(input, 3);
            }
        }
    }])
    //formats positive amounts as x,xxx.xx and negative amounts as (x,xxx.xx)
    .filter('formatAmount', ['$filter', function($filter) {
        return function(input) {
            if(input != null && input < 0){
                input = Big(input).times(Big(-1));
                input = $filter("number")(input, 2);
                return "("+input+")";
            }else if(input != null && input >= 0) {
                return $filter("number")(input, 2);
            }
        }
    }])
    /*
     This filter formats a ssn as xxx-xx-xxxx format
     The input string is expected in xxxxxxxx format.
     */
    .filter("ssn", [function () {
        return function (value) {
            if (value) {
                if (value.length >= 9) {
                    return value.substr(0, 3) + "-" + value.substr(3, 2) + "-" + value.substr(5);
                } else if (value.length >= 5) {
                    return value.substr(0, 3) + "-" + value.substr(3, 2) + "-" + value.substr(5);
                } else if (value.length >= 3) {
                    return value.substr(0, 3) + "-" + value.substr(3);
                }
            }
            return value;
        };
    }])
    //This is a wrapper around number filter to display empty string for null input
    .filter('corenumber', ['$filter', function($filter) {
        return function(input, numberAttrs) {
            if (input == null) {
                return "";
            }
            if (numberAttrs != null) {
                return $filter("number")(input, numberAttrs);
            } else {
                return $filter("number")(input);
            }
        }
    }])

    .filter('securityHelperNamespaceFilter', function() {
        return function(input, namespace) {
            if (input && namespace) {
                return _.pick(input, namespace);
            } else {
                return input;
            }
        }
    })

    .filter('securityHelperPermissionFilter', function() {
        return function(input, permission) {
            if (input && permission) {
                var result = {};
                _.each(_.keys(input), function(key) {
                    result[key] = _.filter(input[key], function(elem) { return elem.permission === permission; })
                });
                return result;
            } else {
                return input;
            }
        }
    })

    .filter('securityHelperSortFilter', function() {
        return function(input, sort) {
            if (input && sort) {
                var result = {};
                _.each(_.keys(input), function(key) {
                    var arr = _.sortBy(input[key], function(elem) {
                        return elem.elementId.toLowerCase();
                    });
                    if (sort === 'DESC') {
                        result[key] = arr.reverse();
                    } else {
                        result[key] = arr;
                    }
                });
                return result;
            } else {
                return input;
            }
        }
    })
;


/* Services */


// This module is declared in scripts/modules.js
angular.module('wf.framework')
    .factory('DateTimeService', [function() {
        //Specifying only Central zone data, since we don't need all zones. This will be passed to timezone(https://github.com/mde/timezone-js)
        // library
        var timezoneData = {
            "zones":{
                "America/New_York":[
                    ["296.0333333333333","-","LMT","-2717668562000"],
                    ["300","US","E%sT","-1546387200000"],
                    ["300","NYC","E%sT","-852163200000"],
                    ["300","US","E%sT","-725932800000"],
                    ["300","NYC","E%sT","-63244800000"],
                    ["300","US","E%sT",null]],
                "America/Chicago":[
                    ["350.6","-","LMT","-2717668236000"],
                    ["360","US","C%sT","-1546387200000"],
                    ["360","Chicago","C%sT","-1067810400000"],
                    ["300","-","EST","-1045432800000"],
                    ["360","Chicago","C%sT","-852163200000"],
                    ["360","US","C%sT","-725932800000"],
                    ["360","Chicago","C%sT","-63244800000"],
                    ["360","US","C%sT",null]]
            },
            "rules":{
                "US":[
                    ["1918","1919","-","Mar","lastSun",["2","0","0",null],"60","D"],
                    ["1918","1919","-","Oct","lastSun",["2","0","0",null],"0","S"],
                    ["1942","only","-","Feb","9",["2","0","0",null],"60","W",""],
                    ["1945","only","-","Aug","14",["23","0","0","u"],"60","P",""],
                    ["1945","only","-","Sep","30",["2","0","0",null],"0","S"],
                    ["1967","2006","-","Oct","lastSun",["2","0","0",null],"0","S"],
                    ["1967","1973","-","Apr","lastSun",["2","0","0",null],"60","D"],
                    ["1974","only","-","Jan","6",["2","0","0",null],"60","D"],
                    ["1975","only","-","Feb","23",["2","0","0",null],"60","D"],
                    ["1976","1986","-","Apr","lastSun",["2","0","0",null],"60","D"],
                    ["1987","2006","-","Apr","Sun>=1",["2","0","0",null],"60","D"],
                    ["2007","max","-","Mar","Sun>=8",["2","0","0",null],"60","D"],
                    ["2007","max","-","Nov","Sun>=1",["2","0","0",null],"0","S"]],
                "NYC":[
                    ["1920","only","-","Mar","lastSun",["2","0","0",null],"60","D"],
                    ["1920","only","-","Oct","lastSun",["2","0","0",null],"0","S"],
                    ["1921","1966","-","Apr","lastSun",["2","0","0",null],"60","D"],
                    ["1921","1954","-","Sep","lastSun",["2","0","0",null],"0","S"],
                    ["1955","1966","-","Oct","lastSun",["2","0","0",null],"0","S"]],
                "Chicago":[
                    ["1920","only","-","Jun","13",["2","0","0",null],"60","D"],
                    ["1920","1921","-","Oct","lastSun",["2","0","0",null],"0","S"],
                    ["1921","only","-","Mar","lastSun",["2","0","0",null],"60","D"],
                    ["1922","1966","-","Apr","lastSun",["2","0","0",null],"60","D"],
                    ["1922","1954","-","Sep","lastSun",["2","0","0",null],"0","S"],
                    ["1955","1966","-","Oct","lastSun",["2","0","0",null],"0","S"]]
            }
        };

        //Initialize the timezone library
        var _tz = timezoneJS.timezone;
        _tz.loadingScheme = _tz.loadingSchemes.MANUAL_LOAD;
        _tz.loadZoneDataFromObject(timezoneData);


        var R_ISO8601_STR = /^(\d{4})-?(\d\d)-?(\d\d)(?:T(\d\d)(?::?(\d\d)(?::?(\d\d)(?:\.(\d+))?)?)?(Z|([+-])(\d\d):?(\d\d))?)?$/;
        // 1        2       3         4          5          6          7          8  9     10      11

        function int(str) {
            return parseInt(str, 10);
        }
        return {
            stdTimezoneOffset: function() {
                var today = new Date();
                var jan = new Date(today.getFullYear(), 0, 1);
                var jul = new Date(today.getFullYear(), 6, 1);
                return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
            },
            doesFollowDST: function() {
                var today = new Date();
                var jan = new Date(today.getFullYear(), 0, 1);
                var jul = new Date(today.getFullYear(), 6, 1);
                return jan.getTimezoneOffset() != jul.getTimezoneOffset();
            },
            isCurrentDST: function() {
                var today = new Date();
                return today.getTimezoneOffset() < this.stdTimezoneOffset();
            },
            clientMachineTimeZoneOffsetToUtcFn: function() {
                var today = new Date();
                return today.getTimezoneOffset();
            },
            //Return the offset of US Central(America/Chicago) time zone for the specified date
            getCentralTimezoneOffset: function(date) {
                var tzDate = new timezoneJS.Date(date, 'America/Chicago');
                return tzDate.getTimezoneOffset();
            },
            getTimezone: function() {
                var today = new Date();
                today.getTimezoneOffset()
            },
            jsonStringToDate: function (string) {
                var match;
                if (match = string.match(R_ISO8601_STR)) {
                    var date = new Date(0),
                        tzHour = 0,
                        tzMin  = 0,
                        dateSetter = match[8] ? date.setUTCFullYear : date.setFullYear,
                        timeSetter = match[8] ? date.setUTCHours : date.setHours;

                    if (match[9]) {
                        tzHour = int(match[9] + match[10]);
                        tzMin = int(match[9] + match[11]);
                    }
                    dateSetter.call(date, int(match[1]), int(match[2]) - 1, int(match[3]));
                    var h = int(match[4]||0) - tzHour;
                    var m = int(match[5]||0) - tzMin;
                    var s = int(match[6]||0);
                    var ms = Math.round(parseFloat('0.' + (match[7]||0)) * 1000);
                    timeSetter.call(date, h, m, s, ms);
                    return date;
                }
                return string;
            }
        }
    }]);


angular.module('wf.framework')
    .provider('wfHttpService', [
        function () {
            function isFile(obj) {
                return obj !=null && obj.toString(obj) === '[object File]';
            }
            var cacheServiceName;
            this.setDefaults = function(defaults) {
                if (defaults.cacheService) {
                    cacheServiceName = defaults.cacheService;
                }
            }
            var myService = {};
            this.$get = ['$http', '$q', '$log', '$injector', function($http, $q, $log, $injector) {
                var cacheService;
                if (cacheServiceName) {
                    try {
                        cacheService = $injector.get(cacheServiceName);
                    } catch (err) {
                        cacheService = $injector.get('frameworkCacheService');
                    }
                } else {
                    cacheService = $injector.get('frameworkCacheService');
                }
                return {

                    invokeService: function (restUrl, methodType, args, hideProgress) {
                        var deferred = $q.defer();

                        var startIdx = restUrl.indexOf('/') + 1;
                        var endIdx = restUrl.length;
                        var method = restUrl.substring(startIdx, endIdx);
                        var operationEnabled = cacheService.isCacheable({method: methodType, url: restUrl, data: args});


                        if (operationEnabled) {
                            var cachedData = cacheService.get({method: methodType, url: restUrl, data: args});
                            if (cachedData.data) {
                                deferred.resolve(cachedData.data);
                            } else {
                                $http({method: methodType, url: restUrl, data: args, headers: {'Content-Type': 'application/json'}}).
                                    success(function (data, status, headers, config) {
                                        deferred.resolve(data);
                                        cacheService.put(angular.copy(data), cachedData.applicationCacheContext);
                                    }).error(function (data, status, headers, config) {
                                        $log.error("Ajax request failed with status " + status);
                                        var rejectMsg = "An error occurred while loading";
										if (data && data.message) {
											rejectMsg = data.message;
										}
										deferred.reject(rejectMsg);
                                    });
                            }
                        } else {
                            var _hideProgress = false;
                            if (hideProgress) {
                                _hideProgress = hideProgress;
                            }
                            $http({method: methodType, url: restUrl, data: args, headers: {'Content-Type': 'application/json'}, hideProgress: _hideProgress })
                                .success(function (data, status, headers, config) {
                                    deferred.resolve(data);                                    
                                }).error(function (data, status, headers, config) {

                                    $log.error("Ajax request failed with status " + status);
									var rejectMsg = "An error occurred while loading";
									if (data && data.message) {
										rejectMsg = data.message;
									}
                                    deferred.reject(rejectMsg);                                    
                                });
                        }
                        return deferred.promise;
                    },
                    postService: function (restUrl, args) {

                        var deferred = $q.defer();
                        $http.post(restUrl, args).
                            success(function (data) {
                                deferred.resolve(data);
                            }).error(function (status) {
                                $log.error("Ajax request failed with status " + status);
                                deferred.reject("An error occurred while loading");
                            }
                        );
                        return deferred.promise;
                    },
                    invokeService_NoArgs_Get: function (restUrl) {
                        var deferred = $q.defer();
                        $http.get(restUrl).success(function (data, status, headers, config) {
                            deferred.resolve(data);
                        }).error(function (data, status, headers, config) {
                            $log.error("Ajax request failed with status " + status);
                            deferred.reject("An error occurred while loading");
                        });
                        return deferred.promise;
                    },
                    invokeService_Args_Get: function (url, params) {
                        var deferred = $q.defer();
                        $http({
                            url: url,
                            method: "GET",
                            params: params
                        }).success(function (data, status, headers, config) {
                            deferred.resolve(data);
                        }).error(function (data, status, headers, config) {
                            deferred.reject("An error occurred while loading");
                            $log.error("Ajax request failed with status " + status);
                        });
                        return deferred.promise;
                    }
                };
            }]

        }])
    .run(['$http', function($httpProvider){
        var isWindow = function (obj) {
            return obj && obj.window === obj;
        }
        var isScope = function (obj) {
            return obj && obj.$evalAsync && obj.$watch;
        }

        var toJsonReplacer = function(key, value) {
            var val = value;

            if (typeof key === 'string' && key.charAt(0) === '$') {
                val = undefined;
            } else if (typeof value === 'string' && val) {
				//strip out all control characters except \n, \r and \t
				//A character is considered to be an ISO control character if 
				//its code is in the range '\u0000' through '\u001F' or in the range '\u007F' through '\u009F'
				//The replacement is being done here instead of in transformRequest since JSON.stringify will
				//escape control characters
                val = value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g, "");
            } else if (isWindow(value)) {
                val = '$WINDOW';
            } else if (value &&  document === value) {
                val = '$DOCUMENT';
            } else if (isScope(value)) {
                val = '$SCOPE';
            }

            return val;
        }
        var toJson = function (obj, pretty) {
            if (typeof obj === 'undefined') return undefined;
            return JSON.stringify(obj, toJsonReplacer, pretty ? '  ' : null);
        }
        var isFile = function (obj) {
            return obj.toString() === '[object File]';
        }
        $httpProvider.defaults.transformRequest = [function(req){
            // Replaces commonly-used Windows 1252 encoded chars that do not exist in ASCII or ISO-8859-1
            // with ISO-8859-1 cognates.
            var s = req;
            //Only change if its a json object
            if(angular.isObject(s) && !isFile(s)) {
                s = toJson(s);

                // smart single quotes and apostrophe
                s = s.replace(/[\u2018\u2019\u201A]/g, "\'");
                // smart double quotes
                s = s.replace(/[\u201C\u201D\u201E]/g, "\\\"");
                // ellipsis
                s = s.replace(/\u2026/g, "...");
                // dashes
                s = s.replace(/[\u2013\u2014]/g, "-");
                // circumflex
                s = s.replace(/\u02C6/g, "^");
                // open angle bracket
                s = s.replace(/\u2039/g, "<");
                // close angle bracket
                s = s.replace(/\u203A/g, ">");
                // spaces
                s = s.replace(/[\u02DC\u00A0]/g, " ");
				
				//replace all other non-ascii char with space
                s = s.replace(/[^\x00-\x7F]/g, " ");
				
                return s;
            }
            return req;

        }].concat($httpProvider.defaults.transformRequest);
    }])
    .factory('frameworkCacheService', function() {
        return {
            isCacheable: function(config) {
                return false;
            }
        }
    })

// Speed up calls to hasOwnProperty
var hasOwnProperty = Object.prototype.hasOwnProperty;
function isEmpty(obj) {
    // null and undefined are "empty"
    if (obj == null) return true;
    // Assume if it has a length property with a non-zero value
    // that that property is correct.
    if (obj.length > 0)    return false;
    if (obj.length === 0)  return true;
    // Otherwise, does it have any properties of its own?
    // Note that this doesn't handle
    // toString and valueOf enumeration bugs in IE < 9
    for (var key in obj) {
        if (hasOwnProperty.call(obj, key)) return false;
    }
    return true;
}
/**
 * Created by U317503 on 6/3/14.
 */


angular.module('wf.framework').factory('wfModalService', ['$rootScope', '$timeout', function($rootScope, $timeout) {
    var kdl, kul, kpl;
    var oldFocus;

    // this set is used in conjunction with the progress indicator and must be
    // separate as it will be invoked in parallel with (but asynchronous from)
    // other invocations to this service
    var kdlPI, kulPI, kplPI;
    var oldFocusPI;
	
	/**
     * documentMode is an IE-only property
     * http://msdn.microsoft.com/en-us/library/ie/cc196988(v=vs.85).aspx
    */
	var msie = document.documentMode;
	
	var overflow = 'initial';
	
	//IE doesn't support overflow:initial
	if (msie) {
		overflow = 'auto';
	}

    var getScrollOffsets = function(w) {
        // use the specified window or the current window if no argument
        w = w || window;

        // for most browsers except IE8 and before
        if (w.pageXOffset != null) return {x: w.pageXOffset, y: w.pageYOffset};

        // for IE and standards mode browsers
        var d = w.document;
        if (document.compatMode == "CSS1Compat")
            return {x: d.documentElement.scrollLeft, y: d.documentElement.scrollTop};

        // for browsers in quirks mode
        return {x: d.body.scrollLeft, u: d.body.scrollTop};
    }

    var isElementInside = function(elem, elem2) {
        // Is elem2 inside elem
        var boundingRectangle = elem.getBoundingClientRect();   // viewport coordinates
        var offsets = getScrollOffsets();                       // scroll offsets
        // Convert to document coordinates
        var x = boundingRectangle.left + offsets.x;
        var y = boundingRectangle.top + offsets.y;
        var width = boundingRectangle.width || (boundingRectangle.right - boundingRectangle.left);
        var height = boundingRectangle.height || (boundingRectangle.bottom - boundingRectangle.top);

        boundingRectangle = elem2.getBoundingClientRect();   // viewport coordinates
        // Convert to document coordinates
        var x2 = boundingRectangle.left + offsets.x;
        var y2 = boundingRectangle.top + offsets.y;

        //console.log('x: ' + x + ' y: ' + y + ' width: ' + width + ' height: ' + height + ' x2: ' + x2 + ' y2: ' + y2);
        if (x2 >= x && x2 <= (x + width) &&
            y2 >= y && y2 <= (y + height)) {
            return true;
        } else {
            return false;
        }
    }

    var getTabStops = function(o, a, el) {
        // Check if this element is a tab stop
        if (el.tabIndex > 0) {
            if (o[el.tabIndex]) {
                o[el.tabIndex].push(el);
            } else {
                o[el.tabIndex] = [el];
            }
        } else if (el.tabIndex === 0) {
            // Tab index "0" comes last so we accumulate it seperately
            a.push(el);
        }
        // Check if children are tab stops
        if (el.children) {
            for (var i = 0, l = el.children.length; i < l; i++) {
                getTabStops(o, a, el.children[i]);
            }
        }
    }

    var getOrderedTabStops = function(el) {
        var o = [],
            a = [],
            stops = []

        getTabStops(o, a, el);
        for (var i = 0, l = o.length; i < l; i++) {
            if (o[i]) {
                for (var j = 0, m = o[i].length; j < m; j++) {
                    stops.push(o[i][j]);
                }
            }
        }
        for (var i = 0, l = a.length; i < l; i++) {
            stops.push(a[i]);
        }
        return stops;
    }

    // We need two parallel disableKeyboard handlers as they can be invoked concurrently and asynchronously
    // from each other for the loading indicator and other elements

    var disableAllKeyboardHandler = function(event) {
        event.preventDefault();
        event.stopPropagation();
    }

    var disableKeyboardHandler = function(event) {
        if (! event.data) {
            event.preventDefault();
            event.stopPropagation();
            return;
        }

        if (document.activeElement.tagName.toUpperCase() !== 'BODY') {
            if (! isElementInside(event.data, document.activeElement)) {
                //console.log('Stop: ' + document.activeElement + ' not inside ' + event.data);
                event.preventDefault();
                event.stopPropagation();
            } else {
                // If it is inside and is the first/last element, do not allow the user to tab off of the modal)
                if (event.keyCode === 9) {
                    // determine if tab operation is allowable based upon current position

                    var stops = getOrderedTabStops(event.data);
                    if (stops && stops.length > 1) {
                        if (document.activeElement === stops[stops.length - 1]) {
                            // at last stop, can only go backwards
                            if (! event.shiftKey) {
                                //console.log('Cannot fall of end');
                                event.preventDefault();
                                event.stopPropagation();
                            }
                        }
                        else if (document.activeElement === stops[0]) {
                            // at beginning stop, can only go forewards
                            if (event.shiftKey) {
                                //console.log('Cannot fall of front');
                                event.preventDefault();
                                event.stopPropagation();
                            }
                        }
                    } else {
                        // nowhere to go
                        event.preventDefault();
                        event.stopPropagation();
                    }
                }
                // allow other keys for entry into contained components
            }
        }
    }

    var beginModalBehaviorInternal = function(fromPI, elem) {
        var dataElem = elem && (elem.getElementsByClassName('wf-modal')[0] || elem.getElementsByClassName('modal')[0]) ?
                (elem.getElementsByClassName('wf-modal')[0] ? elem.getElementsByClassName('wf-modal')[0] : elem.getElementsByClassName('modal')[0]) :
                 elem;

        if (fromPI) {
            if (kdlPI === undefined) {
                kdlPI = angular.element(window).on("keydown", dataElem, disableAllKeyboardHandler);
                kplPI = angular.element(window).on("keypress", dataElem, disableAllKeyboardHandler);
                kulPI = angular.element(window).on("keyup", dataElem, disableAllKeyboardHandler);

                // save old focus and overflow for return
                oldFocusPI = document.activeElement;
                if (elem) {
                    // focus first tabbable stop
                    var stops = getOrderedTabStops(elem);
                    if (stops && stops.length > 0) {
                        $timeout(function() {
                            // we schedule this for immediate execution, but to also to ensure it does not collide
                            // with any existing digest cycle that may be running in response to other events.  This
                            // effectively means that the following will be scheduled for execution ASAP, but not
                            // concurrent with another apply/digest.  Note, that the typical $apply method does not
                            // work here as you may already be insides a digest cycle and calling it will create an
                            // INPROG error
                            stops[0].focus();
                        }, 0);
                    } else {
                        // If there are no focusable elements, then at least focus the modal
                            $timeout(function() {
                                // we schedule this for immediate execution, but to also to ensure it does not collide
                                // with any existing digest cycle that may be running in response to other events.  This
                                // effectively means that the following will be scheduled for execution ASAP, but not
                                // concurrent with another apply/digest.  Note, that the typical $apply method does not
                                // work here as you may already be insides a digest cycle and calling it will create an
                                // INPROG error
                                if (elem.focus) {
                                    elem.focus();
                                }
                            }, 0);
                    }
                }
                document.documentElement.style.overflow = 'hidden';
            }
        } else {
            if (kdl === undefined) {
                kdl = angular.element(window).on("keydown", dataElem, disableKeyboardHandler);
                kpl = angular.element(window).on("keypress", dataElem, disableKeyboardHandler);
                kul = angular.element(window).on("keyup", dataElem, disableKeyboardHandler);

                // save old focus and overflow for return
                oldFocus = document.activeElement;
                if (elem) {
                    // focus first tabbable stop
                    var stops = getOrderedTabStops(elem);
                    if (stops && stops.length > 0) {
                        $timeout(function() {
                            // we schedule this for immediate execution, but to also to ensure it does not collide
                            // with any existing digest cycle that may be running in response to other events.  This
                            // effectively means that the following will be scheduled for execution ASAP, but not
                            // concurrent with another apply/digest.  Note, that the typical $apply method does not
                            // work here as you may already be insides a digest cycle and calling it will create an
                            // INPROG error
                            stops[0].focus();
                        }, 0);
                    } else {
                        // If there are no focusable elements, then at least focus the modal
                            $timeout(function() {
                                // we schedule this for immediate execution, but to also to ensure it does not collide
                                // with any existing digest cycle that may be running in response to other events.  This
                                // effectively means that the following will be scheduled for execution ASAP, but not
                                // concurrent with another apply/digest.  Note, that the typical $apply method does not
                                // work here as you may already be insides a digest cycle and calling it will create an
                                // INPROG error
                                if (elem.focus) {
                                    elem.focus();
                                }
                            }, 0);
                    }
                }
                document.documentElement.style.overflow = 'hidden';
            }
        }
    }

    var endModalBehaviorInternal = function(fromPI) {
        if (fromPI) {
            if (kdlPI !== undefined) {
                angular.element(window).unbind("keydown", disableAllKeyboardHandler);
                angular.element(window).unbind("keypress", disableAllKeyboardHandler);
                angular.element(window).unbind("keyup", disableAllKeyboardHandler);
                kdlPI = kplPI = kulPI = undefined;

                if (kdl === undefined) {  // only restore if there is not another concurrent request
                    // restore focus to previous location and overflow
                    $timeout(function() {
                        // we schedule this for immediate execution, but to also to ensure it does not collide
                        // with any existing digest cycle that may be running in response to other events.  This
                        // effectively means that the following will be scheduled for execution ASAP, but not
                        // concurrent with another apply/digest.  Note, that the typical $apply method does not
                        // work here as you may already be insides a digest cycle and calling it will create an
                        // INPROG error
                        if (oldFocusPI && ! oldFocusPI.onfocus && (! oldFocusPI.outerHTML || oldFocusPI.outerHTML.search(/ng-focus/i) < 0)) {
                            // We only restore the focus if the element we came from is not already managing it
                            oldFocusPI.focus();
                        } // else {
                            // no implied move when fromPI and the element is managing focus
                        //}
                    }, 0);
                    document.documentElement.style.overflow = overflow;
                }
            }
        } else {
            if (kdl !== undefined) {
                angular.element(window).unbind("keydown", disableKeyboardHandler);
                angular.element(window).unbind("keypress", disableKeyboardHandler);
                angular.element(window).unbind("keyup", disableKeyboardHandler);
                kdl = kpl = kul = undefined;

                if (kdlPI === undefined) {  // only restore if there is not another concurrent request
                    // restore focus to previous location and overflow
                    var timeout = $timeout(function() {
                        // we schedule this for immediate execution, but to also to ensure it does not collide
                        // with any existing digest cycle that may be running in response to other events.  This
                        // effectively means that the following will be scheduled for execution ASAP, but not
                        // concurrent with another apply/digest.  Note, that the typical $apply method does not
                        // work here as you may already be insides a digest cycle and calling it will create an
                        // INPROG error
                        if (! oldFocus.onfocus && (! oldFocus.outerHTML || oldFocus.outerHTML.search(/ng-focus/i) < 0)) {
                            // We only restore the focus if the element we came from is not already managing it
                            oldFocus.focus();
                        } else {
                            // if ! fromPI and the element we came from is managing focus, then attempt
                            // to identify and focus the next tab stop (support keyboard only movement via
                            // tab key from one field to the next)
                            var stops = getOrderedTabStops(document);
                            if (stops && stops.length > 0) {
                                var newFocus;
                                for (var i = 0; i < stops.length; i++) {
                                    if (stops[i] === oldFocus) {
                                        if (i < (stops.length - 1)) {
                                            // we can focus next stop
                                            newFocus = stops[i + 1];
                                        } else {
                                            // focus first one
                                            newFocus = stops[0];
                                        }
                                        newFocus.focus();
                                        break;
                                    }
                                }
                            }
                        }
                    }, 0);
                    $timeout.cancel(timeout);
                    oldFocus = null;
                    document.documentElement.style.overflow = overflow;
                }
            }
        }
    }

    var beginModalBehavior = function(elem) {
        beginModalBehaviorInternal(false, elem);
    }

    var endModalBehavior = function() {
        endModalBehaviorInternal(false);
    }

    // this set is used in conjunction with the progress indicator and must be
    // separate as it will be invoked in parallel with (but asynchronous from)
    // other invocations to this service

    var beginModalProgressIndicatorBehavior = function(elem) {
        beginModalBehaviorInternal(true, elem);
    }

    var endModalProgressIndicatorBehavior = function() {
        endModalBehaviorInternal(true);
    }

    return {
        getScrollOffsets: getScrollOffsets,
        isElementInside: isElementInside,
        getTabStops: getTabStops,
        getOrderedTabStops: getOrderedTabStops,
        disableAllKeyboardHandler: disableAllKeyboardHandler,
        disableKeyboardHandler: disableKeyboardHandler,
        beginModalBehavior: beginModalBehavior,
        endModalBehavior: endModalBehavior,
        beginModalProgressIndicatorBehavior : beginModalProgressIndicatorBehavior,
        endModalProgressIndicatorBehavior: endModalProgressIndicatorBehavior
    }
}]);


/**
 * Created by U062274 on 1/14/15.
 */
angular.module('wf.framework')
.service('wfSecurityService', ['$log', '$injector',
    function($log, $injector) {
        var securityDataService;

        /*
         * setSecurityDataServiceName - Provide the name of the securityDataService to be injected.
         */
        var securityDataServiceName;
        this.setSecurityDataServiceName = function(serviceName) {
            securityDataServiceName = serviceName;
        }

        /*
         * setUiSecurityConfig - Can be used to set the security configuration instead of providing a securityService.
         */
        var uiSecurityConfig;
        this.setUiSecurityConfig = function(uiSecurity) {
            if (uiSecurity) {
                uiSecurityConfig = uiSecurity;
            }
        }
        this.getUiSecurityConfig = function() {
            return uiSecurityConfig;
        }

        /*
         * setSecurityEnvironment - Can be used to set the security environment instead of providing a securityService.
         */
        var securityEnvironment;
        this.setSecurityEnvironment = function(env) {
            if (env) {
                securityEnvironment = env;
            }
        }
        this.getSecurityEnvironment = function() {
            return securityEnvironment;
        }

        /*
         * Map of standard functions provided by wfSecurity package.
         */
        var functionMap = {
            'run': function(condition, securityEnvironment){
                if (! condition) {
                    $log.error("wfSecurity condition could not be found.");
                    return false;
                }
                var fun = getEvaluatorFunc(condition.evaluator);
                if (fun) {
                    if (condition.values) {
                        return fun(condition.values, securityEnvironment, condition.evaluator);
                    }
                    if (condition.value) {
                        return fun(condition.value, securityEnvironment, condition.evaluator);
                    }
                    return fun(null, securityEnvironment, condition.evaluator);
                } else {
                    $log.error(condition.evaluator + " is not a valid evaluator.");
                    return false;
                }
            },
            'And':  function (conditions, securityEnvironment) {
                if (!conditions) {
                    return true;
                }
                for(var i=0; i<conditions.length; i++) {
                    var result = true;
                    var fun = getEvaluatorFunc(conditions[i].evaluator);
                    if (fun) {
                        if (conditions[i].values && conditions[i].values.length > 0) {
                            result = fun(conditions[i].values, securityEnvironment, conditions[i].evaluator);
                        } else if (conditions[i].value) {
                            result = fun(conditions[i].value, securityEnvironment, conditions[i].evaluator);
                        } else {
                            result = fun(null, securityEnvironment, conditions[i].evaluator);
                        }

                    } else {
                        $log.error(conditions[i].evaluator + " is not a valid evaluator.");
                    }
                    if(!result){
                        return false;
                    }
                }
                return true;
            },
            'Or': function(conditions, securityEnvironment){
                if (!conditions) {
                    return true;
                }
                for(var i=0; i<conditions.length; i++) {
                    var result = true;
                    var fun = getEvaluatorFunc(conditions[i].evaluator);
                    if (fun) {
                        if (conditions[i].values && conditions[i].values.length > 0) {
                            result = fun(conditions[i].values, securityEnvironment, conditions[i].evaluator);
                        }else if (conditions[i].value) {
                            result = fun(conditions[i].value, securityEnvironment, conditions[i].evaluator);
                        } else {
                            result = fun(null, securityEnvironment, conditions[i].evaluator);
                        }
                    } else {
                        $log.error(conditions[i].evaluator + " is not a valid evaluator.");
                    }
                    if(result){
                        return true;
                    }
                }
                return false;
            },
            'Not': function(conditions, securityEnvironment){
                var result;
                if (conditions && conditions.length > 0) {
                    var fun = getEvaluatorFunc(conditions[0].evaluator);
                    if (fun) {
                        if (conditions[0].values && conditions[0].values.length > 0) {
                            result = fun(conditions[0].values, securityEnvironment, conditions[0].evaluator);
                        }else if (conditions[0].value) {
                            result = fun(conditions[0].value, securityEnvironment, conditions[0].evaluator);
                        } else {
                            result = fun(null, securityEnvironment, conditions[0].evaluator);
                        }
                        return !result;
                    } else {
                        $log.error(conditions[0].evaluator + " is not a valid evaluator.");
                        return true;
                    }
                }
                return true;
            }
        };

        /*
         * envEvaluator - Compare "value" to variable in the securityEnvironment for the variable name contained in
         * "evaluator".
         */
        var envEvaluator = function(value, securityEnvironment, evaluator) {
            var envVarName = evaluator.charAt(0).toLowerCase() + evaluator.slice(1);
            if (value === "*" && securityEnvironment[envVarName]) {
                return true;
            }
            if (securityEnvironment[envVarName].constructor === Array) {
                for (var i = 0; i < securityEnvironment[envVarName].length; i++) {
                    if (securityEnvironment[envVarName][i] === value) {
                        return true;
                    }
                }
                return false;
            }
            else if (value === securityEnvironment[envVarName]) {
                return true;
            }
            return false;
        }

        /*
         * getEvaluatorFunc - If "evaluator" matches one of the special evaluators in functionMap[] then return
         * that function, otherwise, return the envEvaluator() function.
         */
        function getEvaluatorFunc(evaluator) {
            var func = functionMap[evaluator];
            if (func) {
                return func;
            }
            return envEvaluator;
        }

        /*
         * getCondition - Find the condition that matches ConditionName
         */
        function getCondition(conditionName) {
            if (uiSecurityConfig.conditions) {
                return uiSecurityConfig.conditions[conditionName];
            }
            $log.error("Could not find condition: " + conditionName);
            return null;
        }

        /*
         * getElementPermission - Return if the element matches the condition.
         */
        var getElementPermission = function(namespace,elementId) {
            if (! securityDataService && securityDataServiceName) {
                try {
                    securityDataService = $injector.get(securityDataServiceName);
                } catch (err) {
                }
            }
            if (securityDataService) {
                this.setUiSecurityConfig(securityDataService.getSecurityConfig());
                this.setSecurityEnvironment(securityDataService.getSecurityEnvironment());
            }

            if(elementId != null) {
                elementId = elementId.replace(/[\w]+:/g, '');
                //Handle elements inside ng-repeat by removing the _{{$index}}
                elementId = elementId.replace(/(\_\{\{.*}})*\_\{\{([a-zA-Z_\$]|[\\w\$])+\}\}/, '');
            }
            if (uiSecurityConfig) {
                var namespaceRules = uiSecurityConfig.ruleMap[namespace];
                if (namespaceRules) {
                    var buttonRule = namespaceRules["elementMap"];
                    if (buttonRule !== null) {
                        var elementRules = buttonRule[elementId];
                        if (elementRules != null && elementRules.length > 0) {
                            for (var i = 0; i < elementRules.length; i++) {
                                var elementRule = elementRules[i];
                                //$log.debug("condition: " + elementRule.condition + " action: " + elementRule.action);
                                if (elementRule.condition) {
                                    var condition = getCondition(elementRule.condition);
                                    var result = true;
                                    //evaluate the condition
                                    if(! securityEnvironment)
                                        return false;
                                    else
                                        result = functionMap.run(condition, securityEnvironment);
                                    //$log.debug("result: " + result);

                                    if (result) {
                                        return {condition: elementRule.condition, action: elementRule.action};
                                    }
                                } else {
                                    return elementRule.action;
                                }
                            }
                        }
                    }
                }
            }

            return false;
        };

        /*
         * getRoutePermission - Placeholder for future capabilities.
         */
        var getRoutePermission = function(routeName) {
            // for now, just return true
            $log.debug("Getting route permission for route: ", routeName);
            return true;
        };

        return {
            getElementPermission: getElementPermission,
            getRoutePermission: getRoutePermission,
            setUiSecurityConfig: this.setUiSecurityConfig,
            getUiSecurityConfig: this.getUiSecurityConfig,
            setSecurityEnvironment: this.setSecurityEnvironment,
            getSecurityEnvironment: this.getSecurityEnvironment,
            setSecurityDataServiceName: this.setSecurityDataServiceName
        };
    }
]);
