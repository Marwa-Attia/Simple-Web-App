module.exports = function (grunt) {

    grunt.initConfig({

        pkg: grunt.file.readJSON('package.json'),

        systemjs: {
            options: {
                minify: true,
                builder: {
                    packages: {
                        'app': {
                            defaultExtension: 'js'
                        }
                    },
                    meta: {
                        'angular2/core': {build:false},
                        'angular2/upgrade': {build:false}
                    },
                    sourceMaps: true
                },
                build: {
                    mangle: false
                }
            },

            dist: {
                files: [{
                    "src":  "./app/app.module.js",
                    "dest": "./target/bundles/app.min.js"
                }]
            }
        }
    });

    grunt.loadNpmTasks('grunt-systemjs-builder');
    grunt.registerTask("default",["systemjs:dist"]);
};