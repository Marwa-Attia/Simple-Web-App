

/// <reference path="../typings/index.d.ts" />

import {DependencyTreeComponent} from './modules/deptree/dependencytree.component';
import {DependencyTreeService} from './modules/deptree/dependencytree.service';
import {DependencyGraphService} from './modules/deptree/dependencygraph.service';
import upgradeAdapter from './core/core.module';
import {Angular2DemoComponent} from './modules/treeview/angular2demo.component';

angular.module('core')
    .factory('depTreeService', upgradeAdapter.downgradeNg2Provider(DependencyTreeService))
    .directive('deptree', <angular.IDirectiveFactory>upgradeAdapter.downgradeNg2Component(DependencyTreeComponent))
    .directive('angularDemo', <angular.IDirectiveFactory>upgradeAdapter.downgradeNg2Component(Angular2DemoComponent));

//upgradeAdapter.downgradeNg2Provider([DependencyTreeService, DependencyGraphService]);
upgradeAdapter.bootstrap(document.documentElement, ['core']);