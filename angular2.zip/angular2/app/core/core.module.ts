import {UpgradeAdapter} from '@angular/upgrade';
import { FormsModule }   from '@angular/forms';
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {IncludesPipe} from "../modules/framework/pipes/includes.pipe";
import {Angular2DemoComponent} from '../modules/treeview/angular2demo.component';
import {DependencyTreeComponent} from '../modules/deptree/dependencytree.component';
import {DependencyTreeService} from '../modules/deptree/dependencytree.service';
import {DependencyGraphService} from '../modules/deptree/dependencygraph.service';
@NgModule({
  imports: [
       BrowserModule,FormsModule
  ],
  declarations: [
    Angular2DemoComponent,IncludesPipe,DependencyTreeComponent
  ],
  providers: [DependencyTreeService, DependencyGraphService]
})
export class CoreModule { }

const upgradeAdapter  = new UpgradeAdapter(CoreModule);

export default upgradeAdapter;

