import {Pipe, PipeTransform} from '@angular/core';

@Pipe({ name: 'includes',  pure: false })
export class IncludesPipe implements PipeTransform {
  transform(value: any, args: string[] = null): any {
    if(args[0] && args[1]){
       value = value.filter(item => item[args[0]].includes(args[1]))
    }
    return value;
  }
}

