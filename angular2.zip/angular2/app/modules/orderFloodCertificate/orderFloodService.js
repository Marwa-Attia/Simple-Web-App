serviceModule.factory('orderFloodService',function(coreHttpService,$window){
    var orderFloodRequest;

    var serviceItems = {};
    var baseurl = "/applicationAdmin/controller/orderFloodCertificate/";
    serviceItems.setRequest = function(request) {
    	orderFloodRequest = request ;
    };

    serviceItems.orderFlood = function(){
        var restUrl = baseurl+'orderFlood';
        var method = 'POST';
        return coreHttpService.invokeService(restUrl, method, orderFloodRequest);
    };

      return serviceItems;
});


