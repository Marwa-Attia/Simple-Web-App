controllersModule.controller("orderFloodOutputCtrl", [ '$scope', '$location', '$window','orderFloodService',
   function($scope, $location, $window,
			orderFloodService) {
		
	    $scope.init = function() {	
	    	$scope.orderFloodResponse = null;
	    };

	    $scope.orderFlood = function() {
	    	if ($scope.orderFloodRequest.enterpriseDealNumber != null && $scope.orderFloodRequest.enterpriseDealNumber != '') {
           
	    		orderFloodService.setRequest($scope.orderFloodRequest);
	    		orderFloodService.orderFlood().then(function(data) {
                if (data) {
                    $scope.orderFloodResponse = data;
                    $scope.alert(data);
                }
	    		}, function(errorMessage) {
	    			$scope.error = errorMessage;
	    		});
	    	}
	    };
   
	    $scope.backToCoreTools = function() {
	    	$location.path('admin.html');
	    };
} ]);