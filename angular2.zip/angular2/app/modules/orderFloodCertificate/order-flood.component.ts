import { Component,OnInit } from '@angular/core';
import { OrderFloodService,OrderFloodResponse,OrderFloodRequest } from 'order-flood.service';
import { Location } from '@angular/common';

@Component({
	moduleId: module.id,
	selector: 'order-flood',
    templateUrl: 'order-flood.component.html',
    providers: [OrderFloodService]
})

export class orderFlood implements OnInit{
  orderFloodResponse: OrderFloodResponse;
  orderFloodRequest: OrderFloodRequest;
  error: string;

  ngOnInit(): void {
	  this.orderFloodResponse = null;
  }
  
  constructor( private location: Location,orderFloodService: OrderFloodService) {
	}
  
   orderFlood(): void {
    if (this.orderFloodRequest.enterpriseDealNumber != null && this.orderFloodRequest.enterpriseDealNumber != '') {
           
    	orderFloodService.setRequest(this.orderFloodRequest);
    	
    	orderFloodService.orderFlood().then(function(data) {//TODO review
                if (data) {
                    this.orderFloodResponse = data;
                    alert(data);
                }
          }, function(errorMessage) {
            this.error = errorMessage;
          });
        }
  }
   backToCoreTools(): void {
	   this.location.back();
   }
}

