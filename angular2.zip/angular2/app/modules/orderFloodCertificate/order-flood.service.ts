import { Injectable } from '@angular/core';
import { CoreHttpService } from '../../../scripts/libs/CoreHttpService';//TODO is that the correct the path?

@Injectable()
export class OrderFloodService {
	orderFloodRequest: OrderFloodRequest;
	readonly baseurl: string = "/applicationAdmin/controller/orderFloodCertificate/";// TODO correct this

	constructor(coreHttpService:CoreHttpService) {
		
	}
	
	setRequest(request:OrderFloodRequest){
		orderFloodRequest = request ;
	}
	
	orderFlood(): OrderFloodResponse {//TODO should return a promise 
		restUrl:string = baseurl+'orderFlood';
		method:string = 'POST';
		return coreHttpService.invokeService(restUrl, method, orderFloodRequest);// assuming the api for the coreHttpService is still the same
	}
}

export class OrderFloodResponse {
	  
}

export class OrderFloodRequest {
  enterpriseDealNumber:string
}