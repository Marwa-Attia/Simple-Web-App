import {Component} from '@angular/core';
@Component({
    selector: 'angular-demo',
    templateUrl: 'angular2/app/modules/treeview/view.html'
})
export class Angular2DemoComponent {
    modules = [{name : 'ASD'},
    {name : 'ASD'},
    {name : 'ASD'},
    {name : 'BCD'}];
 
    constructor () {
    }    
}