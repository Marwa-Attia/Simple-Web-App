import './rxjs-extensions';
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';
import { HttpModule }    from '@angular/http';
import { AppRoutingModule } from './app-routing.module';

import { DeactiveLoanHoganService } from 'deactive-loan-hogan.service';
import { DeactiveLoanHoganComponent }         from 'deactive-loan-hogan.component';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule
  ],
  declarations: [
    DeactiveLoanHoganComponent
  ],
  providers: [ DeactiveLoanHoganService ],
  bootstrap: [ DeactiveLoanHoganComponent ]
})
export class LoanHoganModule { }