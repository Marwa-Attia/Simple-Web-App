
import { Injectable } from '@angular/core';
//import { CoreHttpService } from '../../../scripts/libs/CoreHttpService';//TODO is that the correct the path?

@Injectable()
export class DeactiveLoanHoganService {
	private requestData: HoganCall;
	//readonly baseurl: string = "/applicationAdmin/controller/hoganCall/"; // TODO correct this

//	constructor(coreHttpService:CoreHttpService) {
//		
//	}
	
	setRequest(request:HoganCall){
		this.requestData = request ;
	}
	
	runCallHogan(): HoganCallResponse {
        console.log(this.requestData);
        return {message:'OK'};
		//restUrl:string = baseurl+'hoganCall';
		//method:string = 'POST';
		//return coreHttpService.invokeService(restUrl, method, requestData);// assuming the api for the coreHttpService is still the same
	}
}

export class HoganCallResponse {
	message:string; 
}

export class HoganCall {
	startDate: Date;
	endDate: Date;
  	recordCount:number;
}