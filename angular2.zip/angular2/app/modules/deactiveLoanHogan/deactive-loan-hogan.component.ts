import { Component } from '@angular/core';
import { DeactiveLoanHoganService,HoganCall,HoganCallResponse } from 'deactive-loan-hogan.service';

@Component({
	moduleId: module.id,
	selector: 'deactive-loan-hogan',
    templateUrl: 'deactive-loan-hogan.component.html'
})

export class DeactiveLoanHoganComponent {
  	hoganCallErrorMessage: string;
  	hoganCall: HoganCall;
	error: string;

  	constructor(private deactiveLoanHoganService: DeactiveLoanHoganService) {}
  
  	triggerCallHogan(): void {
  	let	stDate: Date = this.hoganCall.startDate;
	let	edDate: Date = this.hoganCall.endDate;
	let	recCount: number = this.hoganCall.recordCount;
  		if(!stDate || !edDate || !recCount) {
  			this.hoganCallErrorMessage = "Record Count, Start Date and End Date are required.";
  		} else {
  			if(stDate && stDate < new Date(2014, 4, 15)) {
  				this.hoganCallErrorMessage = 'Start date cannot be prior to Release 2.14 implementation date (05/16/2014).';
  			} else if(stDate && edDate && stDate > edDate) {
  				this.hoganCallErrorMessage = 'Start date cannot be after end date.';		 
  			} else {
  				this.deactiveLoanHoganService.setRequest(this.hoganCall);  
  				this.deactiveLoanHoganService.runCallHogan().then(function (data) { 
  					if(data) {
  						this.hoganCallErrorMessage = data.message;
  					}
  				},
  				function (errorMessage) {
  					this.error = errorMessage;
  				});
  			}
  		}
  	}
}








