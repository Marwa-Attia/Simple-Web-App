// import {ModuleData, ComponentData} from "./DependencyTreeService"

// class ComponentGraph{
//     asDependencyFor : Map<string,ComponentGraph>;
//     current : string;
//     isolatedDependents : Array<string>;
//     dependsOn : Map<string,ComponentGraph>;
//     isRoot : boolean;
//     orderingLevel : number;
//     maxLevel : number;
//     constructor(){
//         this.asDependencyFor = new Map<string,ComponentGraph>();
//         this.dependsOn = new Map<string,ComponentGraph>();
//         this.current = undefined;
//         this.isolatedDependents = [];
//         this.isRoot = false;
//         this.orderingLevel = 0;
//         this.maxLevel = 0;
//     }
    
//     private contains(dependency:string, map:any, mapName:string):boolean{
//         if(map.has(dependency)){
//             return true;
//         }else{
//             var found = false;
//             map.forEach((value, key)=>{
//                 if(value.contains(dependency,value[mapName], mapName)){
//                     found = true;
//                     return false;
//                 }
//             });
//             return found;
//         }
//     }    
    
//     containsDependsOn(dependency):boolean{
//         return this.contains(dependency,this.dependsOn, 'dependsOn');
//     }      
    
//     containsAsDependencyFor(dependency):boolean{
//         return this.contains(dependency,this.asDependencyFor, 'asDependencyFor');
//     } 
    
//     getParent(dependency):string{
//         if(this.dependsOn.has(dependency)){
//             return this.current;
//         }else{
//             var found = false;
//             var parent = undefined;
//             this.dependsOn.forEach((value, key)=>{
//                 parent = value.getParent(dependency)
//                 if(parent){
//                     found = true;
//                     return false;
//                 }
//             });
//             return parent;
//         }
//     }
    
    
//     toString():string{
//         var out = ""
//         /*this.current.forEach(obj=>{
//             out = out+obj;
//         })*/
//         if(this.isRoot)
//             out="";
//         this.dependsOn.forEach(obj=>{
//             out = out+obj.toString();
//         })            
//         return out;
//     }
// }

// interface ModuleGraph{
    
// }

// export class DependencyGraphService {
//     private resolvedModulemap : Map<String,ModuleGraph>;
//     private resolvedComponentMap : Map<string,ComponentGraph>;
//     private unresolvedComponentMap : Map<string,ComponentGraph>;
//     private componentGraph : ComponentGraph;
//     private rootComponentGraph : ComponentGraph;
//     private rootComponent : ComponentData;
    
//     generateDependencyTree(modules:ModuleData[], componentTree:{}):any{
//         this.resolvedComponentMap = new Map<string,ComponentGraph>();
//         this.unresolvedComponentMap = new Map<string,ComponentGraph>();
//         this.rootComponentGraph = new ComponentGraph();
//         this.rootComponentGraph.isRoot = true;
//         this.rootComponentGraph.current='root'; 
//         componentTree['root'] = this.rootComponent = {
//             deps:[],
//             name:'root',
//             type:'root',
//             graph:this.rootComponentGraph            
//         }
//         for(var treeKey in componentTree){
//             if(treeKey!='root')
//                 this.resolveComponentGraph(componentTree[treeKey], componentTree, 'root', this.rootComponentGraph, componentTree[treeKey]);
//         }
//         this.rootComponentGraph.dependsOn.forEach((graph,key) => {
//             if(graph.orderingLevel != 1 ){
//                 graph.asDependencyFor.delete('root');
//                 this.rootComponentGraph.dependsOn.delete(key);
//             }
//         });
//         this.updateDepths(this.rootComponentGraph);
//         return this.rootComponentGraph;
//     }
    
//     updateDepths(graph:ComponentGraph) : void{
//         var minGraphLevel = -1;
//         if(graph.dependsOn.size == 0){
//            minGraphLevel = graph.orderingLevel = this.rootComponentGraph.maxLevel;
//         }
//         graph.dependsOn.forEach((compGraph,key) => {
//             this.updateDepths(compGraph);   
//             if(compGraph.orderingLevel < minGraphLevel || minGraphLevel == -1){
//                 minGraphLevel = compGraph.orderingLevel;
//             }         
//         });
//         if(minGraphLevel > graph.orderingLevel ){
//            graph.orderingLevel = minGraphLevel-1;
//         }
        
//     }
    
//     resolveComponent(component, componentTree) : any {
//         this.unresolvedComponentMap.set(component.name, component.graph);
//         for(var key in component.deps){
//             if(!this.resolvedComponentMap.has(key)){
//                 if(this.unresolvedComponentMap.has(key)){
//                     throw Error('Circular reference detected: '+component.name+' --> ' +key);
//                 }
//                 this.resolveComponent(componentTree[key], componentTree);                
//             }        
//         }
//         this.resolvedComponentMap.set(component.name,component.graph);
//         this.unresolvedComponentMap.delete(component.name);
//     } 
    
//     resolveComponentGraph(componentData, componentTree, parentName, parentGraph:ComponentGraph , rootComp:ComponentData) : any {
//         var graph:ComponentGraph = componentData.graph;
//         if(!this.resolvedComponentMap.has(componentData.name)){            
//             if(!graph){
//                 graph = componentData.graph = new ComponentGraph();
//                 graph.current = componentData.name;
//                 graph.orderingLevel = parentGraph.orderingLevel+1;
//                 if(graph.orderingLevel > this.rootComponentGraph.maxLevel){
//                     this.rootComponentGraph.maxLevel = graph.orderingLevel;
//                 }
//             }                    
//             this.unresolvedComponentMap.set(componentData.name, graph);
//             if(!parentGraph.isRoot || graph.asDependencyFor.size==0){
//                 if(graph.asDependencyFor.has('root')){
//                     graph.asDependencyFor.delete('root')
//                 }
//                 graph.asDependencyFor.set(parentName, parentGraph);                
//             }
//             componentData.deps.forEach(compName => {
//                 if(componentTree[compName]){
//                     if(this.unresolvedComponentMap.has(compName)){
//                         throw Error('Circular reference detected: '+componentData.name+' --> ' +compName);
//                     }
//                     this.resolveComponentGraph(componentTree[compName], componentTree, componentData.name, graph, rootComp);
//                 }                                     
//             });
//             parentGraph.dependsOn.set(componentData.name, graph);
//             this.resolvedComponentMap.set(componentData.name,componentData.graph);
//             this.unresolvedComponentMap.delete(componentData.name);            
//         }else{
//             if(!parentGraph.isRoot || graph.asDependencyFor.size==0){
//                 if(graph.asDependencyFor.has('root')){
//                     graph.asDependencyFor.delete('root')
//                 }
//                 graph.asDependencyFor.set(parentName, parentGraph);  
//                 parentGraph.dependsOn.set(componentData.name, graph);              
//             }
//             if(parentGraph.orderingLevel >= graph.orderingLevel){
//                this.adjustChildLevels(graph, parentGraph); 
//             }
//         }
//         return graph;
//     } 
    
//     adjustChildLevels(graph:ComponentGraph, parentGraph:ComponentGraph){
//         graph.orderingLevel = parentGraph.orderingLevel+1;
//         if(graph.orderingLevel > this.rootComponentGraph.maxLevel){
//             this.rootComponentGraph.maxLevel = graph.orderingLevel;
//         }
//         graph.dependsOn.forEach(compGraph => {
//             if(graph.orderingLevel >= compGraph.orderingLevel){
//                this.adjustChildLevels(compGraph, graph); 
//             }                   
//         });
//     }
// }