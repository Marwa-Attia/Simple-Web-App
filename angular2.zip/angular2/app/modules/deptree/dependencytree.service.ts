import {Injectable} from '@angular/core'
import annotate from '../../lib/Annotate';

export interface ComponentData {
    name?: string,
    deps?: Array<string>,
    type?: String,
    isNg2Component? : boolean,
    graph?:any
}

export interface ModuleData {
    name?: string,
    deps?: Array<string>,
    components?: Array<ComponentData>,
    componentsMap? : Object
}

@Injectable()
export class DependencyTreeService {
    metadata = {
        angularVersion: angular.version,
        apps: [],
        modules: [],
        host: window.location.host,
        modulemap : {}
    };
    
    componentTree = {
        
    };
    treeModuleName:string = undefined;
    
    addDeps(moduleData, name, depsSrc, type) : any {
        var data = {};
        if (typeof depsSrc === 'function') {
            data = {
                name: name,
                deps: annotate(depsSrc),
                type: type
            };
            // Array or empty
        } else if (Array.isArray(depsSrc)) {
            var deps = depsSrc.slice();
            deps.pop();
            data = {
                name: name,
                deps: deps,
                type: type
            };
        } else {
            data = {
                deps :[],
                name: name,
                type: type
            };
        }
        if(data['deps']&& data['deps'][0] && typeof data['deps'][0]=='string' && data['deps'][0].startsWith('ng2'))
            data['isNg2Component'] = true;
        else
            data['isNg2Component'] = false;
        moduleData.components.push(data);
        if(!moduleData.componentsMap[data['name']])
            moduleData.componentsMap[data['name']]=data;
        this.addToComponentTree(moduleData, data);    
        data = null;
    }
    
    addToComponentTree(moduleData:ModuleData, data:ComponentData):void {
        if(data && (!this.treeModuleName || moduleData.name.includes(this.treeModuleName) )){
            if(!this.componentTree[data.name]) {
                //this.componentTree[data.name]={}
                this.componentTree[data.name]= data; 
            }else{
                //throw Error("Multiple modules have same component name : "+data.name);
            }
            //this.componentTree[data.name][moduleData.name] = data; 
            
        }
    }
    
    addModulesToComponentTree(modules:ModuleData[]):void {
        for (var j = 0; j < modules.length; j++) {
            var moduleData:ModuleData = modules[j]
            for (var i = 0; (!this.treeModuleName || moduleData.name.includes(this.treeModuleName) ) && moduleData.components && i < moduleData.components.length; i++) {
                var compData = moduleData.components[i];
                if(!this.componentTree[compData.name]) {
                    //this.componentTree[compData.name]={}
                    this.componentTree[compData.name] = compData; 
                }else{
                    //throw Error("Multiple modules have same component name : "+compData.name);
                }
                //this.componentTree[compData.name][moduleData.name] = compData; 
                //this.componentTree[compData.name] = compData; 
            }
        }                  
    }   
        
    createModule(moduleName:string, treeModuleName:string) : {} {
        this.metadata = {
            angularVersion: angular.version,
            apps: [],
            modules: [],
            host: window.location.host,
            modulemap : {}
        };
        this.treeModuleName = treeModuleName;
        this.componentTree = {}
        /*for (var i = 0; i < this.metadata.modules.length; i++) {
            if (this.metadata.modules[i].name === moduleName) {
                this.addModulesToComponentTree(this.metadata.modules);
                return this.metadata;
                break;
            }
        }*/
        return this.createModules(moduleName);
    }

    createModules(name) : {} {
        var exist = false;
        for (var i = 0; i < this.metadata.modules.length; i++) {
            if (this.metadata.modules[i].name === name) {
                exist = true;
                console.log("Metadata for module "+ name+" already exists");
                if(this.treeModuleName === name)
                    this.addModulesToComponentTree(this.metadata.modules);
                return this.metadata;
            }
        }

        if (exist || name === undefined) {
            return;
        }

        var module = angular.module(name);

        var moduleData:ModuleData= {
            name: name,
            deps: module.requires,
            components: new Array<ComponentData>(),
            componentsMap : {}
        };

        this.processModule(moduleData);
        this.metadata.modules.push(moduleData);
        if(!this.metadata.modulemap[name])
            this.metadata.modulemap[name] = moduleData;

        angular.forEach(module.requires, (mod) => {
            this.createModules(mod);
        });
        return this.metadata;
    }

    processModule(moduleData) {
        var moduleName = moduleData.name;
        var module = <any>angular.module(moduleName);

        // For old versions of AngularJS the property is called 'invokeQueue'
        //noinspection TypeScriptUnresolvedVariable
        var invokeQueue = module._invokeQueue || module.invokeQueue;

        angular.forEach(invokeQueue, (item) => {
            var compArgs = item[2];
            switch (item[0]) {
                case '$provide':
                    switch (item[1]) {
                        case 'value':
                        case 'constant':
                            this.addDeps(moduleData, compArgs[0], compArgs[1], 'value');
                            break;

                        default:
                            this.addDeps(moduleData, compArgs[0], compArgs[1], 'service');
                            break;
                    }
                    break;

                case '$filterProvider':
                    this.addDeps(moduleData, compArgs[0], compArgs[1], 'filter');
                    break;
                case '$animateProvider':
                    this.addDeps(moduleData, compArgs[0], compArgs[1], 'animation');
                    break;
                case '$controllerProvider':
                    this.addDeps(moduleData, compArgs[0], compArgs[1], 'controller');
                    break;
                case '$compileProvider':
                    if (compArgs[1].constructor === Object) {
                        angular.forEach(compArgs[1], (key, value) => {
                            this.addDeps(moduleData, key, value, 'directive');
                        });
                    }

                    this.addDeps(moduleData, compArgs[0], compArgs[1], 'directive');
                    break;
                case '$injector':
                    // invoke, ignore
                    break;
                default:
                    //disablePlugin('unknown dependency type', item[0]);
                    break;
            }

        });
    }
}