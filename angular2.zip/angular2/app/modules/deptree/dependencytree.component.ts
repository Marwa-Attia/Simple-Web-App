import {Component} from '@angular/core';
import {DependencyTreeService} from './dependencytree.service';
import {DependencyGraphService} from './dependencygraph.service';

@Component({
    selector: 'deptree',
    templateUrl: 'angular2/app/modules/deptree/view.html',
    //pipes:[IncludesPipe]
})
export class DependencyTreeComponent {
    module : any;
    searchModulename:string = 'core' ;
    metadata : any;
    componentTree :{};
    currentHighlighted = [];
 
    constructor (private treeService:DependencyTreeService, private graphService:DependencyGraphService ) {
        this.metadata = treeService.metadata;
        this.componentTree = treeService.componentTree;
    }
    
    generateDependencyTree(): any {
       return this.graphService.generateDependencyTree(this.metadata.modules, this.componentTree);
    }
    
    highlight(component):void{
        if(this.currentHighlighted.length>0){
            this.currentHighlighted.forEach(graph =>{
                graph.highlighted = false;
            });
        }
        this.currentHighlighted = component.graph.highlight();        
    }
    
    private generateModules() : void {
        this.treeService.createModule('core',this.searchModulename);
        this.metadata = this.treeService.metadata;
        this.componentTree = this.treeService.componentTree;
        var graph = this.generateDependencyTree();
        console.log(this.metadata);
        console.log(this.componentTree);
        console.log(graph);
    }
}
