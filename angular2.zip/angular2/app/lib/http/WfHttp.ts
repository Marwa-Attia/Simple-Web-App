import WfUtils from '../utils/WfUtils'

export default class WfHttp{
    constructor(wfutils : WfUtils){}
}