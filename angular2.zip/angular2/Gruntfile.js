module.exports = function (grunt) {

    grunt.initConfig({

        pkg: grunt.file.readJSON('package.json'),

        systemjs: {
            options: {
                minify: true,
                sourceMaps: true,
                build:{
                    mangle:true
                },
                builder: {
                    format:'global',
                    transpiler: "typescript",
                    packages: {
                        'app': {
                            defaultExtension: 'ts'
                        }
                    },
                    meta: {
                        '@angular/core': {build: false},
                        '@angular/upgrade': {build: false},
                        '@angular/*': {build: false}
                    }, map: {
                        "typescript": "node_modules/typescript/lib/typescript.js"
                    },
                    typescriptOptions: {
                        inlineSources: true,
                        inlineSourceMap: false,
                        "sourceMap": true,
                        "emitDecoratorMetadata": true,
                        "experimentalDecorators": true,
                        "removeComments": false,
                        "noImplicitAny": false,
                        "project":true,
                        outDir:"/"
                    }
                }
            },
            dist: {
                files: [{
                    "src": "app/app.module.ts",
                    "dest": "target/bundles/app.min.js"
                }]
            }
        }
    });

    grunt.loadNpmTasks('grunt-systemjs-builder');
    grunt.registerTask("default", ["systemjs:dist"]);
};