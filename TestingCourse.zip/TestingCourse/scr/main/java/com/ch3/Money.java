package com.ch3;

/**
 * Created by u486992 on 4/5/2016.
 */
public class Money {
    private final int amount;
    private final String currency;

    public Money(int amount, String currency) throws IllegalArgumentException{
        if(amount<0){
            throw new IllegalArgumentException("Amount Can't be less than 0");
        }
        if(currency==null || currency.isEmpty()){
            throw new IllegalArgumentException("Currency Can't be null");
        }
        this.amount = amount;
        this.currency = currency;
    }

    public int getAmount() {
        return amount;
    }

    public String getCurrency() {
        return currency;
    }

    public boolean equals(Object anObject) {
        if (anObject instanceof Money) {
            Money money = (Money) anObject;
            return money.getCurrency().equals(getCurrency())
                    && getAmount() == money.getAmount();
        }
        return false;
    }
    public static void main(String [] args){
        System.out.print("Hello");
    }
}
