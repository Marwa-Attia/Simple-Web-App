package com.ch3.exercise;


/**
 * Created by u486992 on 4/7/2016.
 */
public class FahrenheitCelciusConverter {
    public static int toCelcius(float fahrenheit) {
        return (int) Math.ceil((fahrenheit - 32) * 5/9);
    }

    public static int toFahrenheit(float celcius) {
        return (int) Math.floor(celcius * 9/5 + 32);
    }
}
