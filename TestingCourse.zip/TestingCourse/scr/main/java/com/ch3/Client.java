package com.ch3;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by u486992 on 4/6/2016.
 */
public class Client {
    private List<Address> addresses;

    public Client() {
        this.addresses = new ArrayList<Address>();
    }

    public void addAddress(Address address) {
        this.addresses.add(address);
    }

    public List<Address> getAddresses() {
        return addresses;
    }
}
