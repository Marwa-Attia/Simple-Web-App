package com.ch3;

/**
 * Created by u486992 on 4/6/2016.
 */
public class Address {
    private String addressStr;

    public Address(String addressStr) {
        this.addressStr = addressStr;
    }

    public String getAddressStr() {
        return addressStr;
    }
}
