package com.ch5;

/**
 * Created by u486992 on 4/15/2016.
 */
public class MailServer {
    public void send(String email, String msgContent) {

    }
}
