package com.ch5;

/**
 * Created by u486992 on 4/15/2016.
 */
public class TemplateEngine {
    public String prepareMessage(Template template, Client client) {
        return null;
    }
}
