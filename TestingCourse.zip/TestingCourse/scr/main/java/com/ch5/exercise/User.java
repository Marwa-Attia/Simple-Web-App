package com.ch5.exercise;

/**
 * Created by u486992 on 4/18/2016.
 */
public class User {
    private String password;

    public void setPassword(String password) {
        System.err.println(this.password+" Param: "+password);
        this.password = password;
        System.err.println(this.password+" Param: "+password);
    }

    public String getPassword() {
        return password;
    }
}
