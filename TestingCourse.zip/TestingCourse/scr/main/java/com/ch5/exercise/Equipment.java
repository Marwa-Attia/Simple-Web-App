package com.ch5.exercise;

/**
 * Created by u486992 on 4/20/2016.
 */
public enum Equipment {
    WHITE_BOARD,PROJECTOR,MICROPHONE
}
