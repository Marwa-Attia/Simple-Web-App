package com.ch5.exercise;

import java.util.List;

/**
 * Created by u486992 on 4/20/2016.
 */
public class Criteria {
    private int capacity;
    private List<Equipment> equipments;

    public List<Equipment> getEquipments() {
        return equipments;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setEquipments(List<Equipment> equipments) {
        this.equipments = equipments;
    }
}
