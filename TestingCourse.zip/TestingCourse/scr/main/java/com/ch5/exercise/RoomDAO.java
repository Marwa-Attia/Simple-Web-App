package com.ch5.exercise;

import java.util.Collection;

/**
 * Created by u486992 on 4/20/2016.
 */
public interface RoomDAO {
    public Room findRoom(Criteria criteria);
    public Room findRoom(String name);
    public Collection<Room> getAllRooms();
    public Collection<Room> getAllAvailableRooms(int timeSlotStart);
}
