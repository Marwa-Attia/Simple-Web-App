package com.ch5.exercise;

import java.util.*;

/**
 * Created by u486992 on 4/20/2016.
 */
public class ClassRoomBooker {

    private RoomDAO roomDAO;

    public ClassRoomBooker(RoomDAO roomDAO) {
        this.roomDAO = roomDAO;
    }

    public Room bookRoom(String name, TimeSlot timeSlotStart) {
        Room room = roomDAO.findRoom(name);
        return book(room, timeSlotStart);
    }

    public Room bookRoom(Criteria criteria, TimeSlot timeSlotStart) {
        Room room = roomDAO.findRoom(criteria);
        return book(room, timeSlotStart);
    }

    private Room book(Room room, TimeSlot timeSlotStart) {
        if (room.getTimeSlots().contains(timeSlotStart)) {
            int index = room.getTimeSlots().indexOf(timeSlotStart);
            TimeSlot val = room.getTimeSlots().get(index);
            if (val.isAvailable()) {
                val.setAvailable(false);
                return room;
            }
        }
        return null;
    }
    public Collection<Room> getAllRooms() {
        Collection<Room> rooms = roomDAO.getAllRooms();
        return rooms;
    }
    public Collection<Room> getAllAvailableRooms(int timeSlot) {
        Collection<Room> rooms = roomDAO.getAllAvailableRooms(timeSlot);
        return rooms;
    }
}
