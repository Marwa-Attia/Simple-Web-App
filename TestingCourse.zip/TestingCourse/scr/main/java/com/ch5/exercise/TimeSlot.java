package com.ch5.exercise;

/**
 * Created by u486992 on 4/20/2016.
 */
public class TimeSlot {
    private int value;
    private boolean available;

    public TimeSlot(int value) {
        this.value = value;
        available=true;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

}
