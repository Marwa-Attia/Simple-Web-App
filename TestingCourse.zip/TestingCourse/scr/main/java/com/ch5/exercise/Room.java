package com.ch5.exercise;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by u486992 on 4/20/2016.
 */
public class Room {
    private String name;
    private int capacity;
    private List<Equipment> equipments;

    private List<TimeSlot> timeSlots ;
    public List<Equipment> getEquipments() {
        return equipments;
    }

    public int getCapacity() {
        return capacity;
    }

    public String getName() {
        return name;
    }

    public List<TimeSlot> getTimeSlots() {
        return timeSlots;
    }

    public Room(int capacity, String name, List<Equipment> equipments) {
        this.capacity = capacity;
        this.name = name;
        this.equipments = equipments;
        timeSlots= new ArrayList<TimeSlot>();
        for (int i=8; i<13;i++){
            TimeSlot timeSlot =new TimeSlot(i);
            timeSlots.add(timeSlot);
        }
       for (int i=1; i<5;i++){
           TimeSlot timeSlot =new TimeSlot(i);
           timeSlots.add(timeSlot);
       }
    }
}
