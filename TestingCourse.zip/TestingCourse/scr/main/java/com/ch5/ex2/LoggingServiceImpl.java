package com.ch5.ex2;

import java.util.Calendar;

/**
 * Created by u486992 on 4/19/2016.
 */
public class LoggingServiceImpl implements Logger<RaceResultsService> {
    @Override
    public void log(Message message) {
        System.out.println("Message "+message+" sent on: "+Calendar.getInstance());
    }
}
