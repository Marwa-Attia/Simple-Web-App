package com.ch5.ex2;

import java.util.Calendar;

/**
 * Created by u486992 on 4/19/2016.
 */
public interface LoggingService {
    void log(Message message);

}
