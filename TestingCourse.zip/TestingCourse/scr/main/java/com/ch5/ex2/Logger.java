package com.ch5.ex2;

/**
 * Created by u486992 on 4/19/2016.
 */
public interface Logger<T> {
    void log(Message message);
}
