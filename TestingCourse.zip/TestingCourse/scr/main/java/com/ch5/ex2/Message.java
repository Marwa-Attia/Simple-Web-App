package com.ch5.ex2;

/**
 * Created by u486992 on 4/15/2016.
 */
public interface Message {
}
