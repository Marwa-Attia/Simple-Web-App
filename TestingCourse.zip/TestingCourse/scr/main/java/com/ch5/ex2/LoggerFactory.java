package com.ch5.ex2;

/**
 * Created by u486992 on 4/19/2016.
 */
public class LoggerFactory {
    public static LoggingServiceImpl getLogger(Class<RaceResultsService> raceResultsServiceClass) {
        return new LoggingServiceImpl();
    }
}
