package com.ch5.ex2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

/**
 * Created by u486992 on 4/15/2016.
 */
public class RaceResultsService {
    public RaceResultsService() {
        subscribers = new HashSet<Client>();
    }

    private Collection<Client> subscribers;

    public void send(Message message) {
        for (Client client : subscribers) {
            client.receive(message);
        }
    }

    public void addSubscriber(Client client) {
        subscribers.add(client);
    }

    public void removeSubscriber(Client client) {
        subscribers.remove(client);
    }
}
