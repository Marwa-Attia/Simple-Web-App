package com.ch5.ex2;

import java.util.*;

/**
 * Created by u486992 on 4/15/2016.
 */
public class RaceResultsService {
    private static Logger logger =
            LoggerFactory.getLogger(RaceResultsService.class);
    public RaceResultsService() {
        subscribers = new HashMap<Topic,Collection<Client>>();
    }

    private Map<Topic,Collection<Client>> subscribers;
    public void send(Message message, Topic topic) {
        Collection<Client> clients=subscribers.get(topic);
        if(clients==null){
            clients= new HashSet<Client>();
        }else{
            for (Client client : clients) {
                client.receive(message);
                logger.log(message);
            }
        }
    }

    public void addSubscriber(Client client, Topic topic) {
        Collection<Client> clients=subscribers.get(topic);
        if(clients!=null) {
            clients.add(client);
        }else{
            Collection<Client> topicClients= new HashSet<Client>();
            topicClients.add(client);
            subscribers.put(topic,topicClients) ;
        }
    }

    public void removeSubscriber(Client client, Topic topic) {
        Collection<Client> clients=subscribers.get(topic);
        if(clients!=null){
            clients.remove(client);
        }
    }
}
