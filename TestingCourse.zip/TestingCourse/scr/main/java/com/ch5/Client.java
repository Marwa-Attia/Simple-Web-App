package com.ch5;

/**
 * Created by u486992 on 4/15/2016.
 */
public class Client {
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
