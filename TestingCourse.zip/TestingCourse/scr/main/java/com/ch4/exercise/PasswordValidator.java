package com.ch4.exercise;

/**
 * Created by u486992 on 4/13/2016.
 */
public class PasswordValidator {
    /**
     * Validates that password matches the following :
     * 1-(?=.*\d) contains at least one digit
     * 2-(?=.*[a-z]) contains at least one lowercase letter
     * 3-(?=.*[A-Z]) contains at least one uppercase letter
     * 4-(?=.*[@#$%!|]) contains at least one special character
     * 5-{6,10} of length no less than 6 characters and no more than 10
     * @param pass String value to validate
     * @return boolean indicating weather or not the password is right.
     */
    public static boolean validate(String pass) {
        if (pass.matches("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%!|]).{6,10})")) {
            return true;
        } else {
            return false;
        }
    }
}
