package com.ch4.exercise;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by u486992 on 4/14/2016.
 */
public class RegexNumberChecker {
    private List<Integer> numberList;
    private Pattern digitPattern = Pattern.compile("\\d{3}");
    public RegexNumberChecker() {
        numberList= new ArrayList<Integer>();
    }

    public List<Integer> getNumberList(String val) {
        Matcher m = digitPattern.matcher(val);
        while (m.find()) {
            numberList.add(Integer.getInteger(m.group()));
        }
        return numberList;
    }
}
