package com.ch4.exercise;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by u486992 on 4/13/2016.
 */
public class MeetingRoomBooker {
    private List<Integer> bookedHours;

    public MeetingRoomBooker() {
        this.bookedHours = new ArrayList<Integer>();
    }

    public boolean bookHour(int hour) throws IllegalArgumentException{
        if (hour>24||hour<1){
            throw  new IllegalArgumentException("Valid hours should be in the range of (1-24");
        }
        if(bookedHours.contains(hour)){
            return false;
        }else {
            bookedHours.add(hour);
            return true;
        }
    }

    public List<Integer> getBookedHours() {
        return bookedHours;
    }
}
