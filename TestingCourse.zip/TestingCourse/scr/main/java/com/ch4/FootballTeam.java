package com.ch4;

import java.util.Comparator;

/**
 * Created by u486992 on 4/7/2016.
 */

public class FootballTeam implements Comparable<FootballTeam>{
    private int gamesWon;

    public int getGamesWon() {
        return gamesWon;
    }

    /**
     *  Creates a FootballTeam with supplied number of games won
     * @param gamesWon the number of games won by the team
     * @throws IllegalArgumentException in case of Invalid (Negative) number of games won
     */
    public FootballTeam(int gamesWon) throws IllegalArgumentException{
        if(gamesWon<0){
            throw  new IllegalArgumentException("Number of games won can't be negative");
        }
        this.gamesWon=gamesWon;
    }


    @Override
    public int compareTo(FootballTeam otherTeam) {
        return  this.gamesWon - otherTeam.getGamesWon();
    }
}