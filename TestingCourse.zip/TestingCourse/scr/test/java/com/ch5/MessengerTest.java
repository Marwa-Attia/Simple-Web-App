package com.ch5;

/**
 * Created by u486992 on 4/15/2016.
 */

import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.*;
import static org.junit.Assert.assertTrue;

public class MessengerTest {
    private static final String MSG_CONTENT ="Msg Content" ;
    private static final String CLIENT_EMAIL = "marwa.atya@gmail.com";
    private Template template;
    private TemplateEngine templateEngine;
    private Client client;
    private MailServer mailServer;

    @Before
    public void setUp() {
        //Dummy, needs to be there but we might as well send null instead.
        template = mock(Template.class);
        //Stub, will behave in the way we would tell it to behave (gain control over the indirect input for the SUT)
        templateEngine = mock(TemplateEngine.class);
        //Another Stub
        client = mock(Client.class);
        //Spy
        mailServer=mock(MailServer.class);
    }

    @Test
    public void sendMethodInMailServerShouldBeCalledWhenMailIsSent() {
        Messenger sut = new Messenger(mailServer, templateEngine);
        //Describing behaviour which the templateEngine stub should perform using the when() method
        when(templateEngine.prepareMessage(template, client)).thenReturn(MSG_CONTENT);
       //Describing behaviour which the client stub should perform using the when() method
        when(client.getEmail()).thenReturn(CLIENT_EMAIL);
        sut.sendMessage(client, template);
        //Spying on the send method in the mailServer Spy, to verify that it was called with the correct painters from our SUT( gain control over the indirect output of the SUT)
        verify(mailServer).send(CLIENT_EMAIL, MSG_CONTENT);
    }
}
