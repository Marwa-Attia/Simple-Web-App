package com.ch5.exercise;

import org.junit.Before;
import org.junit.Test;
import org.mockito.cglib.proxy.Callback;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.mockito.stubbing.OngoingStubbing;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
public class UserServiceImplTest {

    private static final String ANY_PASSWORD ="Pass123" ;
    private static final String ANY_STRING ="4455" ;
    private UserDAO userDao;
    private SecurityService securityService;
    private User user;

    @Before
    public void setUp() throws Exception {
        userDao=mock(UserDAO.class);
        securityService=mock(SecurityService.class);
        user=mock(User.class);

    }

    @Test
    public void testAssignPassword() throws Exception {
        UserServiceImpl userService= new UserServiceImpl(userDao,securityService);
        when(securityService.md5(user.getPassword())).thenReturn(ANY_PASSWORD);
        userService.assignPassword(user);
        verify(user,times(1)).setPassword(ANY_PASSWORD);
        verify(userDao,times(1)).updateUser(user);
    }


}