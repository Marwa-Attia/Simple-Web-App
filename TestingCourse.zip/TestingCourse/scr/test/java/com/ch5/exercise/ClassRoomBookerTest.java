package com.ch5.exercise;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

/**
 * Created by u486992 on 4/20/2016.
 */
public class ClassRoomBookerTest {
    private Criteria criteria;
    private RoomDAO roomDAO;
    private ClassRoomBooker classRoomBooker;
    private Room room;
    private List<Room> rooms;
    private List<TimeSlot> timeSlots;
    private TimeSlot timeSlot=new TimeSlot(1);
    @Before
    public void setUp(){
        roomDAO = mock(RoomDAO.class);
        classRoomBooker= new ClassRoomBooker(roomDAO);
        room=mock(Room.class);
        timeSlots= new ArrayList<TimeSlot>();
        timeSlots.add(timeSlot);

    }
    @Test
     public void shouldBookRoomByName(){
        when(roomDAO.findRoom("Room1")).thenReturn(room);
        when(room.getTimeSlots()).thenReturn(timeSlots);
        Room room=   classRoomBooker.bookRoom("Room1", timeSlot);
        assertNotNull("A room can be booked by name ", room);
    }
    @Test
    public void shouldBookRoomByCriteria(){
        criteria= mock(Criteria.class);
        when(roomDAO.findRoom(criteria)).thenReturn(room);
        when(room.getTimeSlots()).thenReturn(timeSlots);
        Room room=   classRoomBooker.bookRoom(criteria, timeSlot);
        assertNotNull("A room can be booked by Criteria ", room);
    }
    public void shouldListAllRooms(){
        rooms= new ArrayList<Room>();
        rooms.add(room);
        when(roomDAO.getAllRooms()).thenReturn(rooms);
    }
}
