package com.ch5.ex2;

import org.junit.Before;
import org.junit.Test;

import java.util.Calendar;

import static org.mockito.Mockito.*;
import static org.junit.Assert.assertTrue;

/**
 * Created by u486992 on 4/15/2016.
 */
public class RaceResultsServiceTest {
    private Client client1;
    private Client client2;
    private Message message;
    private Message anotherMessage;
    private RaceResultsService raceResultsService;
    private LoggingServiceImpl loggingService;

    @Before
    public void setUp() {
        client1 = mock(Client.class);
        message = mock(Message.class);
        anotherMessage = mock(Message.class);
        raceResultsService = new RaceResultsService();
        loggingService=mock(LoggingServiceImpl.class);
    }

    @Test
    public void nonSubscribersShouldNotGetNotified() {
        raceResultsService.send(message, Topic.F1);
        verify(client1, never()).receive(message);

    }

    @Test
    public void allSubscribedClientsShouldReceiveMessages() {
        client2 = mock(Client.class);
        raceResultsService.addSubscriber(client1, Topic.F1);
        raceResultsService.addSubscriber(client2, Topic.F1);
        raceResultsService.send(message, Topic.F1);
        verify(client1, times(1)).receive(message);
        verify(client2, times(1)).receive(message);

    }

    @Test
    public void subscribedClientsToDifferentTopicsShouldReceiveAllMessagesToAllSubscribedTopics() {
        raceResultsService.addSubscriber(client1, Topic.F1);
        raceResultsService.addSubscriber(client1, Topic.HORSE_RACCE);
        raceResultsService.send(message, Topic.F1);
        raceResultsService.send(message, Topic.HORSE_RACCE);
        raceResultsService.send(message, Topic.FOOTBALL);
        verify(client1, atMost(2)).receive(message);
    }

    @Test
    public void removedSubscriberShouldNotGetNotified() {
        raceResultsService.addSubscriber(client1, Topic.HORSE_RACCE);
        raceResultsService.send(message, Topic.HORSE_RACCE);
        verify(client1, atMost(1)).receive(message);
        raceResultsService.removeSubscriber(client1, Topic.HORSE_RACCE);
        raceResultsService.send(anotherMessage, Topic.HORSE_RACCE);
        verify(client1, never()).receive(anotherMessage);
    }

    @Test
    public void subscriberShouldReceiveMsgForSubscribedTopicsOnly() {
        raceResultsService.addSubscriber(client1, Topic.F1);
        raceResultsService.send(message, Topic.F1);
        raceResultsService.send(message, Topic.HORSE_RACCE);
        verify(client1, times(1)).receive(message);
    }
    @Test
    public void serviceShouldLogEveryMsgDateAndTxt() {
        raceResultsService.addSubscriber(client1, Topic.F1);
        raceResultsService.send(message, Topic.F1);
      //  when(LoggerFactory.getLogger(RaceResultsService.class)).
        //        thenReturn(loggingService);
        verify(loggingService, times(1)).log(message);
    }
}
