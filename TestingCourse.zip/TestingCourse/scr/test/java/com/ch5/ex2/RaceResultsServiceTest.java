package com.ch5.ex2;

import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.*;
import static org.junit.Assert.assertTrue;

/**
 * Created by u486992 on 4/15/2016.
 */
public class RaceResultsServiceTest {
   private Client client1;
    private Client client2;
    private  Message message;
    private  Message anotherMessage;
    private  RaceResultsService raceResultsService;
    @Before
    public void setUp(){
        client1 = mock(Client.class);
        message=mock(Message.class);
        anotherMessage=mock(Message.class);
        raceResultsService= new RaceResultsService();
    }
    @Test
    public void nonSubscribersShouldNotGetNotified(){
        verify(client1,never()).receive(message);
        raceResultsService.send(message);
    }
    @Test
    public void subscriberShouldGetNotified(){
        raceResultsService.addSubscriber(client1);
        raceResultsService.send(message);
        verify(client1).receive(message);
    }
    @Test
    public void allSubscribedClientsShouldReceiveMessages(){
        client2 = mock(Client.class);
        raceResultsService.addSubscriber(client1);
        raceResultsService.addSubscriber(client2);
        raceResultsService.send(message);
        verify(client1).receive(message);
        verify(client2).receive(message);

    }
@Test
    public void shouldSendOnlyOneMessageToMultiSubscriber(){
    raceResultsService.addSubscriber(client1);
    raceResultsService.addSubscriber(client1);
    raceResultsService.send(message);
    verify(client1,atMost(1)).receive(message);
}
    @Test
    public void removedSubscriberShouldNotGetNotified(){
        raceResultsService.addSubscriber(client1);
        raceResultsService.send(message);
        verify(client1,atMost(1)).receive(message);
        raceResultsService.removeSubscriber(client1);
        raceResultsService.send(anotherMessage);
        verify(client1,never()).receive(anotherMessage);
    }
}
