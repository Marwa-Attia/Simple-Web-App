package com.ch4;

import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;

/**
 * Created by u486992 on 4/7/2016.
 */
@RunWith(JUnitParamsRunner.class)
public class FootballTeamTest {
    private static final int ANY_NUMBER = 123;

    private static Object[] numOfGamesWon() {
        return $($(0), $(1), $(3));
    }
    private static Object[] invalidNumOfGamesWon() {
        return $($(-1), $(-5), $(null));
    }
    @Test
    @Parameters(method = "numOfGamesWon")
    public void constructorShouldSetGamesWon(int  numOfGamesWon) {
        FootballTeam team = new FootballTeam(numOfGamesWon);
        assertEquals(numOfGamesWon + " games passed to constructor, but "
                + team.getGamesWon() + " were returned", numOfGamesWon, team.getGamesWon());
    }
    @Test(expected = IllegalArgumentException.class)
    @Parameters(method = "invalidNumOfGamesWon")
    public void constructorShouldThrowIAEForInvalidNumOfGames(int  invalidNumOfGamesWon) {
        FootballTeam team = new FootballTeam(invalidNumOfGamesWon);

    }
    @Test
    public void shouldBePossibleToCompareTeams() {
        FootballTeam team = new FootballTeam(ANY_NUMBER);
        assertTrue("FootballTeam should implement Comparable",team instanceof Comparable);
    }
    @Test
    public void teamsWithMoreMatchesWonShouldBeGreater() {
        FootballTeam team_2 = new FootballTeam(2);
        FootballTeam team_3 = new FootballTeam(3);
        FootballTeam team_4 = new FootballTeam(3);
        assertTrue("Team with more wins should rank higher",team_3.compareTo(team_2) > 0);
        assertTrue("Team with less wins should rank lower",team_2.compareTo(team_3) < 0);
        assertTrue("Team with the same number of wins should rank the same",team_4.compareTo(team_3) ==0);
    }
}
