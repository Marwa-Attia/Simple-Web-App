package com.ch4.exercise;

import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Test;
import org.junit.runner.RunWith;


import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
/**
 * Created by u486992 on 4/13/2016.
 */
@RunWith(JUnitParamsRunner.class)
public class PasswordValidatorTest {
    private Object[] getValidPasswords(){
        return $("Pass!23","E@Pop55");
    }
    private Object[] getInvalidPasswords(){
        return $("999!23","Pop5555","123456","pass!23","PASS@12","P@sswordD","P@s1","E@Pop55E@Pop55");
    }
    @Test
    @Parameters(method = "getValidPasswords")
    public void shouldAcceptValidPasswords(String pass){
        assertTrue("Method should return true for valid passwords",PasswordValidator.validate(pass));

    }
    @Test
    @Parameters(method = "getInvalidPasswords")
    public void shouldRejectInvalidPasswords(String pass){
        assertFalse("Method should return false for invalid passwords",PasswordValidator.validate(pass));

    }
}
