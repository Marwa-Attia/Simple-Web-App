package com.ch4.exercise;

import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;

/**
 * Created by u486992 on 4/14/2016.
 */
@RunWith(JUnitParamsRunner.class)
public class RegexNumberCheckerTester {
    private Object[] getParams() {
        return $($("999!23", 1), $("Pop", 0), $("123456", 2), $("Pass12", 0), $("123", 1),$("cdefg 345 12bbb33 678tt",2));
    }

    @Test
    @Parameters(method = "getParams")
    public void shouldReturnAllThreeDigitsNumberInString(String val, int expectedCount) {
        RegexNumberChecker regexNumberChecker = new RegexNumberChecker();
        List<Integer> results = regexNumberChecker.getNumberList(val);
        assertEquals(results.size(), expectedCount);
    }
}
