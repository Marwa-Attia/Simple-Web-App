package com.ch4.exercise;

import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;

import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by u486992 on 4/13/2016.
 */
@RunWith(JUnitParamsRunner.class)
public class MeetingRoomBookerTest {
    private Object[] getInvalidHours(){
        return $(-1,0,25);
    }
    @Test
    public void shouldReturnListOfBookedHours() {
        MeetingRoomBooker meetingBooker = new MeetingRoomBooker();
        assertTrue("Hours booked should be 0 ", meetingBooker.getBookedHours().size() == 0);
        boolean isBooked = meetingBooker.bookHour(5);
        assertTrue("Hours booked should be greater than 0 after booking a specific hour", meetingBooker.getBookedHours().size() > 0);
    }

    @Test
    public void shouldPreventDoubleBooking() {
        MeetingRoomBooker meetingBooker = new MeetingRoomBooker();

        assertTrue("First book for the hour should return True", meetingBooker.bookHour(5));
        assertFalse("Second book for the hour should return False", meetingBooker.bookHour(5));
    }

    @Test(expected = IllegalArgumentException.class)
    @Parameters(method = "getInvalidHours")
    public void shouldRejectBookingInvalidHours(int invalidHour) {
        MeetingRoomBooker meetingBooker = new MeetingRoomBooker();
        meetingBooker.bookHour(invalidHour);
    }
}
