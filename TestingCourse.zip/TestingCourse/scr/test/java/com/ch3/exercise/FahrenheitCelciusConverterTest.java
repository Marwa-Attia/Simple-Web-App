package com.ch3.exercise;

import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;

/**
 * Created by u486992 on 4/7/2016.
 */
@RunWith(JUnitParamsRunner.class)
public class FahrenheitCelciusConverterTest {
    public static  Object[] getValues(){
        return $(
                $(32,0),
                $(98,37),
                $(212,100)
        );
    }
    @Test
    @Parameters(method = "getValues")
    public void shouldConvertCelciusToFahrenheit(int fahrenheit,int celcius) {
        assertEquals(fahrenheit, FahrenheitCelciusConverter.toFahrenheit(celcius));
    }
    @Test
    @Parameters(method = "getValues")
    public void shouldConvertFahrenheitToCelcius(int fahrenheit,int celcius) {
        assertEquals(celcius, FahrenheitCelciusConverter.toCelcius(fahrenheit));
    }

    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void testToCelcius() throws Exception {

    }

    @Test
    public void testToFahrenheit() throws Exception {

    }
}
