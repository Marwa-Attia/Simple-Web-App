package com.ch3.exercise;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by u486992 on 4/7/2016.
 */
public class HashMapTest {
    private Map<String, String> mapToTest;
    private static final String OBJECT_KEY1 = "obj_key1";
    private static final String OBJECT_KEY2 = "obj_key2";
    private static final String OBJECT_VALUE1 = "Hello";
    private static final String OBJECT_VALUE2 = "Bye";

    @Before
    public void setUp() {
        mapToTest = new HashMap<String, String>();
    }

    @Test
    public void shouldRetrieveAnObjectUsingGetWithTheSameKey() {
        mapToTest.put(OBJECT_KEY1, OBJECT_VALUE1);
        String result = mapToTest.get(OBJECT_KEY1);
        assertEquals(OBJECT_VALUE1, result);
    }

    @Test
    public void shouldReplaceObjectIfSameKeyUsedToPutDifferentValues() {
        mapToTest.put(OBJECT_KEY1, OBJECT_VALUE1);
        mapToTest.put(OBJECT_KEY1, OBJECT_VALUE2);
        String result = mapToTest.get(OBJECT_KEY1);
        assertEquals(OBJECT_VALUE2, result);
    }

    @Test
    public void clearShouldResultInEmptyMap() {
        mapToTest.put(OBJECT_KEY1, OBJECT_VALUE1);
        mapToTest.put(OBJECT_KEY2, OBJECT_VALUE2);
        assertTrue(mapToTest.size() == 2);
        mapToTest.clear();
        assertTrue(mapToTest.size() == 0);
    }

    @Test
    public void shouldBeAbleToUseNullAsKey() {
        mapToTest.put(null, OBJECT_VALUE1);
        assertTrue(mapToTest.size() == 1);
        String result = mapToTest.get(null);
        assertEquals(OBJECT_VALUE1, result);
    }
}
