package com.ch3.exercise;

import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.*;
@RunWith(JUnitParamsRunner.class)
public class StringReverserTest {



        private static  Object[] getString() {
            return $(
                    $("Hello"),
                    $("hioih"),
                    $(""),
                    $(" ")
            );
        }

        @Test
        @Parameters(method = "getString")
        public void shouldReverseString(String str) {
            String reversed = StringReverser.reverse(str);
            String result = StringReverser.reverse(reversed);
            assertEquals("Double reversing should yield the same String", str, result);

        }
}