package com.ch3.exercise;

import junitparams.JUnitParamsRunner;
import junitparams.Parameters;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junitparams.JUnitParamsRunner.$;

/**
 * Created by u486992 on 4/6/2016.
 */
@RunWith(JUnitParamsRunner.class)
public class StringReverserTest {
    private static final Object[] getString() {
        return $(
                $("Hello"),
                $("hiih")
        );
    }
    @Test
    @Parameters(method = "getString")
    public void shouldReverseString(String str){
      String reversed=  StringReverser.reverse(str);
        System.out.println(reversed);
      //  reversed.
    }
}
